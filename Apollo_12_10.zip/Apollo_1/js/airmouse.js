$(document).ready(function(){
	
	
});
var Generate = {};
Generate.event = function (keyCode) {
	var e = $.Event('keyup');
	e.which = keyCode;
	e.keyCode = keyCode;
	airMouse = true;
	Main.processTrigger(e);
}



/* $(document).on("click","#videoDiv",function(e){
	showPlayerBar();
    playOrPause();
}); */


$(document).on('mousewheel DOMMouseScroll','body', function(event){
	    event.preventDefault();
	    var e = 0;
	    if (event.originalEvent.wheelDelta > 0 || event.originalEvent.detail < 0) {
	        e = tvKeyCode.ArrowUp;
	    }
	    else {
	        e = tvKeyCode.ArrowDown;
	    }
	    Generate.event(e);
	});
	
	$(document.body).scroll(function(event) {
			event.preventDefault();
		    var e = 0;
		    if (event.originalEvent.wheelDelta > 0 || event.originalEvent.detail < 0) {
		        e = tvKeyCode.ArrowUp;
		    }
		    else {
		        e = tvKeyCode.ArrowDown;
		    }
		    Generate.event(e);
	});
	
	$(document).on("mouseover",'#login,.searchBar,.containerBtn,.popUpBtn,.form-control,.profile-button,.playForward,.playRewind,.play-icon',function(e){
        
		var id = $(this).attr("id");
		
        if(id){
			$('.imageFocus').blur();
			$(".imageFocus").removeClass("imageFocus");
			
			$("#" + id).addClass("imageFocus");
		}
           
	});

	$(document).on("mouseover",'.tvEPS,.btn,.live-image,.col-5-eq .tvShows-image,.SP-buttons .btn,.menuBar li,.col-5-eq .shows-image,.menuHorizontal li,.policy,.form-signin,.orange-button,#signIn-0,#signIn-1,#signIn-2,.movie-image,.leftData,.logout,.watchBtn,.btn-default',function(e){
        
		var id = $(this).attr("id");
		try{
			$('#email').blur();$('#password').blur();
		}
		catch(e){

		}
        if(id){
			$(".mouseFocus").removeClass("mouseFocus");
			
			$("#" + id).addClass("mouseFocus");
		}
           
     });
     $(document).on("click",'.searchBar',function(e){
          e.preventDefault();
          //$('.imageFocus').removeClass("imageFocus");
          $('.mouseFocus').focus();
     });
     

	$(document).on("click",'#login,.containerBtn,.popUpBtn,.form-control,.profile-button,.playForward,.playRewind,.play-icon,.tvEPS,.btn,.live-image,.col-5-eq .tvShows-image,.SP-buttons .btn,.menuBar li,.col-5-eq .shows-image,.menuHorizontal li,.policy,.form-signin,.orange-button,#signIn-0,#signIn-1,#signIn-2,.movie-image,.leftData,.logout,.watchBtn,.btn-default',function(e){
        var viewIndex = undefined;
		var id = $(this).attr("id");
		e.preventDefault();
		if(id && id.indexOf("leftMenu") != -1){
			Keyhandler.menuKeyEnter($('.mouseFocus'));
		}
		else{
			if(view == "leftMenu"){
				viewIndex = contentView;
			}
			else{
				viewIndex = view;
			}
		}
		
		
        switch(viewIndex){
            case "homeMovies":{
				if(id == "searchBox")
					Keyhandler.homeKeyEnter($('.imageFocus'));
				else
					Keyhandler.homeKeyEnter($('.mouseFocus'));
				
				;break;
			}
			case "singleMovie":{Keyhandler.singleMovieEnter($(".mouseFocus"));break;}
			
			case "signIn":{$('#email').blur();$('#password').blur();Keyhandler.signInEnter($('.imageFocus'));;break;}
			
			case "timeZone":{Keyhandler.timeZoneListEnter($('.mouseFocus'));;break;}
			case "seasonsList":{Keyhandler.seasonsListEnter($('.mouseFocus'));;break;}
			case "liveTvDetail":{Keyhandler.liveTvDetailKeyEnter($('.mouseFocus'));;break;}
			case "live":{Keyhandler.liveKeyEnter($('.mouseFocus'));;break;}
			case "tvShows":{Keyhandler.tvShowsKeyEnter($('.mouseFocus'));;break;}
			case "confirmPin":{Keyhandler.confirmPinEnter($('.mouseFocus'));;break;}
			case "tvShowDetail":{Keyhandler.tvShowDetailEnter($('.mouseFocus'));;break;}
			case "adultShowDetail":{Keyhandler.adultShowDetailEnter($('.mouseFocus'));;break;}
			case "profile":{Keyhandler.profileEnter($('.imageFocus'));;break;}
			case "watchList":{Keyhandler.watchListKeyEnter($('.mouseFocus'));;break;}
			case "search":
			case "adult":{Keyhandler.adultKeyEnter($('.mouseFocus'));;break;}
			case "changePin":{Keyhandler.changePinEnter($('.mouseFocus'));;break;}
			case "tvGuide":{Keyhandler.epgEnterKeyDown($('.mouseFocus'));;break;}
			case "player":{Player.playEnterKeydown($('.imageFocus'));;break;}
			/* case "":{Keyhandler.signInKeyEnter($('.mouseFocus'));;break;}
			case "":{Keyhandler.signInKeyEnter($('.mouseFocus'));;break;}
			case "":{Keyhandler.signInKeyEnter($('.mouseFocus'));;break;}
			case "":{Keyhandler.signInKeyEnter($('.mouseFocus'));;break;} */
			
			
			case "readMore":
			case "terms":
			case "popUp":{
				
			$("#customMessage").hide();
			$("#customMessage").html('');
			try {
				var obj = popState();
				view = obj.view;
			} catch (e) {}

			if (callBack) {
				callBack();
				callBack = '';
			}
			;break;}
			case "logout":{
				var index = parseInt($(this).attr("index"));
				if(index == 0){
					pushState(view,$(".imageFocus").attr("id"));
					Main.logOut();
				}
				else{
					
					$("#customMessage").hide();
					$("#customMessage").html('');
					try {
						var obj = popState();
						view = obj.view;
						$("#"+obj.focus).addClass("imageFocus");
					} catch (e) {}
		
					if (callBack) {
						callBack();
						callBack = '';
					}
				}
				break;
			}
			case "continue":
			case "acceptTerms":
			case "exitApp":{
				Keyhandler.exitKeyEnter($('.mouseFocus'));
				break;
			}
			
		}
           
	});
	
	function cursorVisibilityChange(event) {
		var visibility = event.detail.visibility;
		if(visibility){
			console.log("Cursor appeared");
		
			showArrows();
		}
		else{
			console.log("Cursor disappeared");
			hideArrows();
		}
	}
	document.addEventListener('cursorStateChange', cursorVisibilityChange, false);


	$(document).on('mousemove','body',function(e){
    	if(view != ""){
    		if($('#leftArrow').css('display')!= 'block')
			{
				arrowsTimeOut = setTimeout(function() {
					if($('#leftArrow').css('display')== 'block')
						hideArrows();   
					clearInterval(arrowsTimeOut);
				},6000);

				showArrows();
			}
                   
    	}
    });


	$(document).on("mouseover",'#downArrow,#upArrow,#leftArrow,#rightArrow,#backArrow',function(){
		$(this).css("opacity",'1');
	});
	$(document).on("mouseout",'#downArrow,#upArrow,#leftArrow,#rightArrow,#backArrow',function(){
		$(this).css("opacity",'0.5');
	});

	$(document).on("click","#leftArrow",function(e){
		e = tvKeyCode.ArrowLeft;
		Generate.event(e); 
	});

	$(document).on("click","#upArrow",function(e){
		e = tvKeyCode.ArrowUp;
		Generate.event(e); 
	});

	$(document).on("click","#downArrow",function(e){
		e = tvKeyCode.ArrowDown;
		Generate.event(e); 
	});

	$(document).on("click","#rightArrow",function(e){
		e = tvKeyCode.ArrowRight;
		Generate.event(e); 
	});

	$(document).on("click","#backArrow",function(e){
		e = tvKeyCode.Return;
		Generate.event(e); 
	});




	function showArrows() {
		if(view != "player"){
			$("#leftArrow").fadeIn();
			$("#rightArrow").fadeIn();
			$("#upArrow").fadeIn();
			$("#downArrow").fadeIn();
		}
		$("#backArrow").fadeIn();
	
	}
	function hideArrows() {
		$("#leftArrow").fadeOut();
		$("#rightArrow").fadeOut();
		$("#upArrow").fadeOut();
		$("#downArrow").fadeOut();
		$("#backArrow").fadeOut();
	}