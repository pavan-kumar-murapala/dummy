Main = {
	BOXID:"",
	country:"",
	offset:"",
	unixTime:"",
	profile : {},
	watchListData : '',
	domain:"apollogroup.tv",
	getDeviceID:function(){	
		if (device && device.uuid) {
			return device.uuid;
		} else {
			return getBOXDetails();
		}
	},
	initialize:function(){
		Main.showSplash();
		
			
		setTimeout(function(){
			Main.BOXID = Main.getDeviceID();
			console.log(Main.BOXID);
			Main.getDomain();
			Main.getTimeOffset();

			if(localStorage.getItem("pin") !== null){
				Main.pin = localStorage.getItem("pin");
			}
			else{
				Main.pin = "1234";
			}
		},0)
		
		
	},
	showSplash: function(){
		$("#splashContent").css("display", "block");
		$("#splashContent").html(Util.splashHtml());
	},
	hideSplash : function () {
		$("#splashContent").hide();
	}
}
var homeLiveData = '',previousView = '';
Main.timeZoneData = {'-12.0':'(GMT-12:00) Etc/GMT+12',
'-11.0':'(GMT-11:00) US/Samoa',
'-10.0':'(GMT-10:00) US/Hawaii',
'-9.5':'(GMT-9:30) Pacific/Marquesas',
'-9.0':'(GMT-9:00) US/Alaska',
'-8.0':'(GMT-8:00) US/Pacific',
'-7.0':'(GMT-7:00) US/Mountain',
'-6.0':'(GMT-6:00) US/Indiana-Starke',
'-5.0':'(GMT-5:00) US/Michigan',
'-4.0':'(GMT-4:00) Etc/GMT+4',
'-3.5':'(GMT-3:30) Canada/Newfoundland',
'-3.0':'(GMT-3:00) Etc/GMT+3',
'-2.0':'(GMT-2:00) Etc/GMT+2',
'-1.0':'(GMT-1:00) Etc/GMT+1',
'0.0':'(GMT0:00) Zulu',
'1.0':'(GMT+1:00) Poland',
'2.0':'(GMT+2:00) Libya',
'3.0':'(GMT+3:00) W-SU',
'3.5':'(GMT+3:30) Iran',
'4.0':'(GMT+4:00) Indian/Reunion',
'4.5':'(GMT+4:30) Asia/Kabul',
'5.0':'(GMT+5:00) Indian/Maldives',
'5.5':'(GMT+5:30) Asia/Kolkata',
'5.45':'(GMT+5:45) Asia/Katmandu',
'6.0':'(GMT+6:00) Indian/Chagos',
'6.5':'(GMT+6:30) Indian/Cocos',
'7.0':'(GMT+7:00) Indian/Christmas',
'8.0':'(GMT+8:00) Singapore',
'8.5':'(GMT+8:30) Asia/Pyongyang',
'8.45':'(GMT+8:45) Australia/Eucla',
'9.0':'(GMT+9:00) ROK',
'9.5':'(GMT+9:30) Australia/Yancowinna',
'10.0':'(GMT+10:00) Pacific/Yap',
'10.5':'(GMT+10:30) Australia/Lord_Howe',
'11.0':'(GMT+11:00) Pacific/Ponape',
'12.0':'(GMT+12:00) Pacific/Wallis',
'12.45':'(GMT+12:45) Pacific/Chatham',
'13.0':'(GMT+13:00) Pacific/Tongatapu',
'14.0':'(GMT+14:00) Pacific/Kiritimati'}
var tvTopMenu = '';
var topMenu = {},homeMoviesData = {},tvShowDetail = {},contentView = "homeMovies";
/*tv Guide*/
var tvGuideChannelList = [];
var window_Width = $(window).width();
/*tv Guide*/
Main.getTvShowDetails = function(imdbID){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/info/"+imdbID+".json",
		type : "GET",
		data : {},
		success : function (data) {
			result = data;
			
			if (result) {
				tvShowDetail = result.result;

				pushState(view,$(".imageFocus").attr("id"));
				$(".imageFocus").removeClass("imageFocus");
				$(".leftHigh").removeClass("leftHigh");
				$("#mainContent").hide();
				view = "tvShowDetail";
				contentView = view;
				$("#SingleMoviePage").html(Util.tvShowDetailPage(tvShowDetail)).show();
				$("#"+contentView+"leftMenu-2").addClass("leftHigh");
				Main.HideLoading();

			} 
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});

};

Main.getDomain = function(login){
	
	$.ajax({
		url : "https://raw.githubusercontent.com/Apollo2000/Repo/master/domain.txt",
		type : "GET",
		data : {},
		success : function (data) {
			result = JSON.parse(data);
			
			if (result) {
				Main.domain = result.result;
				if(localStorage.getItem("profile") !== null){
					
					Main.profile = JSON.parse(localStorage.getItem("profile"));
					if(!Main.profile.json)
						Main.profile.json = "json";
					if(Main.profile.saveLogin){
						Main.getProfileInfo(Main.profile.token);
					}
					else{
						Main.HideLoading();
						Main.hideSplash();
						localStorage.removeItem("pin");
						localStorage.removeItem('profile');
						view = "signIn";
						Main.processNext();
					}
					
				}
				else{
					Main.HideLoading();
					Main.hideSplash();
					localStorage.removeItem("pin");
					localStorage.removeItem('profile');
					view = "signIn";
					Main.processNext();
				}	
				
			} 
		},
		error : function (errObj) {
			Main.getTopMenu("movie");
		},
		timeout : 80000
	});
}
Main.getTopMenu = function(genre){
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/"+genre+"/menu.json",
		type : "GET",
		data : {},
		success : function (data) {
			topMenu[genre] =(data.result);
			if(topMenu[genre][0].id != "none" ){
				if(genre == "movie")
					Main.getHomeSections(topMenu[genre][0].id);
				else if(genre == "tv")
					Main.gettvShowSections(topMenu[genre][0].id);
				else if(genre == "livetv")
					Main.getLiveTvSections(topMenu[genre][0].id);
				else if(genre == "tvGuide")
					Main.getTVGuideSections(topMenu[genre][0].id);
			}
			else{

				Main.showFailure("No Data Available.");

				callBack = function(){
					view  = previousView;
					Main.processNext();
				}

			}
			
			Main.getIP();
				
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}
Main.getLiveTvSections  = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/livetv/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			result = data.result;
			homeLiveData = result;
			view = "leftMenu";
			contentView = "live";menuFocus = '';
			$("#mainContent").html(Util.homeLivePage(result)).show();
			$(".imageFocus").removeClass("imageFocus").removeClass("leftHigh");
			$("#"+contentView+"leftMenu-2").addClass("imageFocus").addClass("leftHigh");
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}

Main.updateLiveTvSections  = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/livetv/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {
			result = data.result;
			homeLiveData = result;
			$("#liveList").html(Util.updateLive());
			Main.HideLoading();
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}

Main.getHomeSections = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/movie/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			result = data.result;
			homeMoviesData = result;
			view = "leftMenu";
			contentView = "homeMovies";
			menuFocus = '';
			$("#mainContent").html(Util.homePage(result)).show();
			$(".imageFocus").removeClass("imageFocus").removeClass("leftHigh");
			$("#"+contentView+"leftMenu-0").addClass("imageFocus").addClass("leftHigh");
		},
		error : function (errObj) {
		},
		timeout : 80000
	});
}
Main.subTitles = '';
Main.getSubTitles = function(type,SEASON,EPISODE){
	var subURL = '';
    try{
		if(type == "movie")
		subURL = "http://subs."+Main.domain+"/?imdb="+singleMoviePage.imdb;
	else
		subURL = "http://subs."+Main.domain+"/?imdb="+tvShowDetail.imdb+"&season="+SEASON+"&episode="+EPISODE;


	$.ajax({
		url : subURL,
		type : "GET",
		data : {},
		success : function (data) {
			Main.subTitles = data;
			if(Object.keys(Main.subTitles).length > 0){
				$(".sub-title").show();
				var txt = '';
				for(var i=0;i<Object.keys(Main.subTitles).length;i++){
					txt += "<b>"+Object.keys(Main.subTitles)[i]+"</b>"
				}
				/* var offset = (90/4) * Object.keys(Main.subTitles).length;
				$('.sub-title .listSubs').css("bottom",offset+"px");
				$('.sub-title .listSubs').html(txt); */
				//playSubs(Main.subTitles[Object.keys(Main.subTitles)[0]]);
			}
			else{
				$(".sub-title").hide();
			}
			
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
	}
	catch(e){
		$(".sub-title").hide();
	}
	
}
Main.updateHomeSections = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/movie/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {
			result = data.result;
			homeMoviesData = result;
			homeFocus = "homeMovies-0-0"
			$("#moviesList").html(Util.updateHomePage(result)).show();

			Main.HideLoading();
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}

Main.getMovieDetails = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/info/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {

			result = data.result;
			singleMoviePage = result;
			
			pushState(view,$(".imageFocus").attr("id"));
			$(".imageFocus").removeClass("imageFocus");
			$("#mainContent").hide();
			view = "singleMovie";
			contentView = view;
			$("#SingleMoviePage").html(Util.movieDetailsPage(singleMoviePage)).show();
			Main.HideLoading();
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}
var homeTvShowData = '';
Main.gettvShowSections = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/tv/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			result = data.result;
			homeTvShowData = result;
			if(homeTvShowData){
				view = "leftMenu";
				contentView = "tvShows";menuFocus = '';
				$("#mainContent").html(Util.homeTVShowPage(result)).show();
				$(".imageFocus").removeClass("imageFocus").removeClass("leftHigh");
				$("#"+contentView+"leftMenu-1").addClass("imageFocus").addClass("leftHigh");
			}
			else{
				Main.showFailure("No TV Shows Available.");
			}
			
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}
Main.updatetvShowSections = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/tv/"+id+".json",
		type : "GET",
		data : {},
		success : function (data) {
			
			result = data.result;
			homeTvShowData = result;
			homeFocus = "hometvShows-0-0";
			$("#tvShowList").html(Util.updatetvShowPage(result)).show();
			Main.HideLoading();
			Main.hideSplash();
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 80000
	});
}
var tvGuideProgramsList = [];
Main.getChannelGuide = function(id){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/epg.php?ids=["+id+"]",
		type : "GET",
		async: false,
		success : function (data) {
			
			var tempArray =  id.split(',');
			for(var i=0;i<tempArray.length;i++){
				var key = tempArray[i].replace(/['"]+/g, '')
				tvGuideProgramsList.push({programme:data[key]});
			}
		},
		error : function (errObj) {
			tvGuideProgramsList.push({programme:[]});
			Main.HideLoading();
		},
		timeout : 20000
	});
}

var updateTimer = '';
Main.updateTvGuideContent = function() {
	// body...
	Main.ShowLoading();
	

	setTimeout(function(){
		if(epgLastIndex+10 < tvGuideChannelList.length)
			epgLastIndex =epgLastIndex+10; 
		else 
			epgLastIndex = tvGuideChannelList.length;
		var tempChannelList = '';
		for(var i=tvGuideProgramsList.length;i<epgLastIndex;i++){
			if(i== tvGuideProgramsList.length)
				tempChannelList = '"'+tvGuideChannelList[i].epg.toLowerCase()+'"';
			else
				tempChannelList = tempChannelList + "," + '"' + tvGuideChannelList[i].epg.toLowerCase() + '"';
			//Main.getChannelGuide(tvGuideChannelList[i].epg.toLowerCase());
		}
		Main.getChannelGuide(tempChannelList);
		$('.prog_list_width').append(Util.updateEPGList());
		Main.HideLoading();
	},100)
	
}

var currentLiveBarPistion = 0;
var liveBar;
Main.getEPGScrollPos = function(){
	var hrs = Main.getOffsetDate().getHours();
	var Min = Main.getOffsetDate().getMinutes();

	if(window_Width == 1280){
		currentLiveBarPistion = (hrs*360) + (Min * 6);
		if(Min > 30)
			Min = 30;
		else 
			Min = 0;
		if(hrs > 0)
			hrs = hrs - 1;
		var scrollPos = (hrs*360) + (Min * 6);
		if(scrollPos > 12900)
			scrollPos = 12900;
	}else{
		currentLiveBarPistion = (hrs*600) + (Min * 10);
		if(Min > 30)
			Min = 30;
		else 
			Min = 0;
		if(hrs > 0)
			hrs = hrs - 1;
		var scrollPos = (hrs*600) + (Min * 10);
		if(scrollPos > 12900)
			scrollPos = 12900;
		else if(scrollPos <= 300)
			scrollPos = 0;
	}
	
	 return -scrollPos;
}

Main.getOffsetDate = function(){
	var targetTime = new Date();
	var timeZoneFromDB = Main.offset;
	var tzDifference = timeZoneFromDB * 60 + targetTime.getTimezoneOffset();
	var offsetDate = new Date(targetTime.getTime() + tzDifference * 60 * 1000);
	return offsetDate;
}

var right = 0;
liveBarFunction = function (){

/*	var x = parseInt(Yup("#liveBar").css('margin-left'));
		right = parseInt(Yup(".prog_list_width").css('margin-left'));*/
	if(window_Width == 1280)
			currentLiveBarPistion = currentLiveBarPistion + 3; 
	else
			currentLiveBarPistion = currentLiveBarPistion + 5; 

	paddingToGive = currentLiveBarPistion;
	$("#liveBar").css('margin-left',currentLiveBarPistion+"px");
	/*if( x  <= Math.abs(right) || x >= (Math.abs(right)+1480)){
		
		Yup("#goLiveButton").removeClass("normal");
	}else{
		
		Yup("#goLiveButton").addClass("normal");
	}*/
		
	
	
}

Main.getIP = function(){
	$.ajax({
		url : "http://api."+Main.domain+"/myip.php",
		type : "GET",
		success : function (data) {
			Main.country = data.country;
			Main.offset = data.offest;//Main.offset = -4;
			Main.offset = Main.offset.toFixed(1);
		},
		error : function (errObj) {
		},
		timeout : 10000
	});
}

var epgList = []; 
Main.getEpgList = function(){
	http://json.89to.com/list/epg.json
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/epg.json",
		type : "GET",
		success : function (data) {
			epgList = data.result;
		},
		error : function (errObj) {
		},
		timeout : 1000
	});
}

var epgLastIndex=0;
var epgSelectedDate = new Date();
Main.getTVGuideSections = function(id) {
	Main.ShowLoading();
	Main.clearEpgData();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/livetv/"+id+".json", //"+id+".json"
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			result = data.result;
			tvGuideChannelList = result;
			//homeFocus = "hometvShows-0-0";
			view = "leftMenu";
			contentView = "tvGuide";
			epgLastIndex = 10;
			var tempChannelList = '';
			if(tvGuideChannelList.length>0){
				
				/* tvGuideChannelList = tvGuideChannelList.reduce(function (item, e1) {  
					var matches = item.filter(function (e2)  
					{ return e1.epg == e2.epg});  
					if (matches.length == 0) {  
						item.push(e1);  
					}  
					return item;  
				}, []);*/
				for(var i=-0;i < tvGuideChannelList.length; i++){
					if(tvGuideChannelList[i].epg == "")
						tvGuideChannelList.splice(i,1);
				}				
				var channelCount = 10;
				if(tvGuideChannelList.length  < 10){
					channelCount = tvGuideChannelList.length;
					epgLastIndex = channelCount;
				}

				for(var i=0;i< channelCount;i++){
					if(i== 0)
						tempChannelList = '"'+tvGuideChannelList[i].epg.toLowerCase()+'"';
					else
						tempChannelList = tempChannelList + "," + '"' + tvGuideChannelList[i].epg.toLowerCase() + '"';
					//Main.getChannelGuide(tvGuideChannelList[i].epg.toLowerCase());
				}
				//Main.getChannelGuide(tvGuideChannelList[i].epg.toLowerCase());
				Main.getChannelGuide(tempChannelList);
			}
			epgSelectedDate = Main.getOffsetDate();
			$("#mainContent").html(Util.homeTVGuidepage(tvGuideChannelList)).show();
			$("#"+contentView+"leftMenu-3").addClass("imageFocus");
			
			$(".prog_list_width").css("margin-left",Main.getEPGScrollPos()+"px");
			
			$("#liveBar").css('margin-left',currentLiveBarPistion+"px");
			clearInterval(liveBar);
		    liveBar = setInterval(function(){ liveBarFunction() }, 30000);
		    Main.HideLoading();
		},
		error : function (errObj) {
		},
		timeout : 20000
	});
}
Main.searchResults = '';
Main.searchData = function(type,value){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/search.php?type="+type+"&search="+value,
		type : "GET",
		data : {},
		success : function (data) {

			if(data && data.result.length){

				if(type != "livetv"){
					if(data.result[0].title && data.result[0].title.indexOf("NO RESULTS") == -1)
					{
						Main.searchResults = data.result;
						$("#mainContent").html(Util.searchHtml(type));
						pushState(view,'');
						view = "search";	
						if(type == "movie")
							$("#homeMovies-0-0").addClass("imageFocus");
						else if(type == "livetv")
							$("#homeLive-0-0").addClass("imageFocus");
						else if(type == "tv")
							$("#hometvShows-0-0").addClass("imageFocus");
					}
					else{
						Main.showInfo("No Results Found");
						callBack = '';
					}
				}
				else{
					if(data.result[0].name && data.result[0].name.indexOf("NO RESULTS") == -1)
					{
						Main.searchResults = data.result;
						$("#mainContent").html(Util.searchHtml(type));
						pushState(view,'');
						view = "search";	
						if(type == "movie")
							$("#homeMovies-0-0").addClass("imageFocus");
						else if(type == "livetv")
							$("#homeLive-0-0").addClass("imageFocus");
						else if(type == "tv")
							$("#hometvShows-0-0").addClass("imageFocus");
					}
					else{
						Main.showInfo("No Results Found");
						callBack = '';
					}

				}
				
				
			}
			else{
				Main.showInfo("No Results Found");
				callBack = '';
			}
			Main.HideLoading();
		},
		error : function (errObj) {
			Main.HideLoading();
		},
		timeout : 20000
	});
}

Main.getTVGuide = function(){
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/livetv/menu.json",
		type : "GET",
		data : {},
		success : function (data) {
			topMenu["tvGuide"] =(data.result);
			if(topMenu["tvGuide"].length>0)
				Main.getTVGuideSections(topMenu["tvGuide"][0].id);
				
		},
		error : function (errObj) {
		},
		timeout : 20000
	});
}

Main.clearEpgData = function(){
	tvGuideCurrentList = [];
	tvGuideProgramsList = [];
	tvGuideChannelList = [];
	previousRowIndex = "";
	currentActive_prog_id = [];
}
Main.updateTvGuideSection = function(id){
	Main.ShowLoading();
	Main.clearEpgData();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/livetv/"+id+".json", //"+id+".json"
		type : "GET",
		async : false,
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			result = data.result;
			tvGuideChannelList = result;
			var tempChannelList = '';
			epgLastIndex = 10;
			if(tvGuideChannelList.length>0){
				
				 /*tvGuideChannelList = tvGuideChannelList.reduce(function (item, e1) {  
					var matches = item.filter(function (e2)  
					{ return e1.epg == e2.epg});  
					if (matches.length == 0) {  
						item.push(e1);  
					}  
					return item;  
				}, []);*/
				for(var i=-0;i < tvGuideChannelList.length; i++){
					if(tvGuideChannelList[i].epg == "")
						tvGuideChannelList.splice(i,1);
				}				
				
				var channelCount = 10;
				if(tvGuideChannelList.length  < 10){
					channelCount = tvGuideChannelList.length;
					epgLastIndex = channelCount;
				}
				for(var i=0;i< channelCount;i++){
					if(i== 0)
						tempChannelList = '"'+tvGuideChannelList[i].epg.toLowerCase()+'"';
					else
						tempChannelList = tempChannelList + "," + '"' + tvGuideChannelList[i].epg.toLowerCase() + '"';
					//Main.getChannelGuide(tvGuideChannelList[i].epg.toLowerCase());
				}
				Main.getChannelGuide(tempChannelList);
			}
			$('.list_vertical #navBar').nextAll().remove();
			$(".list_vertical #navBar").after(Util.epgProgramSection(tvGuideChannelList));
			if(Main.getOffsetDate().getDay() != epgSelectedDate.getDay())
				$('#liveBar').hide();
			else{
				$(".prog_list_width").css("margin-left",Main.getEPGScrollPos()+"px");
				$("#liveBar").css('margin-left',currentLiveBarPistion+"px");
				clearInterval(liveBar);
			    liveBar = setInterval(function(){ liveBarFunction() }, 30000);
				$('#liveBar').show();
			}

			
			/*$(".prog_list_width").css("margin-left",Main.getEPGScrollPos()+"px");
			$("#liveBar").css('margin-left',currentLiveBarPistion+"px");
			clearInterval(liveBar);
			liveBar = setInterval(function(){ liveBarFunction() }, 30000);*/
			Main.HideLoading();
			Main.hideSplash();
		},
		error : function (errObj) {
		},
		timeout : 20000
	});

}
String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};
var stack = [];
Main.ShowLoading = function () {
	if ($("#splashContent").css("display") == "none")
		document.getElementById("loading").style.display = "block";
}
Main.playerShowLoading = function () {
	if(view == "player"){
		$('#playerLoading').removeClass('loader-bg');
		$('#playerLoading img').removeClass('dockPlayerImgLoader').addClass('playerImgLoader');
		
		if(!$('#loadPercent').length)
			$('#playerloadingImg').append('<div id="loadPercent"></div>');
	}else{
		
	}
	if ($("#splashContent").css("display") == "none" && $("#PlayBackImage").css("display") != "table" && $('#beforePlayer').css('display') != 'block')
		document.getElementById("playerLoading").style.display = "block";
}
Main.playerHideLoading = function () {
	document.getElementById("playerLoading").style.display = "none";
	$('#loadPercent').remove();
}
Main.HideLoading = function () {
	try{
		document.getElementById("loading").style.display = "none";
	}
	catch(e){
		
	}
	
}
device = {
	
}
var mainPlayUrl = '';
var callBack = '';
var cookieBoxNo = null;
var cookieSupported = false;
var view = '';
var Generate = {},previousFocus = '';;
Generate.event = function (keyCode) {
	var e = $.Event('ke$');
	e.which = keyCode;
	e.keyCode = keyCode;
	airMouse = true;
	Main.processTrigger(e);
}
function hideValues(){
	$("#SingleMoviePage").hide();
	$("#mainContent").hide();
	homeFocus = '';
	
}
Main.processNext = function (event) {
	switch (view) {
	case "homeMovies": {
		hideValues();
		stack = [];
		contentView = view;
		if(previousFocus && previousFocus.indexOf("Movies") != -1){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#mainContent").show();
			previousFocus = '';
			
		}
		else{
			previousFocus = '';
			Main.getHomeSections(topMenu["movie"][0].id);
		}
		
		break;
	}
	case "adult":{
		contentView = view;
		if(previousFocus){
			$('#'+previousFocus).addClass("imageFocus");
			$("#mainContent").show();
			previousFocus = '';
		}
		else{

		}
		break;
	}
	case "tvShows": {
		hideValues();
		stack = [];
		contentView = view;
		if(previousFocus && previousFocus.indexOf("tvShow") != -1){
		if(previousFocus.indexOf("leftMenu") != -1)
			view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#mainContent").show();
			previousFocus = '';
		}
		else{
		/* 	if(topMenu["tv"]){
				Main.gettvShowSections(topMenu["tv"][0].id);
			}
			else{ */
				Main.getTopMenu("tv");
			//}
			previousFocus = '';
			
		}
		break;
	}
	case "live":{
		hideValues();
		stack = [];
		contentView = view;
		if(previousFocus && previousFocus.indexOf("Live") != -1){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#mainContent").show();
			previousFocus = '';
		}
		else{
			//if(topMenu["livetv"]){
			//	Main.getLiveTvSections(topMenu["livetv"][0].id);
			//}
			//else{
				Main.getTopMenu("livetv");
			//}
			previousFocus = '';
			$(".imageFocus").removeClass("imageFocus").removeClass("leftHigh");
			$("#"+contentView+"leftMenu-2").addClass("imageFocus").addClass("leftHigh");
		}
		break;
	}
	case "signIn":{
		hideValues();
		Main.hideSplash();
		$('.imageFocus').removeClass("imageFocus");
		$("#signIn").html(Util.signIn());
		$("#signIn").show();
		Main.HideLoading();
		break;
	}
	case "tvShowDetail":{
		contentView = view;
		if(previousFocus){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#SingleMoviePage").show();
			previousFocus = '';
		}
		
		break;
	}
	case "adultShowDetail":{
		contentView = view;
		if(previousFocus){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#SingleMoviePage").show();
			previousFocus = '';
		}
		break;
	}
	case "liveTvDetail":{
		contentView = view;
		if(previousFocus){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#SingleMoviePage").show();
			previousFocus = '';
		}
		Main.HideLoading();
		break;
	}
	case "singleMovie":{
		contentView = view;
		if(previousFocus){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#SingleMoviePage").show();
			previousFocus = '';
		}
		else{

		}
		
		break;
	}
	case "player":{
		$('.imageFocus').removeClass("imageFocus");
		$("#SingleMoviePage").hide();
		$("#mainContent").hide();
		Player.playStream();
		break;
	}
	case "search":{
		if(previousFocus){
			$('#'+previousFocus).addClass("imageFocus");previousFocus = '';
		}
		$("#mainContent").show();
		$("#SingleMoviePage").hide();
		$("#SingleMoviePage").html();
		break;
	}
	case "watchList":{
		if(previousFocus){
			$('#'+previousFocus).addClass("imageFocus");
		}
		else{
			$("#mainContent").html(Util.watchListHTML());
			
		}
		$("#mainContent").show();
		$("#SingleMoviePage").hide();
		$("#SingleMoviePage").html();
		stack = [];
		contentView  = view;
		view  = "leftMenu";
		if(!previousFocus)
			$("#"+contentView+"leftMenu-4").addClass("imageFocus").addClass("leftHigh");
		else
			previousFocus = '';
		
		Main.HideLoading();
		break;
	}
	case "tvGuide":{
		hideValues();
		stack = [];
		if(previousFocus){
			if(previousFocus.indexOf("leftMenu") != -1)
				view  = "leftMenu";
			$('#'+previousFocus).addClass("imageFocus");
			$("#mainContent").show();
			previousFocus = '';
		}
		else{
			if(topMenu["tvGuide"]){
				Main.getTVGuideSections(topMenu["tvGuide"][0].id);
			}
			else{
				Main.getTVGuide();
			}
			previousFocus = '';
		}
		break;
	}
	}
}





Main.processTrigger = function (event) {
	$('.mouseFocus').removeClass('mouseFocus');
	if ($('#loading').css("display") != "block" || view == "player") {
		switch (view) {
		case "leftMenu":{
			Keyhandler.menuKeyhandler(event);
			break;
		}
		case "homeMovies": {
				Keyhandler.homeKeyhandler(event);
				break;
			}
	    case "timeZone":{
			Keyhandler.timeZoneKeyhandler(event);
			break;
		}
		case "singleMovie": {
				Keyhandler.singleMovieKeydown(event);
				break;
			}
		case "popUp": {
				Keyhandler.descKeyhandler(event);
				break;
		}
		case "seasonsList":{
			Keyhandler.seasonsListKeyhandler(event);
			break;
		}
		case "liveTvDetail":{
			Keyhandler.liveTvDetailKeydown(event);
			break;
		}
		case "player":{
			Player.playKeydown(event);
			break;
		}
		case "tvShows":{
			Keyhandler.tvShowsKeyDown(event);
			break;
		}
		case "live":{
			Keyhandler.liveTvKeyhandler(event);
			break;
		}
		case "confirmPin":{
			Keyhandler.confirmPinKeyDown(event);
			break;
		}
		case "tvShowDetail":{
			Keyhandler.tvShowDetailKeyhandler(event);
			break;
		}
		case "adultShowDetail":{
			Keyhandler.adultShowDetailKeyhandler(event);
			break;
		}
		case "signIn":{
			Keyhandler.signInKeyhandler(event);
			break;
		}
		case "profile":{
			Keyhandler.profileKeyhandler(event);
			break;
		}
		case "watchList":{
			Keyhandler.watchListKeyDown(event);
			break;
		}
		case "search":
		case "adult":{
			Keyhandler.adultKeyDown(event);
			break;
		}
		case "changePin":{
			Keyhandler.changePinKeyDown(event);
			break;
		}
		case "tvGuide":{
			Keyhandler.tvGuideKeyHandler(event);
			break;
          }
          case "exitApp":{
			Keyhandler.exitKeyhandler(event);
			break;
		}
	}
	}
}
function pushState(view, focus, backData, startTime) {

	console.log("pushState ");
	if(view == "leftMenu") view = contentView;
	for (var i = 0; i < stack.length; i++) {
		if (stack[i].view == view) {
			stack.splice(i, 1);
			i = 0;
		}
	}
	var obj = {
		"view" : view,
		"focus" : focus,
		"backData" : backData,
		"time" : startTime
	}
	stack.push(obj);
}
function popState(view, focus) {
	console.log("popState");
	return stack.pop();
}

var HomeData = {};
var macTimer = 0;

Main.checkInWatchList = function(type,id){
for(var i=0;i<watchlistMap[type].length;i++){
	if(type != "channel"){
		if(watchlistMap[type][i].imdb == id)
			return true;
	}
	else{
		if(watchlistMap[type][i].id == id)
		return true;
	}
}
return false;
}

Main.showSuccess = function (msg) {

	if (view != "popUp")
		pushState(view, $(".imageFocus").attr("id"));
	view = "popUp";
	$("#customMessage").show();
	$("#customMessage").html(Util.showStatusPopUp(1, msg, "OK"));
};
Main.showFailure = function (msg) {

	var status = navigator.onLine;

	if (status == false) {
		if (view != "popUp")
			pushState(view, $(".imageFocus").attr("id"));
		
		view = "popUp";
		$("#customMessage").show();

		if (navigator.connection.type && navigator.connection.type.toUpperCase() != "NONE" && navigator.connection.type.toUpperCase() != "UNKNOWN")
			$("#customMessage").html(Util.showPopUpMessage(1, "Trouble connecting to Internet using " + navigator.connection.type.toUpperCase() + ", please Try again.", "", "Okay"));
		else
			$("#customMessage").html(Util.showPopUpMessage(1, "Trouble connecting to Internet, please Try gain.", "", "Okay"));

		Main.HideLoading();
		/*callBack = function () {
			location.reload();
		}*/
	} else {
		if (view != "popUp")
			pushState(view, $(".imageFocus").attr("id"));
		view = "popUp";
		$("#customMessage").show();
		if (!msg)
			$("#customMessage").html(Util.showStatusPopUp(0, "Something went wrong", "OK"));
		else
			$("#customMessage").html(Util.showStatusPopUp(0, msg, "OK"));
		Main.HideLoading();
	}

};
Main.showMessage = function(msg){
	$("#customMessage").show();
	$("#customMessage").html("<div id='showMessage'>"+msg+"</div>");
}
Main.showInfo = function (msg) {
	if (view != "popUp")
		pushState(view, $(".imageFocus").attr("id"));
	view = "popUp";
	$("#customMessage").show();
	$("#customMessage").html(Util.showStatusPopUp(2, msg, "OK"));
}
Main.ShowMenu = function(season){
	if (view != "seasonsList")
		pushState(view, $(".imageFocus").attr("id"));
	$(".imageFocus").removeClass("imageFocus");
	view = "seasonsList";
	$("#customMessage").show();
	$("#customMessage").html(Util.showMenuPopUp(season,tvShowDetail.seasons,"Season"));
}

Main.ShowTimeZone = function(zone){
	pushState(view, $(".imageFocus").attr("id"));
	$(".imageFocus").removeClass("imageFocus");
	view = "timeZone";
	$("#customMessage").show();
	$("#customMessage").html(Util.showTimeZone(zone));
	var dataKeys = Object.keys(Main.timeZoneData);
	var focusIndex = dataKeys.indexOf(Main.offset+"");
	$("#timeList-"+focusIndex).addClass("imageFocus");
}

Main.ShowSubtitles = function(){
	//pushState(view, $(".imageFocus").attr("id"));
	$(".imageFocus").removeClass("imageFocus");
	//view = "subTitles";
	$("#customMessage").show();
	$("#customMessage").html(Util.showSubs());
	$("#subsList-0").addClass("imageFocus");
}

Main.getTimeOffset = function(){
	
	$.ajax({
		url : "http://api.89to.com/myip.php",
		type : "GET",
		data : {},
		success : function (data) {
				Main.offset = data.offest;
				//Main.offset = -4;
				Main.offset = Main.offset.toFixed(1);
				var x = parseInt(Main.offset) + "" + (Main.offset % 1) * 60;
				for(var i=0;i<Main.timeZoneData.length;i++){
					if(Main.timeZoneData[i].split("GMT")[1].split(")")[0] == x){
						Main.timeZone = Main.timeZoneData[i];
					}
				}
				
		},
		error : function (errObj) {
		},
		timeout : 80000
	});
}
Main.updateEpisodes = function(seasonID){
	var Text = '';
	for(var i=0;i<Object.keys(tvShowDetail.seasons[seasonID]).length && i < 4;i++){
		Text += Util.generateEpsCard(tvShowDetail,tvShowDetail.seasons[seasonID][(i+1)],(i+1),seasonID,Object.keys(tvShowDetail.seasons[seasonID]).length);
	}
	$("#episodes").html(Text);
	$("#SP-btn-1 span").text("Season Selected - "+(seasonID))
	tvEPSIndex = 1;
}
var watchlistMap = {"movies":[],"tvshow":[],"channel":[]}

Main.getWatchList = function(){
	
	$.ajax({
		url : "http://api."+Main.domain+"/watchlist/?token="+Main.profile.token,
		type : "GET",
		data : {},
		success : function (data) {
			Main.watchListData = data;
			
			if(Main.watchListData.result && Main.watchListData.result.imdb)
				for(var i=0;i<Object.keys(Main.watchListData.result.imdb).length;i++){
					var key = Object.keys(Main.watchListData.result.imdb)[i];
					var val = Main.watchListData.result.imdb[key];
					if(parseInt(val.tvdb))
						watchlistMap["tvshow"].push(val);
					else
						watchlistMap["movies"].push(val) ;
				}
			if(Main.watchListData.result && Main.watchListData.result.channels)
				for(var i=0;i<Object.keys(Main.watchListData.result.channels).length;i++){
					var key = Object.keys(Main.watchListData.result.channels)[i];
					var val = Main.watchListData.result.channels[key];
					watchlistMap["channel"].push(val);
				}

		},
		error : function (errObj) {
		},
		timeout : 80000
	});
}

Main.getWatchListData =  function(type){
	homeFocus = '';

	$("#watchList").html(Util.getWatchListDivHTML(type));
}


Main.hitWatchList = function(action, channel, imdb, season, eps){
	var ApiUrl = '';
	if(channel)
		ApiUrl = "http://api."+Main.domain+"/watchlist/?token="+Main.profile.token+"&watchlist="+action+"&channel="+channel;
	else
		ApiUrl =  "http://api."+Main.domain+"/watchlist/?token="+Main.profile.token+"&watchlist="+action+"&imdb="+imdb+"&season="+season+"&episode="+eps;
	$.ajax({
		url : ApiUrl,
		type : "GET",
		data : {},
		success : function (data) {

			Main.watchListData = data;
			watchlistMap["channel"] = [],watchlistMap["tvshow"] = [],watchlistMap["movies"] = [];
			if(Main.watchListData.result && Main.watchListData.result.imdb)
				for(var i=0;i<Object.keys(Main.watchListData.result.imdb).length;i++){
					var key = Object.keys(Main.watchListData.result.imdb)[i];
					var val = Main.watchListData.result.imdb[key];
					if(parseInt(val.tvdb))
						watchlistMap["tvshow"].push(val);
					else
						watchlistMap["movies"].push(val) ;
				}
			if(Main.watchListData.result && Main.watchListData.result.channels)
				for(var i=0;i<Object.keys(Main.watchListData.result.channels).length;i++){
					var key = Object.keys(Main.watchListData.result.channels)[i];
					var val = Main.watchListData.result.channels[key];
					watchlistMap["channel"].push(val);
				}
			Main.HideLoading();
		},
		error : function (errObj) {
		},
		timeout : 80000
	});
}
Main.playStream = function(imdbID,seasonID,episode){
	Main.ShowLoading();
	$.ajax({
		url : "http://api."+Main.domain+"/play/?token="+Main.profile.token+"&imdb="+imdbID+"&season="+seasonID+"&episode="+episode,
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();

			if(!data || data.error){
                    if(data.error.error)
                         Main.showFailure(data.error.error);
                    else
                         Main.showFailure("Something went wrong");
                         
				callBack =  function(){
					var obj = popState();
					view = obj.view;
					previousFocus = obj.focus;
					Main.processNext();
				}
			}
			else{
				Player.data = data;
				Player.url = Player.data.link;
				if(imdbID && episode)
					Player.type = "show";
				else
					Player.type = "movie";
	
				pushState(view, $(".imageFocus").attr("id"));
				view = "player";
				Main.processNext();
			}
			
		},
		error : function (errObj) {
			Main.showFailure(errObj.responseText);
		},
		timeout : 80000
	});
}
Main.playLive = function(channelID){
	Main.ShowLoading();
	$.ajax({
		url : "http://api."+Main.domain+"/play/?token="+Main.profile.token+"&channel="+channelID,
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			if(data.error){
				Main.showFailure(data.error);
			}
			else{
				Player.type = "live";
				Player.data = data;
				Player.url = Player.data.link;
				view = "player";
				Main.processNext();
			}
			
		},
		error : function (errObj) {
			Main.showFailure(errObj.responseText);
		},
		timeout : 80000
	});
}
var adultArray = {};
Main.getAdultMovies = function(){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/info/tt6969696.json",
		type : "GET",
		data : {},
		success : function (data) {
			$("#SingleMoviePage").hide();
			$("#SingleMoviePage").html('');
			adultArray.movies = data.result;
			Main.getAdultChannels();
		},
		error : function (errObj) {
			Main.showFailure(errObj.responseText);
		},
		timeout : 80000
	});
}
Main.getAdultChannels = function(){
	Main.ShowLoading();
	$.ajax({
		url : "http://"+Main.profile.json+"."+Main.domain+"/list/livetv/69.json",
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			adultArray.channels = data.result;
			$('.imageFocus').removeClass("imageFocus");
			$('.leftHigh').removeClass("leftHigh");

			view = "leftMenu";
			contentView = "adult";menuFocus = '';
			$("#mainContent").html(Util.adultPage(adultArray)).show();
			$(".imageFocus").removeClass("imageFocus").removeClass("leftHigh");
			$("#"+contentView+"leftMenu-6").addClass("imageFocus").addClass("leftHigh");
		},
		error : function (errObj) {
			Main.showFailure(errObj.responseText);
		},
		timeout : 80000
	});
}

Main.login = function(email,pwd){
	Main.ShowLoading();
	$.ajax({
		url : "http://api."+Main.domain+"/login/?email="+email+"&password="+pwd,
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			if(!data.error){
				Main.profile = data;
				Main.profile.saveLogin = true;
				
				if(!Main.profile.json)
					Main.profile.json = "json";

				localStorage.removeItem("pin");
				localStorage.removeItem('profile');

				localStorage.setItem('profile', JSON.stringify(Main.profile));
				$("#signIn").hide();
				$("#signIn").html("");
				if(stack.length){
					$("#"+contentView+"leftMenu-5 p").text("Log out")
					var obj = popState();
					view = obj.view;
					previousFocus = obj.focus;
					Main.processNext();
				}
				else{
					Main.getProfileInfo(Main.profile.token);
				}
			}
			else{
				Main.showFailure(data.error);
				callBack = '';
			}
			
		},
		error : function (errObj) {
			Main.HideLoading();
			Main.showFailure(errObj.responseText);
			callBack = '';
		},
		timeout : 80000
	});
}

Main.getProfileInfo = function(token){
	$.ajax({
		url : "http://api."+Main.domain+"/account/?&token="+token,
		type : "GET",
		asyn:false,
		data : {},
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			if(data){
				if(parseInt(data.expire) == 0){
					
					view = "signIn";
					Main.processNext();
				}
				else {
					Main.tokenInfo = data;
					Main.getTopMenu("movie");
					if(Main.profile.token)
						Main.getWatchList();
				}
			}
			
		},
		error : function (errObj) {
			Main.HideLoading();
			view = "signIn";
			Main.processNext();
		},
		timeout : 80000
	});
}

Main.logOut = function(email,pwd){
	Main.ShowLoading();
	$.ajax({
		url : "http://api."+Main.domain+"/logout/?token="+Main.profile.token,
		type : "GET",
		data : {},
		success : function (data) {
			Main.HideLoading();
			Main.hideSplash();
			Main.profile = '';
			Main.pin = 1234;
			localStorage.removeItem("pin");
			localStorage.removeItem('profile');
			$("#"+contentView+"leftMenu-5 p").text("Sign In");
			view = "signIn";
			Main.processNext();
		},
		error : function (errObj) {
		},
		timeout : 80000
	});
}

function getBOXDetails() {
	try {
		try {
			if (document.cookie) {
				cookieBoxNo = read_cookie('boxNo');
				cookieSupported = true;
				console.log("cookie support is there")
			}
		} catch (e) {
			console.log("No cookie support");
		}

		if (cookieBoxNo == null) {
			if (typeof(Storage) !== "undefined") {
				if (localStorage.getItem("boxNo") === null) {
					var bxN = uuid.v1().replaceAll("-","").substr(0,12).toUpperCase();
					localStorage.setItem("boxNo",bxN);
					return bxN;
				} else {
					var boxNo = localStorage.getItem("boxNo");
					if (cookieSupported)
						write_cookie('boxNo', boxNo);
					return boxNo;
				}
			} else {
				var bxN = uuid.v1().replaceAll("-","").substr(0,12).toUpperCase();
				localStorage.setItem("boxNo",bxN);
				return bxN;
			}
		} else {
			return cookieBoxNo;
		}
	} catch (e) {
		return "ERROR";
	}

}
function write_cookie(name, value) {
	var expiration_date = new Date();
	expiration_date.setFullYear(2040);
	expiration_date = expiration_date.toGMTString();

	var cookie_string = escape(name) + "=" + escape(value) + "; expires="
		 + expiration_date;
	document.cookie = cookie_string;
}
function read_cookie(key) {

	var cookie_string = "" + document.cookie;
	var cookie_array = cookie_string.split("; ");

	for (var i = 0; i < cookie_array.length; ++i) {
		var single_cookie = cookie_array[i].split("=");
		if (single_cookie.length != 2)
			continue;
		var name = unescape(single_cookie[0]);
		var value = unescape(single_cookie[1]);

		if (key == name)
			return value;
	}
	// Cookie was not found:
	return null;
}