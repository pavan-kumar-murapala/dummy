Util = {};
Util.splashHtml = function() {
    var Text = "";
    Text += '<div style="overflow:hidden;height:100%;width:100%;background:url(images/splash-logo.png) no-repeat; background-size:36%;background-position:center center;">';
    Text += '</div>';
    return Text;
}
var listMenu = true;
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                ];
const monthFullNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];
var timeArray =  ['00:00 AM','00:30 AM','01:00 AM','01:30 AM','02:00 AM','02:30 AM','03:00 AM','03:30 AM','04:00 AM','04:30 AM','05:00 AM','05:30 AM','06:00 AM','06:30 AM','07:00 AM','07:30 AM','08:00 AM','08:30 AM','09:00 AM','09:30 AM','10:00 AM','10:30 AM','11:00 AM','11:30 AM','12:00 PM','12:30 PM','01:00 PM','01:30 PM','02:00 PM','02:30 PM','03:00 PM','03:30 PM','04:00 PM','04:30 PM','05:00 PM','05:30 PM','06:00 PM','06:30 PM','07:00 PM','07:30 PM','08:00 PM','08:30 PM','09:00 PM','09:30 PM','10:00 PM','10:30 PM','11:00 PM','11:30 PM',]//dont remove space between time and Am /pm space is mandetory 
var timeArrayToCompare =  ['00:00 AM','00:30 AM','01:00 AM','01:30 AM','02:00 AM','02:30 AM','03:00 AM','03:30 AM','04:00 AM','04:30 AM','05:00 AM','05:30 AM','06:00 AM','06:30 AM','07:00 AM','07:30 AM','08:00 AM','08:30 AM','09:00 AM','09:30 AM','10:00 AM','10:30 AM','11:00 AM','11:30 AM','12:00 PM','12:30 PM','13:00 PM','13:30 PM','14:00 PM','14:30 PM','15:00 PM','15:30 PM','16:00 PM','16:30 PM','17:00 PM','17:30 PM','18:00 PM','18:30 PM','19:00 PM','19:30 PM','20:00 PM','20:30 PM','21:00 PM','21:30 PM','22:00 PM','22:30 PM','23:00 PM','23:30 PM',]
function formatDate(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  //return date.getMonth()+1 + "/" + date.getDate() + "/" + date.getFullYear() + " " + strTime;
  return date.getMonth()+1 + "/" + date.getDate() + "/" + date.getFullYear() ;
}			

Util.getSubChannels = function(array){
	var Text = '';
	Text += '<ul class="submenu">'
//Text += '<li>'
if(listMenu){
	Text += '<div class="listMenu">'
	Text += '<ul>'
	var star = '';
	for(var i=0;i<array.length;i++){
		if(array[i].favorite){
			star = "<img style='width:25px' src='images/star.png'>"
		}
		else{
			star = '';
		}
		Text += '	<li source="playSubChannels" type="list" index="'+i+'" id="liveChannels-'+i+'" length="'+array.length+'"><table><tr><td><img class="listThumb" src="'+array[i].thumb+'"></td><td class="channelText"><p> '+array[i].name+' </p></td><td>'+star+'</td></tr></table></li>'
	}
	Text += '</ul>'
	Text += '</div>'
}
else{
	Text += '<div class="GridMenu">'
	Text += '<ul>'
	for(var i=0;i<array.length;i++){
		if(i%5 == 0){
			Text += '<div id="Grow-'+(i/5)+'">'
		}
		Text += '	<li><div type="grid" source="playSubChannels" index="'+i+'" id="liveChannels-'+i+'" length="'+array.length+'"><img class="gridthumb" src="'+array[i].thumb+'"><p class="gridTitle">'+array[i].name+'</p></div></li>'
		if((i+1)%5 == 0 && i != 0){
			Text += '</div>';
		}
		
	}
		
	
	Text += '</ul>'
	Text += '</div>'
}

//Text += '</li>'
Text += '</ul>'
return Text;
}
Util.leftMenu = function(setView){
	var Text = '';
	Text += '<div  class="wrapper"  >';
	Text += '<div  class="leftMenu col-sm-1 no-padding"  >'
	
	Text += '<ul class="menuBar">'


	    Text += '<li class="dummyList">'
		Text += '</li>'
		Text += '<li class="" index = 0 id="'+setView+'leftMenu-0" ><img src="images/movies.png"><p>Movies</p>'


		Text += '</li>'
		
		Text += '<li  index = 1 id="'+setView+'leftMenu-1" ><img src="images/tv-shows.png"><p>TV Shows</p>'
		Text += '</li>'
		
		Text += '<li  index = 2 id="'+setView+'leftMenu-2"><img src="images/livetv.png"></i><p>Live TV</p>'
		Text += '</li>'
		
		Text += '<li  index = 3 id="'+setView+'leftMenu-3"><img src="images/tv-guide.png"><p>TV GUIDE</p>'
		Text += '</li>';

		Text += '<li  index = 4 id="'+setView+'leftMenu-4"><img src="images/watchlist.png"><p>Watch List</p>'
		Text += '</li>'

		Text += '<li  index = 5 id="'+setView+'leftMenu-5"><img src="images/profile.png"><p>Profile</p>'
		Text += '</li>';

		if(Main.profile.showAdult){
			Text += '<li  index = 6 id="'+setView+'leftMenu-6"><img src="images/adult.png" style="width: 50px;"><p>ADULT</p>'
			Text += '</li>';
		}


		if(Main.profile){
			Text += '<li  index = 7 id="'+setView+'leftMenu-7"><img src="images/logout.png"><p>Sign Out</p>';
		}
		else{
			Text += '<li  index = 7 id="'+setView+'leftMenu-7"><img src="images/logout.png"><p>Sign In</p>';
		}
		
		Text += '</li>'
	Text += '</ul>'
	Text +='</div>';
	return Text;
}
Util.updateHomePage = function(homeData){
	var Text = '';

	var rowID = 0;
	for(var i=0;i<homeData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		if(v_index < 2){
			if(h_index == 0){
				Text += "<div id='homeRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generateMovieCard(homeData[i],v_index,h_index,i,homeData.length);
			//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>"
			}
		}
		

	}
	return Text;
}

Util.profilePage = function(){
	var Text = '';

	Text += '<div class="profile-container">'
	Text += '<div class="profile-bg-wrap"><div class="profile-logo"><img src="images/logo.png"/></div></div>'
	Text += '<div class="profile-detail"><div class="profile-image"><img src="images/profile-icon.png"/></div><span class="profile-name">'+Main.tokenInfo.nicename+'</span></div>'
	




	Text += '<div class="profile-account-details"><div class="row"><div class="profile-detail-inner col-sm-6"><img src="images/profile.png"/><span>'+Main.tokenInfo.account+'</span></div><div class="profile-detail-inner col-sm-6"><img src="images/calendar.png"/><span>Expire: '+Main.tokenInfo.expire+'</span></div>'
	Text += '</div></div>'
	
    Text += '<div class="profile-account-buttons">'
	Text += '<div class="row">'
	var setFocus = false;
	Text += '<div class="col-sm-6">'
	//Main.profile.adult = 1;
	if(Main.profile.adult){
		if(Main.profile.showAdult)
			Text += '<div class=""><label class="containerBtn imageFocus" id ="adultBox" > Allow Adult Content <input type="checkbox" checked> <span class="checkmark"></span></label> </div>';
		else
			Text += '<div class=""><label class="containerBtn imageFocus" id ="adultBox" > Allow Adult Content <input type="checkbox" > <span class="checkmark"></span></label> </div>';
		Text += '<br/>'
		setFocus = true;
	 }
	 
		if(!setFocus)
			Text += '<div class="">selected time zone : <button id="timeZone" class="profile-button imageFocus" >  '+Main.timeZoneData[Main.offset]+' </button></div>';
	    else
			Text += '<div class="">selected time zone : <button id="timeZone"  class="profile-button">  '+Main.timeZoneData[Main.offset]+'</button></div>';
	
	Text += '</div>'

	Text += '<div class="col-sm-6">'
	if(Main.profile.adult){
		Text += '<div class="" style="text-align: right;"><button id="changePin"  class="profile-button">Change Pin</button></div>';
		Text += '<br/>';
	}
	 
	
	Text += '<div class=""  style="text-align: right;"><label class="containerBtn" id="loginSave" > Save Login Info <input  type="checkbox" checked><span class="checkmark"></span></label> </div>';
	

	Text += '</div>'

	
	Text += '</div>'

	Text += '</div>'

	return Text;
}
Util.liveTvDetailPage = function(obj,index){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	Text += Util.leftMenu("liveTvDetail");

	Text += '<div class="col-sm-11 inner-content no-padding">'
	
	Text += '<div  class="header clearfix" id="heading">'
	Text += '<div  class="container">'			
	Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
	Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Movies</h1></div>'
	//Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
	Text += '</div>';
	Text += '</div>';

	Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'
	Text += '<li >Live TV / '+obj.name+'</li>'					
	Text +='</ul></div></div>';

	
	Text += '<div  class="liveDetail-page" id="liveDiv" >'
	Text += '<div  class="liveBanner" id="" >'
	Text+="<img  src='"+obj.logo+"'>"
	Text +='</div >';
	Text += ' <div class="liveChannelButtons">'
	Text += '<div  class="row liveEpgNow" >'
		Text += '<div  class="col-sm-3" >'
		Text+="<img src='"+obj.logo+"' class='liveDetailImg'>"
		Text +='</div >';
		Text += '<div  class="col-sm-9" >'
		if(obj.epg_now){
			
			Text+="<h2 class='epgNow'>Live Now : "+obj.epg_now+"</h2>"
			Text+="<h2 class='epgNow'>Live Next : "+obj.epg_next+"</h2>"
			
		}
		Text +='</div >';

	Text +='</div >';

	Text +='<div class="SP-buttons">';
	if(Main.checkInWatchList("channel",obj.id)){
		toAdd =  "Remove from";
	}
	else{
		toAdd =  "Add to";
	}
	Text +='<div source="SPbuttons" liveID="'+obj.id+'" index="0" liveTVIndex ='+index+'  id="watchNow" class="btn playButton imageFocus"><img src="images/livetv.png"/><span>Play</span></div>';
	Text +='<div source="SPbuttons" index="1" liveTVIndex ='+index+'  id="watchListBtn" class="btn dark-btn watchList" ><img src="images/watchlist.png"/><span>'+toAdd+' WatchList</span></div>';
	
	Text += '</div>';
	
	Text +='</div>';
	Text += '</div>';
	
	Text += '</div>';

	return Text;
}

Util.movieDetailsPage = function(singleMoviePage){
	var Text = '';
	
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("singleMovie");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading">'
			Text += '<div  class="container">'			
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Movies</h1></div>'
			//Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
                        Text += '</div>';
                        Text += '</div>';

			Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'

			
			Text += '<li >'+singleMoviePage.genres+'</li>'					
			
			
			Text +='</ul></div></div>';

			Text += '<div  class="details-page" id="movieDiv" >'
			
			Text += '<div  class="details-page-left" id="movieImage" >'
			Text+="<img src='"+singleMoviePage.poster+"'  onerror='this.src=\"images/show.png\";'>"
			Text +='</div >';

			Text += '<div  class="details-page-right" id="movieCategory" >'
				Text += '<div  class="title-name" >'+singleMoviePage.title+' ('+singleMoviePage.year+')</div>'
				
				Text +='<div class="release-date">'+dateUtil(singleMoviePage.released * 1000)+' <div class="votes"><img src="images/watchlist.png"/><b>'+singleMoviePage.votes+'</b></div></div> ';
				Text +='<div class="desc" >'+(singleMoviePage.plot.length > 600 ? singleMoviePage.plot.substring(0,598)+".." : singleMoviePage.plot )+'</div>';
				Text +='<div class="rating">';
				
				Text +='<div class="rating-value"><span>'+singleMoviePage.rank+'<b>/10</b></span></div>';
				Text +='<div class="imdb-btn"><img src="images/imdb-btn.png"/></div>';

				Text += '</div>';
				Text +='<div class="SP-buttons">';
				var toAdd = 'Add to';
				if(Main.checkInWatchList("movies",singleMoviePage.imdb)){
					toAdd =  "Remove from";
				}
				Text +='<div source="SPbuttons" index="0" id="SP-btn-0" class="btn playButton imageFocus"><img src="images/livetv.png"/><span>Play</span></div>';
				Text +='<div source="SPbuttons" index="1"  id="SP-btn-1" class="btn dark-btn watchList" ><img src="images/watchlist.png"/><span>'+toAdd+' WatchList</span></div>';
			//	Text +='<div source="SPbuttons" index="2"  id="SP-btn-2" class="btn dark-btn allDetails"><div class="dots"><span></span><span></span><span></span></div><span>Show All Details</span></div>';
				
				
				Text +='</div>';
				
			Text +='</div >';


			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
	
	return Text;
}

Util.tvShowDetailPage = function(show){
	var Text = '';
	
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("tvShowDetail");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading">'
			Text += '<div  class="container">'			
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">TV SHOW</h1></div>'
			//Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
                        Text += '</div>';
                        Text += '</div>';

			Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'

			
			Text += '<li >'+show.genres+'</li>'					
			
			
			Text +='</ul></div></div>';

			Text += '<div class="scrollSingleDiv">';

			Text += '<div  class="details-page " id="movieDiv" >'
			
			Text += '<div  class="details-page-left" id="movieImage" >'
			Text+="<img src='"+show.poster+"'>"
			Text +='</div >';

			Text += '<div  class="details-page-right" id="movieCategory" >'
				Text += '<div  class="title-name" >'+show.title+' </div>'
				
				Text +='<div class="release-date">'+dateUtil(parseInt(tvShowDetail.released) * 1000)+' <div class="votes"><img src="images/watchlist.png"/><b>'+show.votes+'</b></div></div>';
				Text +='<div class="desc" >'+ ( show.plot.length > 600 ? show.plot.substring(0,598)+".." : show.plot ) +'</div>';
				Text +='<div class="rating">';
				
				Text +='<div class="rating-value"><span>'+show.rank+'<b>/10</b></span></div>';
				Text +='<div class="imdb-btn"><img src="images/imdb-btn.png"/></div>';

				Text += '</div>';
				Text +='<div class="SP-buttons">';
				
				Text +='<div source="SPbuttons" index="0"  id="SP-btn-1" class="btn dark-btn selectSeason imageFocus" style="margin-right: 30px;" ><span>Season Selected - '+ Object.keys(tvShowDetail.seasons)[ Object.keys(tvShowDetail.seasons).length-1] +'</span></div>';
				
				var toAdd = 'Add to';
				if(Main.checkInWatchList("tvshow",show.imdb)){
					toAdd =  "Remove from";
				}
				Text +='<div source="SPbuttons" index="1"  id="watchListBtn" class="btn dark-btn watchList" style="margin-top: 25px;" ><img src="images/watchlist.png"/><span>'+toAdd+' WatchList</span></div>';
				
				//Text +='<div source="SPbuttons" index="0" id="SP-btn-0" class="btn playButton imageFocus"><img src="images/livetv.png"/><span>Play</span></div>';
				//Text +='<div source="SPbuttons" index="1"  id="SP-btn-1" class="btn dark-btn watchList" ><img src="images/watchlist.png"/><span>Add to WatchList</span></div>';
			//	Text +='<div source="SPbuttons" index="2"  id="SP-btn-2" class="btn dark-btn allDetails"><div class="dots"><span></span><span></span><span></span></div><span>Show All Details</span></div>';
				
				Text +='</div>';

				
			Text +='</div >';
			

			Text +='</div >';

			Text += "<div class='episodes' id='episodes' style='display: inline-block;'>"
			/* if(Object.keys(show.seasons).length > 0)
			for(var i=0;i<Object.keys(show.seasons[1]).length;i++){
				var v_index = Math.floor(i/4);
				var h_index = i % 4;
				if(h_index == 0){
					if(v_index > 0)
						Text += "<div id='epsRow-"+v_index+"' style='display:none' class='episodesRow row'>"
					else
						Text += "<div id='epsRow-"+v_index+"' class='episodesRow row'>"
				}
					
				Text += Util.generateEpsCard(show,show.seasons[1][(i+1)],v_index,h_index,(i+1),1,Object.keys(tvShowDetail.seasons[1]).length);
				if(h_index == 3)
					Text += "</div>"
			} */
			var seasonToShow = Object.keys(tvShowDetail.seasons).length-1;
			seasonToShow = Object.keys(show.seasons)[seasonToShow];
			for(var i=0;i<Object.keys(show.seasons[seasonToShow]).length && i < 4;i++){
				Text += Util.generateEpsCard(show,show.seasons[seasonToShow][(i+1)],(i+1),seasonToShow,Object.keys(tvShowDetail.seasons[seasonToShow]).length);
			}

			Text +='</div>';
			Text +='</div >';
			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
	
	return Text;
}

Util.adultDetailPage = function(show){
	var Text = '';
	
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("adultShowDetail");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading">'
			Text += '<div  class="container">'			
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">TV SHOW</h1></div>'
		//	Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
                        Text += '</div>';
                        Text += '</div>';

			Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'

			
				
			
			
			Text +='</ul></div></div>';

			Text += '<div class="scrollSingleDiv">';

			Text += '<div  class="details-page " id="movieDiv" >'
			
			Text += '<div  class="details-page-left" id="movieImage" >'
			Text+="<img src='"+show.poster+"' style='width:100%'>"
			Text +='</div >';

			Text += '<div  class="details-page-right" id="movieCategory" >'
				Text += '<div  class="title-name" >'+show.name+'</div>'
				

				Text += '</div>';
				Text +='<div class="SP-buttons">';
				
				Text +='<div source="SPbuttons" index="0"  id="SP-btn-1" class="btn dark-btn selectSeason imageFocus" style="margin-top: 450px;    margin-left: 40px;" ><span>Play Episode 1</span></div>';

				Text +='</div>';

				
			Text +='</div >';
			

			

			Text += "<div class='episodes' id='episodes' style='display: inline-block;'>"
	
			
			for(var i=0;i<show.episodes.length && i < 4;i++){
				Text += Util.adultEpsCard(show,show.episodes[i],(i),0,show.episodes.length);
			}

			Text +='</div>';
			Text +='</div >';
			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
	
	return Text;
}

Util.searchHtml = function(type){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	//Text += Util.leftMenu("live");


		Text += '<div  class="col-sm-12 no-padding" >';
			Text += '<div  class="header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Search Results</h1></div>'
			//Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			/* Text += '<div  id="navBar" ><div class="container"><ul class="menuHorizontal">'

			for (var i=0;i<topMenu["livetv"].length;i++){
				if(i == 0){
					Text += '<li  id="liveTopMenu-'+i+'" count='+topMenu["livetv"].length+' class="menuLiveSelected" source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'">'+topMenu["livetv"][i].name+'</li>'					
				}
				else if(i < 10){
					Text += '<li  id="liveTopMenu-'+i+'" count='+topMenu["livetv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'">'+topMenu["livetv"][i].name+'</li>'					
				}
				else{
					Text += '<li  id="liveTopMenu-'+i+'" style="display:none" count='+topMenu["livetv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'">'+topMenu["livetv"][i].name+'</li>'					
				}
			}
			
			Text +='</ul></div></div>'; */
			Text += '<div  class="inner-wrap">'
			Text += '<div class="center-layout" >'
			
			Text += '<div id="adultList" >'
			
			/* for(var i=0;i<homeLiveData.length && i < 4;i++){
				Text += Util.generateLiveCard(homeLiveData[i],i,homeLiveData.length);
			} */

			var rowID = 0;
			
			for(var i=0;i<Main.searchResults.length;i++){

				var v_index = Math.floor(i/5);
				var h_index = i % 5;
			//	if(v_index < 2){
					if(h_index == 0){
						Text += "<div id='adultRow-"+v_index+"' class='row'>";
					}
					Text +="<div class='col-5-eq'>"
					if(type == "livetv")
						Text += Util.generateLiveCard(Main.searchResults[i],v_index,h_index,i,Main.searchResults.length);
					else if(type == "movie")
						Text += Util.generateMovieCard(Main.searchResults[i],v_index,h_index,i,Main.searchResults.length);
					else
						Text += Util.generatetvShowCard(Main.searchResults[i],v_index,h_index,i,Main.searchResults.length);
					//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
					Text +="</div>"
					if(h_index == 4){
						Text += "</div>";
					}
			//	}
				

			}
			Text +='</div >';
			Text +='</div >';
			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
    return Text;
}

function dateUtilNew(date){
	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
   ];
	var date = new Date(date);
	
	var year = date.getFullYear();
	var month = date.getMonth();
	var day = date.getDate();
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var seconds = date.getSeconds();

	return day+" "+monthNames[month] + " " + year;
}

function dateUtil(epocTime){
	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
   ];
	var date = new Date(parseInt(epocTime));
	
	var year = date.getFullYear();
	var month = date.getMonth();
	var day = date.getDate();
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var seconds = date.getSeconds();

	return day+" "+monthNames[month] + " " + year;
}
Util.updatetvShowPage =  function(homeTvShowData){
	var Text = '';
	
	var rowID = 0;
	for(var i=0;i<homeTvShowData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		if(v_index < 2){
			if(h_index == 0){
				Text += "<div id='tvShowRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>";
			}
		}
		

	}
    return Text;
}


Util.playerBody = function(){
	var Text = '';
	
		Text +='<div id="PlayBackImage" style="display:none">'
		var image = 'https://d3lyihdno7nd8k.cloudfront.net/image/livebg.jpg';
		
		//image = selectedMovie.backgroundImage;
		Text +='<div id="playerBackImg" style="background:url('+image+') no-repeat;background-size: 100% 100%;background-repeat:no-repeat;height:100%;" ></div> '
		Text += '<img src="images/TV_Loader.png" class="imgLoaderForMovies">'
		Text +='<div class="liveGradient"></div>'
		
		
		Text += '</div>'
		
		
		Text +='<div class="player">'
			
	
			Text +='<div class="player-content">'
			Text +='<div class="container">'
				Text +='<p></p>'
			Text +='</div>'
			Text +='</div>'
				
			/* Text += '<div class="play-icon-wrap">'
		   
			Text +='<span class="play-icon" style="display:none" source="play-icon"><img src="images/play-icon.png"/></span>';
			 Text +='<div source="playerPrev" id="playerPrev"><div class="snapImage"><img src=""/></div></div>';
			Text +=	'<div source="playerNext" id="playerNext"><div class="snapImage"><img src=""/></div></div>';
			
			Text += '</div>'; */
			Text +='<div class="player-inner"></div>'
			Text +='<div class="flix-mov-title" id="flix-mov-title">'
				Text +='<div class="iconPlay"><img src="images/splash-logo.png"></div>'
				Text +='<div class="playIconText">'+ Player.name
				+'</div>'
			Text +='</div>'
			


			Text +='<div class="playerBottomDiv">';
				Text +='<div class="flix-seekbar"  id="flix-seekbar" onmouseover=\'progressIconHandle(event, "over");\' onclick=\'progressIconHandle(event, "click");\' onmousedown=\'progressIconHandle(event, "down");\' onmouseout=\'progressIconHandle(event, "out");\'>'
				
						
				Text +='<div class="flix-seekbar-load" id="flix-seekbar-load"></div>'
				Text +='<div class="flix-seekbar-run" id="flix-seekbar-run"></div>'
				Text +='<a href="#" class="seek-picker" id="seek-picker" source="picker"></a>'
				Text +='<span class="seek-picker-runtime" id="seek-picker-runtime"></span>'
				Text += '</div><div id="playerLog" ></div>' 
			
				Text +='<span class="seek-picker-start" id="seek-picker-start">00:00:00</span>'
				Text +='<span class="seek-picker-end" id="seek-picker-end">00:00:00</span>'
				

				Text += '<div class="sub-title" source="subtitles">'
				Text += '<span><img src="images/subtitle.png"/></span>'
				Text += '<span>Sub title</span>'
				//Text += '<div class="listSubs"><b>English</b></div>';
				Text += '</div>'	
			Text += '</div>'
			
		    Text +='</div>'
			Text +='</div>'
		Text +='</div>'
	  return Text;
}
Util.addLiveRow = function(v_indexAdd){
	var Text = '';
	var rowID = 0;
	for(var i= (v_indexAdd)*5;i<homeLiveData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		
		if(v_index == v_indexAdd){

			if(h_index == 0){
				Text += "<div id='liveRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generateLiveCard(homeLiveData[i],v_index,h_index,i,homeLiveData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>";
			}
		}
		else{
			break;
		}
		

	}
	return Text;
}
Util.homeLivePage =  function(homeLiveData){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("live");


		Text += '<div  class="col-sm-11 inner-content live-page  no-padding" >';
			Text += '<div  class="header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Live</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search"  maxlength = "20"  id="searchBox" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div  id="navBar" ><div class="container"><ul class="menuHorizontal">'
			var classToAdd = '';;
			for (var i=0;i<topMenu["livetv"].length;i++){
				classToAdd = '';
				
				if(topMenu["livetv"][i].name.length > 13)
					classToAdd = "namescroll";
				if(i == 0){
					Text += '<li  id="liveTopMenu-'+i+'" count='+topMenu["livetv"].length+' class="menuLiveSelected" source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'"><p class="'+classToAdd+'">'+topMenu["livetv"][i].name+'</p></li>'					
				}
				else if(i < 10){
					Text += '<li  id="liveTopMenu-'+i+'" count='+topMenu["livetv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'"><p class="'+classToAdd+'">'+topMenu["livetv"][i].name+'</p></li>'					
				}
				else{
					Text += '<li  id="liveTopMenu-'+i+'" style="display:none" count='+topMenu["livetv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'"><p class="'+classToAdd+'">'+topMenu["livetv"][i].name+'</p></li>'					
				}
			}
			
			Text +='</ul></div></div>';
			Text += '<div  class="inner-wrap">'
			Text += '<div class="center-layout" >'
			Text += '<div id="liveList" >'
			
			/* for(var i=0;i<homeLiveData.length && i < 4;i++){
				Text += Util.generateLiveCard(homeLiveData[i],i,homeLiveData.length);
			} */

			var rowID = 0;
			for(var i=0;i<homeLiveData.length;i++){

				var v_index = Math.floor(i/5);
				var h_index = i % 5;
				if(v_index < 2){
					if(h_index == 0){
						Text += "<div id='liveRow-"+v_index+"' class='row'>";
					}
					Text +="<div class='col-5-eq'>"
					Text += Util.generateLiveCard(homeLiveData[i],v_index,h_index,i,homeLiveData.length);
					//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
					Text +="</div>"
					if(h_index == 4){
						Text += "</div>";
					}
				}
				

			}
			Text +='</div >';
			Text +='</div >';
			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
    return Text;
}

Util.updateLive = function(){
	var Text = '';
	var rowID = 0;
	for(var i=0;i<homeLiveData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		if(v_index < 2){
			if(h_index == 0){
				Text += "<div id='liveRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generateLiveCard(homeLiveData[i],v_index,h_index,i,homeLiveData.length);
			//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>";
			}
		}
		

	}
	return Text;
}

Util.generateLiveCard = function(obj,v,h,i,count){
	var Text = '';
	Text += '<div class="live-image" imdb="'+obj.id+'" v_index="'+v+'" h_index="'+h+'"	index='+i+' id="homeLive-'+v+"-"+h+'" count='+count+' >'
        Text += '<div class="live-image-inner">'
	Text += '<img src="' + obj.logo + '"  onerror="this.src=\'images/livetv-error.jpg\';" />';
	Text += '</div>'
	Text += '<div class="liveNameText">'+obj.name+'</div>'
  Text += '</div>'
	return Text;
}
Util.adultEpsCardGenerate =  function(i,s){
	var Text = '';
	Text += '<div source = "eps" class="tvEPS" imdb="'+adultShowDetail.imdb+'"	index='+i+' id="eps-'+i+'" eps='+i+' season = '+s+'  count='+adultShowDetail.episodes.length+' >'
	Text += '<img src="' + adultShowDetail.episodes[i].poster + '"  onerror="this.src=\'images/show.png\';" />';
	
	Text += '<div class="tvMeta">'
	
	Text += '<div class="epsName">'+adultShowDetail.episodes[i].name+'</div>'
	
	Text += '</div>'
	
	Text += '</div>'
	return Text;
}
Util.generateTVEPSCard = function(i,s){
	var Text = '';
	Text += '<div source = "eps" class="tvEPS" imdb="'+tvShowDetail.imdb+'"	index='+i+' id="eps-'+i+'" eps='+i+' season = '+s+'  count='+Object.keys(tvShowDetail.seasons[s]).length+' >'
	Text += '<img src="' + tvShowDetail.seasons[s][i].screenshot + '"  onerror="this.src=\'images/show.png\';" />';
	
	Text += '<div class="tvMeta">'
	Text += '<div class="epsNumber">Episode No. '+i+'</div>'
	Text += '<div class="epsName">'+tvShowDetail.seasons[s][i].title+'</div>'
	Text += '<div class="epsDate">'+dateUtilNew((tvShowDetail.seasons[s][i].released) * 1000)+'</div>';

	var descText = '';
	if(tvShowDetail.seasons[s][i].plot.length > 60)
		descText = tvShowDetail.seasons[s][i].plot.substring(0,60) + " ..";
	else
		descText = tvShowDetail.seasons[s][i].plot;

	Text += '<div class="epsDesc">'+descText+'</div>'
	
	Text += '</div>'
	
	Text += '</div>'
	return Text;
}
Util.adultEpsCard = function(show,obj,i,s,count){
	var Text = '';
	Text += '<div   source = "eps" class="tvEPS" imdb="'+show.imdb+'" index='+i+' id="eps-'+i+'" eps='+i+' season = '+s+'  count='+count+' >'
	var image = '';
	if(obj){
		image = obj.poster;
	}
	Text += '<img src="' + image	+ '"  onerror="this.src=\'images/show.png\';" />';
	
	Text += '<div class="tvMeta">'
	if(show.name)
		Text += '<div class="epsName">'+show.name+'</div>'	
	Text += '</div>'

	Text += '</div>'
	return Text;
}
Util.generateEpsCard = function(show,obj,i,s,count){
	var Text = '';
	Text += '<div   source = "eps" class="tvEPS" imdb="'+show.imdb+'" index='+i+' id="eps-'+i+'" eps='+i+' season = '+s+'  count='+count+' >'
	var image = '';
	if(obj){
		image = obj.screenshot;
	}
	Text += '<img src="' + image	+ '"  onerror="this.src=\'images/show.png\';" />';
	
	Text += '<div class="tvMeta">'
	Text += '<div class="epsNumber">Episode No. '+i+'</div>'
	if(obj.title)
		Text += '<div class="epsName">'+obj.title+'</div>'
	else if(obj.name)
		Text += '<div class="epsName">'+obj.name+'</div>'
	if(obj.released)
	Text += '<div class="epsDate">'+dateUtilNew((obj.released) * 1000)+'</div>';

	var descText = '';
	if(obj.plot && obj.plot.length > 60)
		descText = obj.plot.substring(0,60) + " ..";
	else
		descText = obj.plot;

	Text += '<div class="epsDesc">'+descText+'</div>'
	
	Text += '</div>'

	Text += '</div>'
	return Text;
}
Util.homeTVShowPage =  function(homeTvShowData){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("tvShows");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">TV SHOWS</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search"  maxlength = "20"  id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div  id="navBar" ><div class="container"><ul class="menuHorizontal ">'
			var classToAdd = '';

			for (var i=0;i<topMenu["tv"].length;i++){
				classToAdd = '';
				
				if(topMenu["tv"][i].name.length > 13)
					classToAdd = "namescroll";
				if(i == 0){
					Text += '<li  id="tvShowsTopMenu-'+i+'" count='+topMenu["tv"].length+' class="tvmenuSelected" source="topMenu" index='+i+' attrId="'+topMenu["tv"][i].id+'"><p class="'+classToAdd+'">'+topMenu["tv"][i].name+'</p></li>'					
				}
				else if(i>8){
					Text += '<li  id="tvShowsTopMenu-'+i+'" style="display:none" count='+topMenu["tv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["tv"][i].id+'"><p class="'+classToAdd+'">'+topMenu["tv"][i].name+'</p></li>'										
				}else{
					Text += '<li  id="tvShowsTopMenu-'+i+'" count='+topMenu["tv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["tv"][i].id+'"><p class="'+classToAdd+'">'+topMenu["tv"][i].name+'</p></li>'					
				}
			}
			
			Text +='</ul></div></div>';
			Text += '<div class="center-layout">'
			Text += '<div id="tvShowList" >'
			
			var rowID = 0;
			for(var i=0;i<homeTvShowData.length;i++){

				var v_index = Math.floor(i/5);
				var h_index = i % 5;
				if(v_index < 2){
					if(h_index == 0){
						Text += "<div id='tvShowRow-"+v_index+"' class='row'>";
					}
					Text +="<div class='col-5-eq'>"
					Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
					Text +="</div>"
					if(h_index == 4){
						Text += "</div>";
					}
				}
				

			}
			Text +='</div >';
			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
    return Text;
}
Util.addTvRow = function(v_indexAdd){
	var Text = '';
	var rowID = 0;
	for(var i= (v_indexAdd)*5;i<homeTvShowData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		
		if(v_index == v_indexAdd){

			if(h_index == 0){
				Text += "<div id='tvShowRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>";
			}
		}
		else{
			break;
		}
		

	}
	return Text;
}
Util.generatetvShowCard = function(obj,v,h,i,count){
	var Text = '';
	Text += '<div class="tvShows-image" imdb="'+obj.imdb+'"	index='+i+' h_index='+h+'  v_index='+v+'  id="hometvShows-'+v+"-"+h+'" count='+count+' >'
	Text += '<div class="tvShowImg"><img src="' + obj.poster + '"  onerror="this.src=\'images/default-thumb.png\';" /></div>';
		Text += '<div class="shows-content">';
			Text += '<div class="shows-name">'+obj.title+'</div>'
			var seasons = '',dateValue = '';
			if(obj.seasons && obj.seasons.last){
				dateValue = "Last: "+ dateUtil(obj.seasons.last.released * 1000);
				seasons = obj.seasons.last.season +" Seasons";
			} 

    Text += '<div class="shows-detail">'+obj.year+'- '+ (seasons)+' - <b>'+obj.rank+'</b></div>'
			Text += '<div class="shows-date"> '+dateValue+'</div>'
		
		Text +='</div>';
	Text += '</div>'
	return Text;
}
Util.homePage = function(homeData){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("homeMovies");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class= "header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Movies</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text"  maxlength = "20" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div id="navBar"><div class="container"><ul class="menuHorizontal">'
			var classToAdd = '';
			for (var i=0;i<topMenu["movie"].length;i++){
				classToAdd = '';
				
				if(topMenu["movie"][i].name.length > 13)
					classToAdd = "namescroll";
				if(i == 0){
					Text += '<li  id="topMenu-'+i+'" count='+topMenu["movie"].length+' class="menuSelected" source="topMenu" index='+i+' attrId="'+topMenu["movie"][i].id+'"><p class="'+classToAdd+'">'+topMenu["movie"][i].name+'</p></li>'					
				}
				else if(i >= 8){
					Text += '<li  id="topMenu-'+i+'" style="display:none" count='+topMenu["movie"].length+' source="topMenu" index='+i+' attrId="'+topMenu["movie"][i].id+'"><p class="'+classToAdd+'">'+topMenu["movie"][i].name+'</p></li>'										
				}else	{
					Text += '<li  id="topMenu-'+i+'" count='+topMenu["movie"].length+' source="topMenu" index='+i+' attrId="'+topMenu["movie"][i].id+'"><p class="'+classToAdd+'">'+topMenu["movie"][i].name+'</p></li>'					
				}
			}
			
			Text +='</ul></div></div>';
						Text += '<div class="inner-wrap">'
			Text += '<div class="center-layout">'
			Text += '<div id="moviesList">'                        
			/* for(var i=0;i<homeData.length && i < 4;i++){
					Text += Util.generateMovieCard(homeData[i],i,homeData.length);
			} */

			var rowID = 0;
			for(var i=0;i<homeData.length;i++){

				var v_index = Math.floor(i/5);
				var h_index = i % 5;
				if(v_index < 2){
					if(h_index == 0){
						Text += "<div id='homeRow-"+v_index+"' class='row'>";
					}
					Text +="<div class='col-5-eq'>"
					Text += Util.generateMovieCard(homeData[i],v_index,h_index,i,homeData.length);
					//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
					Text +="</div>"
					if(h_index == 4){
						Text += "</div>";
					}
				}
				

			}
			Text +='</div >';
			Text +='</div >';
                        Text +='</div >';

			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	
    return Text;
}
Util.addMovieRow = function(v_indexAdd){
	var Text = '';
	var rowID = 0;
	for(var i= (v_indexAdd)*5;i<homeMoviesData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		
		if(v_index == v_indexAdd){

			if(h_index == 0){
				Text += "<div id='homeRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generateMovieCard(homeMoviesData[i],v_index,h_index,i,homeMoviesData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>";
			}
		}
		else{
			break;
		}
		

	}
	return Text;
}
Util.generateMovieCard = function(obj,v,h,i,count){
	var Text = '';
	Text += '<div class="shows-image" v_index="'+v+'" h_index="'+h+'" imdb="'+obj.imdb+'"	index='+i+' id="homeMovies-'+v+"-"+h+'" count='+count+' >'
	Text += '<img src="' + obj.poster + '"  onerror="this.src=\'images/default-thumb.png\';" />';
	Text += '</div>'
	return Text;
}
Util.adultMovieCard = function(obj,v,h,i,count){
	var Text = '';
	Text += '<div class="shows-image" v_index="'+v+'" h_index="'+h+'" imdb="'+obj.imdb+'"	index='+i+' id="homeMovies-'+v+"-"+h+'" count='+count+' >'
	Text += '<img src="' + obj.poster + '"  onerror="this.src=\'images/default-thumb.png\';" />';
	Text += '<div class="adult-content">';
	Text += '<div class="adult-name">'+obj.name+'</div>'
    Text +='</div>';
	Text += '</div>' 
	return Text;
}

Util.generatePlayerOverlay = function(){
    var Text = '';
    Text += '<div class="wrapperMenu">'
	Text += '<ul >'
	var count = 0;
	function checkLive(obj){
		return obj.type == "live";
	}
	var liveData = HomeData.categories.filter(checkLive);
	for(var i=0;i<liveData.length;i++){
		 
		Text += '<li source="playCatg" index="'+i+'" id="cat-'+i+'" length="'+liveData.length+'">'+liveData[i].name+'</li>';	
	}
	Text += '</ul>';
    Text += '</div>';

    return Text;
}


Util.showStatusPopUp = function(code,message,btnText){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="info-msg-cont">'
    Text += '<div class="row remove-margin">'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4">'
    var image = 'https://d20w296omhlpzq.cloudfront.net/devices/common/shape-5@3x.png';
    if(code == 0)
        image = 'images/error.png';
    else if(code ==1)
        image = 'images/success.png';
    else
        image = 'images/info.png';
    
   // Text += '<img src="'+image+'" class="img-responsive pop-err-ico" alt="">'
    Text += '</div>'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '<p class="dis-block">'+message+'</p>'
    Text += '<a href="#" class="orange-button" style="margin:0px">'+btnText+'</a>'
    Text += '</div>'

    return Text;
}

Util.showPopUp1 = function(no,title,desc,info1,info2){
    var Text = '';
    Text += '<div class="">'
    Text += '<div class="overlay-screen">'
    Text += '</div>'
    Text += '<div class="popup-Message-container popup-lg">'
	Text += '<h4 class="popUpSubhead">'+title+'</h4>'
	Text += '<h4 class="sumHead"></h4>'
    Text += '<div class="readmoreText " >'+desc
    Text += '</div>'
    Text +=   '<div class="col-md-12 col-lg-12 col-xl-12 remove-padding mt30">'
    if(no == 2){
        
        Text +=     '<a id="Btn-0" class="popUpBtn popUpBtn-orange remove-margin" index="0"> << '+info1+'</a>'
        Text +=     '<a id="Btn-1" class="popUpBtn  ml30  remove-margin" index="1">'+info2+'</a>'
        
    }
    else if(no == 1){
            Text +=     '<a id="Btn-0" index = "0" class="popUpBtn-orange btn btn-default popUpBtn remove-margin" style="margin-left: -2%;"> '+info1+'</a>'
    }
    else {
        
    }
    Text +=   '</div>  '
    Text +=   ''
    Text += '</div>'
    Text += ''
    Text += '</div>'
return Text;
}

Util.changePin = function(){
    var Text = '';
    Text += '<div class="">'
    Text += '<div class="overlay-screen">'
    Text += '</div>'
    Text += '<div class="popup-Message-container popup-lg">'
	Text += '<h4 class="pinHead">Change Pin</h4>'
	Text += '<h4 class="errorHead"></h4>'
	Text += '<div class="readmoreText " >'
	
	Text += '<div class="login-content">'
	
	Text += '<div class="form-group"><span class="labelClass">Old Pin</span><input type="password" maxlength = "15" class="form-control imageFocus" id="oldPin"/></div>'
	Text += '<div class="form-group"><span class="labelClass">New Pin</span><input type="password" maxlength = "15" class="form-control" id="newPin"/></div>'
	Text += '<div class="form-group"><span class="labelClass">Confirm Pin</span><input type="password" maxlength = "15" class="form-control" id="confirmPin"/></div>'
	
	Text += '</div>'
	


    Text += '</div>'
    Text +=   '<div class="col-md-12 col-lg-12 col-xl-12 remove-padding mt30" style="text-align: center;">'
	Text +=     '<a id="changePin" class="popUpBtn btnConfirm popUpBtn-orange remove-margin" index="0">Change Pin</a>'
    Text +=   '</div>  '
    Text +=   ''
    Text += '</div>'
    Text += ''
    Text += '</div>'
return Text;
}
Util.confirmPin = function(){
    var Text = '';
    Text += '<div class="">'
    Text += '<div class="overlay-screen">'
    Text += '</div>'
    Text += '<div class="popup-Message-container popup-lg">'
	Text += '<h4 class="pinHead">Change Pin</h4>'
	Text += '<h4 class="errorHead"></h4>'
	Text += '<div class="readmoreText " >'
	
	Text += '<div class="login-content">'
	
	Text += '<div class="form-group"><span class="labelClass">Enter Pin</span><input type="password" maxlength = "15"  class="form-control imageFocus" id="oldPin"/></div>'
	
	Text += '</div>'
	


    Text += '</div>'
    Text +=   '<div class="col-md-12 col-lg-12 col-xl-12 remove-padding mt30" style="text-align:center">'
	Text +=     '<a id="changePin" class="popUpBtn btnConfirm popUpBtn-orange remove-margin" index="0">Change Pin</a>'
    Text +=   '</div>  '
    Text +=   ''
    Text += '</div>'
    Text += ''
    Text += '</div>'
return Text;
}
Util.showMenuPopUp = function(seasonNo,list,name){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="info-msg-cont">'
    Text += '<div class="row remove-margin">'
	Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
	var count = Object.keys(list).length;
	for(var i=0;i<count;i++){
		if(Object.keys(tvShowDetail.seasons)[i] == (seasonNo))
			Text += '<a index='+i+' count='+count+' id="ssList-'+i+'" class="btn btn-default btn-block btnCust imageFocus" >'+name+" - "+Object.keys(tvShowDetail.seasons)[i]+'</a>'		
		else{
			if((count - 12) > 0 && i < (count - 12))
				 Text += '<a index='+i+' count='+count+' style="display:none" id="ssList-'+i+'" class="btn btn-default btn-block btnCust" >'+name+" - "+ Object.keys(tvShowDetail.seasons)[i]+'</a>'
			else
				Text += '<a index='+i+' count='+count+' id="ssList-'+i+'" class="btn btn-default btn-block btnCust" >'+name+" - "+ Object.keys(tvShowDetail.seasons)[i]+'</a>'			
		}
		
	}
	 Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '</div>'

    return Text;
}

Util.showTimeZone = function(zone){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="timeZone-msg-cont">'
    Text += '<div class="row remove-margin">'
	Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
	var dataKeys = Object.keys(Main.timeZoneData);
	var focusIndex = 0;
	try{
		focusIndex = dataKeys.indexOf(Main.offset+"");
	}
	catch(e){
		console.log(e.message);
	}

	var j = 0;
	if(focusIndex+10 <= dataKeys.length)
		j = focusIndex;
	else
		j = dataKeys.length - 10;
    var count = 0;
	for(var i=0;i<dataKeys.length;i++){
		var key = dataKeys[i];
		var value = Main.timeZoneData[key];
		if(i >= j && count < 10){
			count++;
			Text += '<a index='+i+' count='+dataKeys.length+' id="timeList-'+i+'" class="btn btn-default btn-block btnCust" >'+value+'</a>'	
		}
		else
		     Text += '<a index='+i+' style="display:none" count='+dataKeys.length+' id="timeList-'+i+'" class="btn btn-default btn-block btnCust" >'+value+'</a>'	
	}
	 Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '</div>'

    return Text;
}
Util.showSubs = function(){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="timeZone-msg-cont">'
    Text += '<div class="row remove-margin">'
	Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
	Text += '<a index='+0+' source="listSubs" count='+Object.keys(Main.subTitles).length+' id="subsList-0" class="btn btn-default btn-block btnCust" >Hide</a>'	
	for(var i=0;i<Object.keys(Main.subTitles).length;i++){
		if(i < 10)
			 Text += '<a index='+(i+1)+' source="listSubs"  count='+Object.keys(Main.subTitles).length+' id="subsList-'+(i+1)+'" class="btn btn-default btn-block btnCust" >'+Object.keys(Main.subTitles)[i]+'</a>'	
		else
		     Text += '<a index='+(i+1)+' source="listSubs"  style="display:none" count='+Object.keys(Main.subTitles).length+' id="subsList-'+(i+1)+'" class="btn btn-default btn-block btnCust" >'+Object.keys(Main.subTitles)[i]+'</a>'	
	}
	 Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '</div>'

    return Text;
}
Util.showPopUp = function(no,title,desc,info1,info2){
    var Text = '';
    Text += '<div class="">'
    Text += '<div class="overlay-screen">'
    Text += '</div>'
    Text += '<div class="popup-Message-container popup-lg">'
    Text += '<h4 class="popup-subhead">'+title+'</h4>'
    Text += '<p class="popup-p" >'+desc
    Text += '</p>'
    Text +=   '<div class="col-md-12 col-lg-12 col-xl-12 remove-padding popup-btn-wrap mt30">'
    if(no == 2){
        
        Text +=     '<a id="Btn-0" class="popUpBtn popUpBtn-orange remove-margin" index="0">'+info1+'</a>'
        Text +=     '<a id="Btn-1" class="popUpBtn  ml30  remove-margin" index="1">'+info2+'</a>'
        
    }
    else if(no == 1){
            Text +=     '<a id="Btn-0" index = "0" class="popUpBtn-orange popUpBtn remove-margin">'+info1+'</a>'
    }
    else {
        
    }
    Text +=   '</div>  '
    Text +=   ''
    Text += '</div>'
    Text += ''
    Text += '</div>'
return Text;
}
Util.signIn = function(){
	var Text = "";
	
	Text += '<div class="login-page">'
	Text += '     <div id="loading"  class="cssload-container loader-bg" style="display:none;z-index: 999;">'
	Text += '      <div id="loadingImg">'
	Text += '	     	<div class="loader-img" id="loadingText">Loading..</div> '
	Text += '	     	<img src="images/Spin.png" class="imgLoader" />'
	Text += '     	</div>'
	Text += '     </div>'
	Text += '        <div class="login-container">'
	Text += '            <div class="center-wrap">'
	Text += '                <div class="login-logo"><img src="images/logo.png"/></div>'
	Text += '                <div class="login-form">'
	Text += '                    <div class="login-header">Login</div>'
	Text += '                    <div class="login-content">'
	Text += '                        <form>'
	Text += '                            <div class="form-group">'
	Text += '                                <input type="text" placeholder="Email" maxlength = "20"  id="email" value="" class="form-control signin imageFocus"/>'
	Text += '                            </div>'
	Text += '                            <div class="form-group">'
	Text += '                                <input type="password" placeholder="Password" id="password" value=""  maxlength = "15"  class="form-control signin"/>'
	Text += '                            </div>'
	Text += '                            <div class="btn-action">'
	Text += '                                <b type="submit"  id="login"  class="btn blue-btn">Login</b>'
	Text += '                            </div>'
	Text += '                        </form>'
	Text += '                    </div>'
	Text += '                </div>'
	Text += '            </div>'
	Text += '        </div>'
	Text += '    </div>'
	
	return Text;
}

Util.adultPage = function(adultObj){
	var Text = '';

	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("adult");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class= "header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">ADULT</h1></div>'
			//Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div id="navBar"><div class="container"><ul class="menuHorizontal">'
			
			
			Text += '<li  id="adultTopMenu-0" index=0 class="menuSelected" source="topMenu" >Movies</li>'
			Text += '<li  id="adultTopMenu-1"  index=1  class="" source="topMenu">Channels</li>'
			
						
			
			Text +='</ul></div></div>';
                        Text += '<div class="inner-wrap">'
			Text += '<div id="adultList">'        
			
			Text += '<div class="center-layout">'
			var rowID = 0;
			
			if(adultObj.movies.length){
				for(var i=0;i<adultObj.movies.length;i++){
					
						var v_index = Math.floor(i/5);
						var h_index = i % 5;
						//if(v_index < 2){
							if(h_index == 0){
								Text += "<div id='adultRow-"+v_index+"' class='row'>";
							}
							Text +="<div class='col-5-eq'>"
							//Text += Util.generatetvShowCard(watchlistMap["tvshow"][i],v_index,h_index,i,watchlistMap["tvshow"].length);
							Text += Util.adultMovieCard(adultObj.movies[i],v_index,h_index,i,adultObj.movies.length);
							Text +="</div>"
							if(h_index == 4){
								Text += "</div>"
							}
					//	}
				}
			}
			else if(adultObj.channels){
				for(var i=0;i<adultObj.channels.length;i++){
					
					var v_index = Math.floor(i/5);
					var h_index = i % 5;
				//	if(v_index < 2){
						if(h_index == 0){
							Text += "<div id='adultRow-"+v_index+"' class='row'>";
						}
						Text +="<div class='col-5-eq'>"
						Text += Util.generateLiveCard(adultObj.channels[i],v_index,h_index,i,adultObj.channels.length);
						Text +="</div>"
						if(h_index == 4){
							Text += "</div>"
						}
				//	}
				}
			}
			else{
				Text += '<p class="noWatchList">No Movies / Shows / Channels Added.</p>' ;
			}
			Text += "</div>"

			Text +='</div >';
            Text +='</div >';

		Text += '</div>';
	Text += '</div>';

	return Text;
}
Util.adultLive = function(){
    var Text = '';
	Text += '<div class="center-layout">'
	for(var i=0;i<adultArray.channels.length;i++){
		
		var v_index = Math.floor(i/5);
		var h_index = i % 5;
	
			if(h_index == 0){
				Text += "<div id='adultRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generateLiveCard(adultArray.channels[i],v_index,h_index,i,adultArray.channels.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>"
			}
	
	}

	return Text;
}
Util.adultMovies = function(){
    var Text = '';
	Text += '<div class="center-layout">'
	for(var i=0;i<adultArray.movies.length;i++){
		
			var v_index = Math.floor(i/5);
			var h_index = i % 5;
			//if(v_index < 2){
				if(h_index == 0){
					Text += "<div id='adultRow-"+v_index+"' class='row'>";
				}
				Text +="<div class='col-5-eq'>"
				Text += Util.generateMovieCard(adultArray.movies[i],v_index,h_index,i,adultArray.movies.length);
				Text +="</div>"
				if(h_index == 4){
					Text += "</div>"
				}
		//	}
	}

	return Text;
}
var movie = false,show = false,channel = false;
Util.watchListHTML = function(){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("watchList");

	    movie = false;show = false;channel = false;
		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class= "header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Watch List</h1></div>'
		//	Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" id="searchBox" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div id="navBar"><div class="container"><ul class="menuHorizontal">'
			
			if(watchlistMap["movies"].length){
				Text += '<li  id="watchListTopMenu-0" index=0 class="menuSelected" source="topMenu" >Movies</li>'
				movie = true;
			}
			if(watchlistMap["tvshow"].length)	{
				if(!movie)
					Text += '<li  id="watchListTopMenu-1" index=1   class="menuSelected"  source="topMenu">TV Shows</li>'	
				else
					Text += '<li  id="watchListTopMenu-1" index=1   class=""  source="topMenu">TV Shows</li>'			
				show = true;	
			}
			if(watchlistMap["channel"].length)	{
				if(!movie && !show)
					Text += '<li  id="watchListTopMenu-2"  index=2  class="menuSelected" source="topMenu">Channels</li>'
				else
					Text += '<li  id="watchListTopMenu-2"  index=2  class="" source="topMenu">Channels</li>'
				channel = true;
			}	
						
			
			Text +='</ul></div></div>';
                        Text += '<div class="inner-wrap">'
			Text += '<div id="watchList">'        
			
			Text += '<div class="center-layout">'
			var rowID = 0;
			/* if(!channel && !show && !channel){
				
			} */
			if(movie){
				for(var i=0;i<watchlistMap["movies"].length;i++){
					
						var v_index = Math.floor(i/5);
						var h_index = i % 5;
						//if(v_index < 2){
							if(h_index == 0){
								Text += "<div id='watchRow-"+v_index+"' class='row'>";
							}
							Text +="<div class='col-5-eq'>"
							Text += Util.generateMovieCard(watchlistMap["movies"][i],v_index,h_index,i,watchlistMap["movies"].length);
							//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
							Text +="</div>"
							if(h_index == 4){
								Text += "</div>"
							}
					//	}
				}
			}
			else if(show){
				for(var i=0;i<watchlistMap["tvshow"].length;i++){
					
									var v_index = Math.floor(i/5);
									var h_index = i % 5;
								//	if(v_index < 2){
										if(h_index == 0){
											Text += "<div id='watchRow-"+v_index+"' class='row'>";
										}
										Text +="<div class='col-5-eq'>"
										Text += Util.generatetvShowCard(watchlistMap["tvshow"][i],v_index,h_index,i,watchlistMap["tvshow"].length);
										//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
										Text +="</div>"
										if(h_index == 4){
											Text += "</div>"
										}
								//	}
								}
			}
			else if(channel){
				for(var i=0;i<watchlistMap["channel"].length;i++){
					
					var v_index = Math.floor(i/5);
					var h_index = i % 5;
				//	if(v_index < 2){
						if(h_index == 0){
							Text += "<div id='watchRow-"+v_index+"' class='row'>";
						}
						Text +="<div class='col-5-eq'>"
						Text += Util.generateLiveCard(watchlistMap["channel"][i],v_index,h_index,i,watchlistMap["channel"].length);
						Text +="</div>"
						if(h_index == 4){
							Text += "</div>"
						}
				//	}
				}
			}
			else{
				Text += '<p class="noWatchList">No Movies / Shows / Channels Added.</p>' ;
			}
			Text += "</div>"


			/* for(var i=0;i<homeData.length && i < 4;i++){
					Text += Util.generateMovieCard(homeData[i],i,homeData.length);
			} */
			Text +='</div >';
                        Text +='</div >';

			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	
    return Text;
}

Util.getWatchListDivHTML = function(type){
	var Text = '';
	Text += '<div class="center-layout">';
	if(type == "movie"){
		for(var i=0;i<watchlistMap["movies"].length;i++){
			
				var v_index = Math.floor(i/5);
				var h_index = i % 5;
				//if(v_index < 2){
					if(h_index == 0){
						Text += "<div id='watchRow-"+v_index+"' class='row'>";
					}
					Text +="<div class='col-5-eq'>"
					Text += Util.generateMovieCard(watchlistMap["movies"][i],v_index,h_index,i,watchlistMap["movies"].length);
					//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
					Text +="</div>"
					if(h_index == 4){
						Text += "</div>"
					}
			//	}
		}
	}
	else if(type == "show"){
		for(var i=0;i<watchlistMap["tvshow"].length;i++){
			
							var v_index = Math.floor(i/5);
							var h_index = i % 5;
						//	if(v_index < 2){
								if(h_index == 0){
									Text += "<div id='watchRow-"+v_index+"' class='row'>";
								}
								Text +="<div class='col-5-eq'>"
								Text += Util.generatetvShowCard(watchlistMap["tvshow"][i],v_index,h_index,i,watchlistMap["tvshow"].length);
								//Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
								Text +="</div>"
								if(h_index == 4){
									Text += "</div>"
								}
						//	}
						}
	}
	else if(type == "live"){
		for(var i=0;i<watchlistMap["channel"].length;i++){
			
			var v_index = Math.floor(i/5);
			var h_index = i % 5;
		//	if(v_index < 2){
				if(h_index == 0){
					Text += "<div id='watchRow-"+v_index+"' class='row'>";
				}
				Text +="<div class='col-5-eq'>"
				Text += Util.generateLiveCard(watchlistMap["channel"][i],v_index,h_index,i,watchlistMap["channel"].length);
				Text +="</div>"
				if(h_index == 4){
					Text += "</div>";
				}
		//	}
		}
	}
	else{
		Text += '<p class="noWatchList">No Movies / Shows / Channels Added.</p>' ;
	}
	Text += '<div>';
	return Text;
}
Util.displayTime = function(){
  var Text = '';
  Text +='<div class="time_bar" id="timeBar" source ="timeBar">'
   //for(var x = 0;x<dates.length;x++){
      
      for(var y=0;y<timeArray.length;y++){
          Text +='<div class="time_period" ><span class="time_period" >'+timeArray[y]+'</span></div>'//id="timeArray_'+x+'_'+y+'"
      }
      //Text += '</div>'
  //}
  Text += '</div>'
    
   return Text;
}
String.prototype.replaceBetween = function(start, end, what) {
    return this.substring(0, start) + what + this.substring(end);
};
Util.getCurrentEPGList = function(currentdate,index) {
	if(tvGuideProgramsList.length){
		for(var cIndex = index ; cIndex < tvGuideProgramsList.length; cIndex++){
			var programsList = [];
			for(var pIndex = 0; pIndex < tvGuideProgramsList[cIndex].programme.length ; pIndex++){
				var s_year = tvGuideProgramsList[cIndex].programme[pIndex].start.substring(0,4);
				var s_month = tvGuideProgramsList[cIndex].programme[pIndex].start.substring(4,6);
				var s_day = tvGuideProgramsList[cIndex].programme[pIndex].start.substring(6,8);

				var s_time = tvGuideProgramsList[cIndex].programme[pIndex].start.substring(8,10) + ':'+
							tvGuideProgramsList[cIndex].programme[pIndex].start.substring(10,12);

				//var timeZone = tvGuideProgramsList[pIndex].programme[pIndex].start.split(' ')[1]

				var e_year = tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(0,4);
				var e_month = tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(4,6);
				var e_day = tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(6,8);

				var e_time = tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(8,10) + ':'+
							tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(10,12);

				var s_dateTime = s_year+'-'+s_month+'-'+s_day+' '+s_time;
				var e_dateTime = e_year+'-'+e_month+'-'+e_day+' '+e_time;

				var timeDiffSec = (new Date(e_dateTime).getTime() - new Date(s_dateTime).getTime())/1000;

				/*if(new Date(currentdate).getDate() == new Date(s_dateTime).getDate()){
					var obj = tvGuideProgramsList[cIndex].programme[pIndex];
					obj.startDate = s_dateTime;
					obj.endDate = e_dateTime;
					obj.timeDiffSec = timeDiffSec;
					obj.startTime = s_time;
					obj.endTime = e_time;
					programsList.push(obj);
				}else if(new Date(s_dateTime) > new Date()){
					var obj = tvGuideProgramsList[cIndex].programme[pIndex];
					obj.startDate = s_dateTime;
					obj.endDate = e_dateTime;
					obj.timeDiffSec = timeDiffSec;
					obj.startTime = s_time;
					obj.endTime = e_time;
					programsList.push(obj);
					
				
				}*/
				if(new Date(currentdate).getDate() == new Date(s_dateTime).getDate()){
					var obj = tvGuideProgramsList[cIndex].programme[pIndex];
					obj.startDate = s_dateTime;
					obj.endDate = e_dateTime;
					obj.timeDiffSec = timeDiffSec;
					obj.startTime = s_time;
					obj.endTime = e_time;
					programsList.push(obj);
				}
				else if(new Date(currentdate).getDate() == new Date(e_dateTime).getDate() &&
				 (tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(8,10) > 0 || tvGuideProgramsList[cIndex].programme[pIndex].stop.substring(10,12) > 0)){
					var obj = tvGuideProgramsList[cIndex].programme[pIndex];
					var s_dateTime = e_year+'-'+e_month+'-'+e_day+' 00:00';
					var e_dateTime = e_year+'-'+e_month+'-'+e_day+' '+e_time;
					var timeDiffSec = (new Date(e_dateTime).getTime() - new Date(s_dateTime).getTime())/1000;
					
					obj.start = obj.start.replaceBetween(8,10,'00')
					obj.startDate = s_dateTime;
					obj.endDate = e_dateTime;
					obj.timeDiffSec = timeDiffSec;
					obj.startTime = "00:00";
					obj.endTime = e_time;
					programsList.push(obj);
				}
				else if(new Date(s_dateTime).getDate() > Main.getOffsetDate().getDate)
					break;
			}
			tvGuideCurrentList.push(programsList);
		}
	}
}

var previousStartDate = '';
Util.updateEPGList = function(){
	var Text = '';
	$today = Main.getOffsetDate();
	var startIndex = tvGuideCurrentList.length;
	Util.getCurrentEPGList(epgSelectedDate,tvGuideCurrentList.length);
	if(tvGuideCurrentList.length>0){
			  for(var a = startIndex ;a< tvGuideCurrentList.length;a++){
			    Text +='<div id="entireDataRow_'+a+'">'
			    Text +='<div class="pro_cha_row" id= "epgData_'+a+'">'
			    for(var x = 0 ;x<tvGuideCurrentList[a].length;x++){
			    

			     var curent_prog_Start_Time = tvGuideCurrentList[a][x].startDate;
			     var curent_prog_End_Time = tvGuideCurrentList[a][x].endDate;
			      var current_Time = tvGuideCurrentList[a][x].startDate;
			      
			       if(Main.getOffsetDate()>=new Date(curent_prog_Start_Time) && Main.getOffsetDate()<=new Date(curent_prog_End_Time)){
			          currentActive_prog_id[a] = x; // current Porgarm index
			          if(a==0)
			            selceted_prog_id = "epgData_"+a+'_'+x;
			        }
		        	else if(Main.getOffsetDate().getDay() != epgSelectedDate.getDay())
		        		currentActive_prog_id[a] = 0;

			        var seconds = tvGuideCurrentList[a][x].timeDiffSec;//console.log(seconds);
			        pxToScroll = pxToScroll + seconds;

			        if(window_Width <= 1280){
			        	if(seconds>=1800){
				          Text +='<div class="prog_info" id = "epgData_'+a+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+' index = '+x+' rowIndx = '+a+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+' style="width:'+ seconds/10 +'px">'
				          Text +='<div class="prog_info_inner"  id = "epgData_'+a+'_'+x+'" index = '+x+' rowIndx = '+a+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+'>'
				          Text +='<div class="prog_border"></div><div class="show_titles"  style="left:10px;">'
				          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
				          Text +='</div>'
				          Text +='</div>'
				          Text +='</div>'
				        }else {
				          Text +='<div class="prog_info"   id = "epgData_'+a+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+'  index = '+x+' rowIndx = '+a+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+' style="width:'+ seconds/10 +'px">'
				          Text += '<div class="prog_info_inner"   id = "epgData_'+a+'_'+x+'" index = '+x+' rowIndx = '+a+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+' >'
				          Text +='<div class="prog_border"></div><div class="show_titles show_titles_sm" style="left:10px;">'
				          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
				          Text +='</div>'
				          Text +='</div>'
				          Text +='</div>'
				        }
			        }else{
			        	if(seconds>=1800){
				          Text +='<div class="prog_info" id = "epgData_'+a+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+' index = '+x+' rowIndx = '+a+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+' style="width:'+ seconds/6 +'px">'
				          Text +='<div class="prog_info_inner"  id = "epgData_'+a+'_'+x+'" index = '+x+' rowIndx = '+a+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+'>'
				          Text +='<div class="prog_border"></div><div class="show_titles"  style="left:10px;">'
				          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
				          Text +='</div>'
				          Text +='</div>'
				          Text +='</div>'
				        }else {
				          Text +='<div class="prog_info"   id = "epgData_'+a+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+'  index = '+x+' rowIndx = '+a+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+' style="width:'+ seconds/6 +'px">'
				          Text += '<div class="prog_info_inner"   id = "epgData_'+a+'_'+x+'" index = '+x+' rowIndx = '+a+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+' >'
				          Text +='<div class="prog_border"></div><div class="show_titles show_titles_sm" style="left:10px;">'
				          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
				          Text +='</div>'
				          Text +='</div>'
				          Text +='</div>'
				        }
			        }
			        
			    }
			    if(!tvGuideCurrentList[a].length){
		    	//Text += '<div class="dataNoAvialable" index = '+x+' rowIndx = '+s+' source ="prgrams_data">No Data Available For Selected Section</div>';
			    	Text +='<div class="prog_info nodata"   id = "epgData_'+a+'_'+x+'"   index = '+x+' rowIndx = '+a+' source ="prgrams_data" >'
			          Text += '<div class="prog_info_inner"   id = "epgData_'+a+'_'+x+'" index = '+x+' rowIndx = '+a+' source ="prgrams_data" >'
			          Text +='<div class="prog_border"></div><div class="show_titles show_titles_sm" style="left:10px;">'
			          Text +='<div class="prog_title"">No Data Available For Selected Section</div>'
			          Text +='</div>'
			          Text +='</div>'
			          Text +='</div>'
			          currentActive_prog_id[a] = 0;
			    }
			    Text +='</div>'
			    Text +='</div>'
			  }
			}else{
			  Text += '<div class="dataNoAvialable">No Data Available For Selected Section</div>';
			}
		return Text;	
}	
Util.displayDateFormat = function(epgSelectedDate){
	var date = epgSelectedDate;
	var dayName = date.toString().split(' ')[0];
	return dayName+','+ monthFullNames[date.getMonth()]+' '+date.getDate()+','+date.getFullYear();

}
var tvGuideCurrentList = [];
var pxToScroll = 0;
Util.homeTVGuidepage = function(data){

	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("tvGuide");

		Text += '<div  class="col-sm-11 inner-content no-padding" >';
		Text += '<div  class= "header clearfix" id="heading" >'
		Text += '<div  class="container">'	
		Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
		Text += '<div class="col-sm-4 text-center"><h1 class="main-title">TV GUIDE</h1></div>'
		Text += '<div class="form-search navItem floatRight col-sm-2 p-right">'
		Text += '<button id="changeDate" class="dateSlection" source="dates">'+formatDate(epgSelectedDate)+'</button'
		Text += '</div>'
		Text += '</div>'
		Text += '</div>'
		Text += '</div>'

			 Text +='<div class="list_vertical">'
			 Text +='<span class="list_shadow"></span>'

			 Text += '<div  id="navBar" ><div class="container"><ul class="menuHorizontal">'
			var classToAdd = '';
			for (var i=0;i<topMenu["tvGuide"].length;i++){
				classToAdd = '';
				
				if(topMenu["tvGuide"][i].name.length > 13)
					classToAdd = "namescroll";
				if(i == 0){
					Text += '<li  id="tvGuideTopMenu-'+i+'" count='+topMenu["tvGuide"].length+' class="guideMenuSelected" source="topMenu" index='+i+' attrId="'+topMenu["tvGuide"][i].id+'"><p class="'+classToAdd+'">'+topMenu["tvGuide"][i].name+'</li>'					
				}
				else if(i < 10){
					Text += '<li  id="tvGuideTopMenu-'+i+'" count='+topMenu["tvGuide"].length+' source="topMenu" index='+i+' attrId="'+topMenu["tvGuide"][i].id+'"><p class="'+classToAdd+'">'+topMenu["tvGuide"][i].name+'</li>'					
				}
				else{
					Text += '<li  id="tvGuideTopMenu-'+i+'" style="display:none" count='+topMenu["tvGuide"].length+' source="topMenu" index='+i+' attrId="'+topMenu["tvGuide"][i].id+'"><p class="'+classToAdd+'">'+topMenu["tvGuide"][i].name+'</li>'					
				}
			}
			
			Text +='</ul></div></div>';
			Text += Util.epgProgramSection(data);
		Text += '</div>'
		Text += '</div>'
		Text += '</div>'
	Text += '</div>';

	
    return Text;
}
Util.epgProgramSection = function(data){
	var Text = '';
	Text +='<div class="list_of_channels">'

		   Text +='<div id="goCurrentTime" class="channels_live_tag_cont" source = "goLive">'
		     Text +='<div class="prog_border"></div><span id="goLiveButton" class="tag normal" >'+Util.displayDateFormat(epgSelectedDate)+'</span>'//
		   Text +='</div>'
		 for(var f=0;f<data.length;f++){
		    Text +='<div class="channel" index = '+f+' id="channel_'+f+'" source = "channels" targetPath = '+data[f].logo+'>'
		    Text += '<div class="row">'
		    //Text += '<div class="col-sm-2 nopadding">'+(f+1)+'</div>'
		    Text += '<div class="col-sm-12 channelName">'+data[f].name+'</div>'
		    Text += '</div>'
		    Text +='</div>'
		 }
		Text +='</div>'

		Text += '<div class="programs_list"><div class="prog_list_width"><div id="liveBar" class="live_bar"><span>Now Live</span></div>'
		Text +='<div class="channels_time_header">'

		Text+=Util.displayTime();

		Text +='</div>'


		$today = Main.getOffsetDate();
		/*$yesterday = new Date($today);
		$yesterday.setDate($today.getDate() - 1);*/

		Util.getCurrentEPGList(epgSelectedDate,0);
		var s = 0;

		if(tvGuideCurrentList.length>0){
		  for(var a = 0 ;a< tvGuideCurrentList.length;a++){
		    Text +='<div id="entireDataRow_'+a+'">'
		    Text +='<div class="pro_cha_row" id= "epgData_'+a+'">'
		    for(var x = 0 ;x<tvGuideCurrentList[a].length;x++){
		    

		     var curent_prog_Start_Time = tvGuideCurrentList[a][x].startDate;
		     var curent_prog_End_Time = tvGuideCurrentList[a][x].endDate;
		      var current_Time = tvGuideCurrentList[a][x].startDate;
		      
		       if(Main.getOffsetDate()>=new Date(curent_prog_Start_Time) && Main.getOffsetDate()<=new Date(curent_prog_End_Time)){
		          currentActive_prog_id[s] = x; // current Porgarm index
		          if(s==0)
		            selceted_prog_id = "epgData_"+s+'_'+x;
		        }
		        else if(Main.getOffsetDate().getDay() != epgSelectedDate.getDay())
		        	currentActive_prog_id[s] = 0;
		        var seconds = tvGuideCurrentList[a][x].timeDiffSec;//console.log(seconds);
		        pxToScroll = pxToScroll + seconds;

		        if(window_Width <= 1280){
		        	if(seconds>=1800){
			          Text +='<div class="prog_info" id = "epgData_'+s+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+' index = '+x+' rowIndx = '+s+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+' style="width:'+ seconds/10 +'px">'
			          Text +='<div class="prog_info_inner"  id = "epgData_'+s+'_'+x+'" index = '+x+' rowIndx = '+s+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+'>'
			          Text +='<div class="prog_border"></div><div class="show_titles"  style="left:10px;">'
			          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
			          Text +='</div>'
			          Text +='</div>'
			          Text +='</div>'
			        }else {
			          Text +='<div class="prog_info"   id = "epgData_'+s+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+'  index = '+x+' rowIndx = '+s+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+' style="width:'+ seconds/10 +'px">'
			          Text += '<div class="prog_info_inner"   id = "epgData_'+s+'_'+x+'" index = '+x+' rowIndx = '+s+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/10+' >'
			          Text +='<div class="prog_border"></div><div class="show_titles show_titles_sm" style="left:10px;">'
			          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
			          Text +='</div>'
			          Text +='</div>'
			          Text +='</div>'
			        }
		        }else{
		        	if(seconds>=1800){
			          Text +='<div class="prog_info" id = "epgData_'+s+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+' index = '+x+' rowIndx = '+s+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+' style="width:'+ seconds/6 +'px">'
			          Text +='<div class="prog_info_inner"  id = "epgData_'+s+'_'+x+'" index = '+x+' rowIndx = '+s+'  source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+'>'
			          Text +='<div class="prog_border"></div><div class="show_titles"  style="left:10px;">'
			          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
			          Text +='</div>'
			          Text +='</div>'
			          Text +='</div>'
			        }else {
			          Text +='<div class="prog_info"   id = "epgData_'+s+'_'+x+'" currentProgIndex = '+tvGuideCurrentList[a][x].startDate+' progStartTimeIndex = '+curent_prog_Start_Time+' progEndTimeIndex = '+curent_prog_End_Time+'  index = '+x+' rowIndx = '+s+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+' style="width:'+ seconds/6 +'px">'
			          Text += '<div class="prog_info_inner"   id = "epgData_'+s+'_'+x+'" index = '+x+' rowIndx = '+s+' source ="prgrams_data" duration = '+seconds+' scroolToposition = '+pxToScroll/6+' >'
			          Text +='<div class="prog_border"></div><div class="show_titles show_titles_sm" style="left:10px;">'
			          Text +='<div class="prog_title"">'+tvGuideCurrentList[a][x].title+'</div>'
			          Text +='</div>'
			          Text +='</div>'
			          Text +='</div>'
			        }
		        }
		        
		    }
		    if(!tvGuideCurrentList[a].length){
		    	//Text += '<div class="dataNoAvialable" index = '+x+' rowIndx = '+s+' source ="prgrams_data">No Data Available For Selected Section</div>';
		    	Text +='<div class="prog_info nodata"   id = "epgData_'+s+'_'+x+'"   index = '+x+' rowIndx = '+s+' source ="prgrams_data" >'
		          Text += '<div class="prog_info_inner"   id = "epgData_'+s+'_'+x+'" index = '+x+' rowIndx = '+s+' source ="prgrams_data" >'
		          Text +='<div class="prog_border"></div><div class="show_titles show_titles_sm" style="left:10px;">'
		          Text +='<div class="prog_title"">No Data Available For Selected Section</div>'
		          Text +='</div>'
		          Text +='</div>'
		          Text +='</div>'
		          currentActive_prog_id[s] = 0;
		    }
		    Text +='</div>'
		    Text +='</div>'
		    s++;
		  }
		}else{
		  Text += '<div class="dataNoAvialable">No Data Available For Selected Section</div>';
		}


		Text +='</div>'
		
		//Text +='</div>';
	Text += '</div>'
	Text += '<div class="epg_prog_desc col-sm-12">'
	Text += '<div class="col-sm-2">'
	Text += '<img  id="epg_channel_img" src=""    onerror="this.src=\'images/livetv-error.jpg\';" >'
	Text += '</div>'
	Text += '<div class="col-sm-10">'	
	Text += '<div class="epg_Info">'
	Text += '<label id="epg_prog_dur"></label>'
	Text += '<label id="epg_prog_title"></label>'
	Text += '</div>'
	Text += '<div class="epg_Info" id="epg_prog_desc"></div>'
	return Text;

}
Util.showDatesPopUp = function(){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="info-msg-cont">'
    Text += '<div class="row remove-margin">'
	Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
	var count = 7
	for(var i=0;i<count;i++){
    	var myDate = Main.getOffsetDate();
    	myDate.setDate(myDate.getDate()+i);
		if(epgSelectedDate.getDay() == myDate.getDay())
			Text += '<a index='+i+' count='+count+' id="ssList-'+i+'" class="btn btn-default btn-block btnCust imageFocus" >'+formatDate(myDate)+'</a>'		
		else{
			if((count - 12) > 0 && i < (count - 12))
				 Text += '<a index='+i+' count='+count+' style="display:none" id="ssList-'+i+'" class="btn btn-default btn-block btnCust" >'+formatDate(myDate)+'</a>'
			else
				Text += '<a index='+i+' count='+count+' id="ssList-'+i+'" class="btn btn-default btn-block btnCust" >'+formatDate(myDate)+'</a>'			
		}
		
	}
	 Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '</div>'

    return Text;
}
