
var Player = {
	streams: [],url :''
};
var media = '',catgIndex  = 0,liveChnlIndex = 0,playObj = {},previousFocus = '';
var sType = 1,firstTime = true;
var dur = '';
function getTimeText(t) {
	t = t / 1000;
	var pt = new Number(t) ;
	var hh = Math.floor(pt / 3600);
	var mm = Math.floor((pt % 3600) / 60);
	
	return "" + (hh < 10 ? "0" + hh : hh) + ":" + (mm < 10 ? "0" + mm : mm);
}
function progressIconHandle(event, action) {
	console.log(event.type)
	switch (action) {
	case 'over':
		$("#seek-picker-runtime").show();
		moveSeekBall(event);
		addEvent(document, "mousemove", moveSeekBall);
		break;
	case 'out':
		$("#seek-picker-runtime").hide();
		removeEvent(document, "mousemove", moveSeekBall);
		break;
	case 'click':
		playAtPos(event);
		break;
	case 'down':
		playAtPos(event);
		break;
	default:
		break;
	}
}

function addEvent(object, eventStr, func) {
	try {
		object.addEventListener(eventStr, func, false);
	} catch (e) {
	}
}

function removeEvent(object, eventStr, func) {
	try {
		object.removeEventListener(eventStr, func);
	} catch (e) {
	}
}
function playAtPos(event){
	var x = event.clientX - $("#flix-seekbar").offset().left - 8 ;
	
	dur = media.getDuration();
	try{
		if(media.getDuration() == -1){
			if(singleMoviePage && singleMoviePage.vendorInfo && singleMoviePage.vendorInfo.duration){
				dur = singleMoviePage.vendorInfo.duration;
				dur = dur*1000;
			}
				
		}
	}catch(e){}
	
	var totalWidth = $("#flix-seekbar").width();
	var seekPercent = 0;
	if(x > 0){
		seekPercent = ((x) / totalWidth);
		$("#seek-picker-runtime").css("left",event.clientX - ($("#flix-seekbar").offset().left ) + 280);
		var pos = dur * seekPercent;
		$("#seek-picker-runtime").html(getTimeHMS(pos));
		media.seekTo(pos);
		
	}
	
}
function moveSeekBall(event) {
	console.log(event.type);
	
	dur = media.getDuration();
	try{
		if(media.getDuration() == -1){
			if(singleMoviePage && singleMoviePage.vendorInfo && singleMoviePage.vendorInfo.duration){
				dur = singleMoviePage.vendorInfo.duration;
				dur = dur*1000;
			}
				
		}
	}catch(e){}
	
	var x = event.clientX - $('#flix-seekbar').position().left - 8 ;
	var totalWidth = $("#flix-seekbar").width();
	var seekPercent = ((x) / totalWidth);
	var pos  = seekPercent * dur;
	if(x > 0 && x <= totalWidth){
		$("#seek-picker-runtime").css("left",(event.clientX - ($("#flix-seekbar").offset().left) ) + 280);
		$("#seek-picker-runtime").html(getTimeHMS(pos));
	}
	else
		$("#seek-picker-runtime").hide();
}
function getTimeHMS(t) {
	t = t / 1000;
	var pt = new Number(t) ;
	var hh = Math.floor(pt / 3600);
	var mm = Math.floor((pt % 3600) / 60);
	var ss = Math.floor(pt % 60);
	return "" + (hh < 10 ? "0" + hh : hh) + ":" + (mm < 10 ? "0" + mm : mm)
			+ ":" + (ss < 10 ? "0" + ss : ss);
}
Player.playStream = function(url){
	$("#HTML5Div").html(Util.playerBody());$(".play-icons").hide();
	
	try{
		if(media){
			clearPlayerValues();
		}
	}
	catch(e){}
	
	
	media = toast.Media.getInstance();$("#HTML5Div").show();$(".player").hide();
	 if(Player.type == "movie"){
		Main.getSubTitles("movie");
	 }
	 else if(Player.type == "live"){
		$(".play-icons").hide();
		$(".player").hide();
	 }
	 else{
		Main.getSubTitles("show",Player.season,Player.eps);
	 }
    
    hideArrows();
	 //$("#loadingText").html(playObj.name);
	 Main.ShowLoading();
	 media.setListener({
		onevent: function (evt) {
			switch(evt.type) {
				case "STATE":
					console.log("Media State changed: " + evt.data.oldState + " -> " + evt.data.state);

					if(evt.data.oldState != 'STALLED' && evt.data.state == 'STALLED'){
						 document.getElementById('log').innerHTML = 'Buffering is started';
						// Main.ShowLoading();
					 }
					 else if(evt.data.oldState == 'STALLED' && evt.data.state != 'STALLED'){
						 document.getElementById('log').innerHTML = 'Buffering is ended';
						// Main.HideLoading();
					 }
					break;
				case "DURATION":
					console.log("Media duration updated: " + evt.data.duration + "ms");
					break;
				case "POSITION":
					console.log("Media position updated: " + evt.data.position + "ms");
					var dur = media.getDuration();
					try{
						if(media.getDuration() == -1){
							/* if(singleMoviePage && singleMoviePage.vendorInfo && singleMoviePage.vendorInfo.duration){
								dur = singleMoviePage.vendorInfo.duration;
								dur = dur*1000;
							} */
								
						}
					}catch(e){}
					document.getElementById('flix-seekbar-run').style.width = Number(evt.data.position * 100 / dur) + '%';
					$('#seek-picker').css("left",((Number(evt.data.position * 100 / dur) - 1 )) + '%');
					$('#seek-picker-start').html(getTimeHMS(evt.data.position));
					$('#seek-picker-end').html(getTimeHMS(dur));
					$("#beforePlayer").hide();
                         Main.HideLoading();
                         Main.playerHideLoading();
					break;
				case "BUFFERINGPROGRESS":
                    try{
                         if(view == "player"){
                              //Main.ShowLoading();
                              if(evt.data.bufferingPercentage < 98){
                                   bufferState = 1;
                              }
                              else{
                                   bufferState = 0;
                              }
                              //Yup("#loadingText").html("Loading ( "+evt.data.bufferingPercentage+" %) ");
                              //Yup('#playerLog').html('Buffering is ' + evt.data.bufferingPercentage + '%');
                              $('#loadPercent').html(evt.data.bufferingPercentage + '%');
                              media._containerElem.hidden = false;
                         }
                    }catch(e){}
					break;
				case "SUBTITLE":
					console.log("Media subtitle text: " + evt.data.text);
					break;
				case "ENDED":
					Player.processBack();
                         break;
                    case "ERROR":{
                         
                    }
			}
		},
		onerror: function (err) {
			$("#beforePlayer").hide();
			Main.showFailure("Stream error occured");
			callBack = function(){
				Player.processBack();
			}
		}
	 });

	//Player.url = "http://167-114-27-133.89to.com:8082/vod/6MAB5TaZ25Wyb2HxDEzC0Q/1540127083/KNPR3ziYIBvxTes1HbsSKsgpock7n2ZkI9nOQ3k1spWGB4EjeTOTh0Pio7ZUyslMxemKV3NDp7TNfzmmA.mp4";
    media.open(Player.url);
 
 	var elContainer = media.getContainerElement();

	// OPTION 1: Let's set the render area to full screen.
	elContainer.style.position = 'fixed';
	elContainer.id = 'renderarea';
	elContainer.style.left = '0%';
	elContainer.style.top = '0%';
	elContainer.style.width = '100%';
	elContainer.style.height = '100%' ;
	//document.body.appendChild(elContainer);
	
	// OPTION 2: Instead of attaching the container to body,
	//           you can append the 'elContainer' to any other DOM element to show the video in partial screen like below:
	var elPlayer = document.getElementById("videoDiv");
		// .renderarea style could be pre-defined with CSS.
	elPlayer.appendChild(elContainer);
	/*try{
		$('object').css("height","720px");
		$('object').css("width","1280px");
	}catch(e){}*/
	elPlayer.style.display = "block";
	$("#HTML5Div").show();
	$("#player").hide();
     media.play();
     if(intervalNetwork){
          clearInterval(intervalNetwork);intervalNetwork = '';
     }
     intervalNetwork = setInterval(function(){
          chknetwork();

     },1000);
	if(playBarInterval){
		clearInterval(playBarInterval);playBarInterval = '';
	}
	playBarInterval = setInterval(function(){$(".player").hide();$(".play-icons").hide();},4000);
}
var intervalNetwork = '';
var playBarInterval = '',seekTime = 0,seekTimer = '';
var jumpNum = 45000;
var loadingTimeArray = [];
function chknetwork(){
               if(media){
                    var player = media;
				var obj = {};
				if (!player.paused) {
					loadingTimeArray.push(media.getCurrentPosition());
					if (loadingTimeArray.length > 10) {
						loadingTimeArray.shift();
					}
				}
				for (var i = 0, j = loadingTimeArray.length; i < j; i++) {
					obj[loadingTimeArray[i]] = (obj[loadingTimeArray[i]] || 0) + 1;
				}
			
				if (obj[media.getCurrentPosition()] > 8) {
					Main.playerShowLoading();
				} else {
					Main.playerHideLoading();
				}
			}
			else{
				Main.playerHideLoading();
			}
}

Player.playKeydown = function(e)
{
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");
	
	
	function showPlayerBar(){

		if($("#customMessage").css("display") == "block")
			return false;
		if($(".player").css("display") == "block"){
			if(playBarInterval){
				clearInterval(playBarInterval);playBarInterval = '';
			}
			playBarInterval = setInterval(function(){
			$(".player").hide();
			if($('.imageFocus').attr("source") != "listSubs")
				$('.imageFocus').removeClass("imageFocus");
		//	$('.sub-title .listSubs').hide();
			$('.play-icons').hide();
			if(Player.type == "live"){
				$(".play-icons").hide();
				$(".playerBottomDiv").hide();
				$(".player").hide();
			 }
			 else{
				$(".play-icons").hide();
				$(".player").hide();
			 }
			},8000);
			return false;
		}
		else{
			$(".player").show();
			$('.play-icons').show();
			if($('.imageFocus').attr("source") != "listSubs")
				$('.imageFocus').removeClass("imageFocus");
			$('.play-icon').addClass("imageFocus");
			if(Player.type == "live"){
				$(".play-icons").hide();
				$(".playerBottomDiv").hide();
			 }
			 
			if(playBarInterval){
				clearInterval(playBarInterval);playBarInterval = '';
			}		
			playBarInterval = setInterval(function(){
				if(Player.type == "live"){
					$(".play-icons").hide();
					$(".playerBottomDiv").hide();$(".player").hide();
				 }
				 else{
					$(".player").hide();
					$(".play-icons").hide();
				 }
				 if($('.imageFocus').attr("source") != "listSubs")
					$('.imageFocus').removeClass("imageFocus");
			//	$('.sub-title .listSubs').hide();
				$('.play-icons').hide();
			},8000);
			return true;
		}
	}
	var source = $(".imageFocus").attr("source");
	if(showPlayerBar()){
		//showPlayerDetails();
	}
	else { //if($("#beforePlayer").css("display") != "block"){
		
		switch (keycode) {
		case tvKeyCode.MediaPlayPause:{
			if($(".play-icon").css("display") == "block"){
				if(document.visibilityState != "hidden")
					media.play();
					$(".play-icon").html('<i class="fas fa-pause"></i>');
				 
			}
			else{
				media.pause();
		        $(".play-icon").html('<i class="fas fa-play"></i>');
		        
			}
			break;
		}
		case tvKeyCode.ArrowLeft: {
			
			if(source == "playIcons")
			{
				if(index == 1){
					$('.imageFocus').removeClass("imageFocus");
					$('.playRewind').addClass("imageFocus");
				}
				else if(index == 2){
					$('.imageFocus').removeClass("imageFocus");
					$('.play-icon').addClass("imageFocus");
				}
				else if(index  == 0){
					if($('.sub-title').css("display") == "block"){
						$('.imageFocus').removeClass("imageFocus");
						$('.sub-title').addClass("imageFocus");
					}
					
				}
			}
			
			//seekToPosition("prev");
			break;
		}
		case tvKeyCode.ArrowRight: {
			/* if(source == "subtitles"){
				$('.imageFocus').removeClass("imageFocus");
			}
			else {
				//seekToPosition("next");
			} */
			if(source == "subtitles"){
				$('.imageFocus').removeClass("imageFocus");
				$('.playRewind').addClass("imageFocus");
			}
			else if(source == "playIcons")
			{
				if(index == 1){
					$('.imageFocus').removeClass("imageFocus");
					$('.playForward').addClass("imageFocus");
				}
				else if(index == 0){
					$('.imageFocus').removeClass("imageFocus");
					$('.play-icon').addClass("imageFocus");
				}
				
			}
			
			
			break;
		}case tvKeyCode.ArrowUp: {

			if(source == "listSubs"){
				var count = Object.keys(Main.subTitles).length;
				index --;
				if(index >= 0){
					$('.imageFocus').removeClass("imageFocus");
					$('#subsList-'+index).addClass("imageFocus");
				}
				
			}
			else if($(".player").css("display") == "block"){


				if(Player.type == "live"){
					if(homeLiveData && stack[stack.length-1].view == "live"){
						liveChnlIndex--;
						if(homeLiveData[liveChnlIndex] && homeLiveData[liveChnlIndex].id){
							Player.name = homeLiveData[liveChnlIndex].name;
							Main.playLive(homeLiveData[liveChnlIndex].id);
						}
					}
					else if(Main.searchResults && stack[stack.length-1].view == "search"){
						liveChnlIndex--;
						if(Main.searchResults[liveChnlIndex] && Main.searchResults[liveChnlIndex].id){
							Player.name = Main.searchResults[liveChnlIndex].name;
							Main.playLive(Main.searchResults[liveChnlIndex].id);
						}
					}
					else if(tvGuideChannelList.length && stack[stack.length-1].view == "tvGuide"){
						liveChnlIndex--;
						if(tvGuideChannelList[liveChnlIndex] && tvGuideChannelList[liveChnlIndex].id){
							Player.name = tvGuideChannelList[liveChnlIndex].name;
							Main.playLive(tvGuideChannelList[liveChnlIndex].id);
						}
					}
					else if(adultArray.channels){
						liveChnlIndex--;
						if(adultArray.channels[liveChnlIndex] && adultArray.channels[liveChnlIndex].id){
							Player.name = adultArray.channels[liveChnlIndex].name;
							Main.playLive(adultArray.channels[liveChnlIndex].id);
						}
					}
					
				}else{
					$(".player").hide();
					$('.play-icons').hide();
					$('.imageFocus').removeClass("imageFocus");
				}
				
			}
			else {
				$(".player").show();
				$('.play-icons').show();
				$('.imageFocus').removeClass("imageFocus");
				$('.play-icon').addClass("imageFocus");
			}
			break;
		}
		case tvKeyCode.Enter: {
			Player.playEnterKeydown($('.imageFocus'));
			break;
		}
		case tvKeyCode.MediaPlay:{
			if(document.visibilityState != "hidden")
				media.play();
				$(".play-icon").html('<i class="fas fa-pause"></i>');
			break;
		}
		case tvKeyCode.MediaStop:{
			Player.processBack();
			console.log("tvKeyCode.MediaStop " + keycode);
			break;
		}
		case tvKeyCode.MediaPause:{
			$(".player").show();$('.play-icons').show();
			media.pause();
			$(".play-icon").html('<i class="fas fa-play"></i>');
	        
			break;
		}
		case tvKeyCode.MediaFastForward:{
			$(".player").show();$('.play-icons').show();
			$('.imageFocus').removeClass("imageFocus");
			$('.playForward').addClass("imageFocus");
			seekToPosition("next");
			break;
		}
		case  tvKeyCode.MediaRewind:
		case tvKeyCode.MediaBackward:{
			$(".player").show();$('.play-icons').show();
			$('.imageFocus').removeClass("imageFocus");
			$('.playRewind').addClass("imageFocus");
			seekToPosition("prev");
			break;
		}
		case tvKeyCode.ArrowDown: {

			if(source == "listSubs"){
				var count = Object.keys(Main.subTitles).length;
				index ++;
				if(index <= count){
					$('.imageFocus').removeClass("imageFocus");
					$('#subsList-'+index).addClass("imageFocus");
				}
				
			}
			else if($(".player").css("display") == "block"){
				if(Player.type == "live"){
					if(homeLiveData && stack[stack.length-1].view == "live"){
						liveChnlIndex ++;
						if(homeLiveData[liveChnlIndex] && homeLiveData[liveChnlIndex].id){
							Player.name = homeLiveData[liveChnlIndex].name;
							Main.playLive(homeLiveData[liveChnlIndex].id);
						}
					}
					else if(Main.searchResults && stack[stack.length-1].view == "search"){
						liveChnlIndex++;
						if(Main.searchResults[liveChnlIndex] && Main.searchResults[liveChnlIndex].id){
							Player.name = Main.searchResults[liveChnlIndex].name;
							Main.playLive(Main.searchResults[liveChnlIndex].id);
						}
					}
					else if(tvGuideChannelList.length && stack[stack.length-1].view == "tvGuide"){
						liveChnlIndex++;
						if(tvGuideChannelList[liveChnlIndex] && tvGuideChannelList[liveChnlIndex].id){
							Player.name = tvGuideChannelList[liveChnlIndex].name;
							Main.playLive(tvGuideChannelList[liveChnlIndex].id);
						}
					}
					else if(adultArray.channels){
						liveChnlIndex++;
						if(adultArray.channels[liveChnlIndex] && adultArray.channels[liveChnlIndex].id){
							Player.name = adultArray.channels[liveChnlIndex].name;
							Main.playLive(adultArray.channels[liveChnlIndex].id);
						}
					}
				}else{
					$(".player").hide();$('.play-icons').hide();
					$('.imageFocus').removeClass("imageFocus");
				}
				
				
				
			}
			else {
				$(".player").show();$('.play-icons').show();
				$('.imageFocus').removeClass("imageFocus");
				$('.play-icon').addClass("imageFocus");
			}
			break;
		}
		
		case tvKeyCode.Return: 
		case 8:{
			if(source == "listSubs"){
				$("#customMessage").html('');
				$("#customMessage").hide();
			}
			else{
				Player.processBack();
			}
			
			break;
		}
		case 1536:{
			
		}
		default:{
			break;
		}
		}
	}
}
var liveCatChannelArray = '';
Player.playEnterKeydown = function(curFocus){
	var source = curFocus.attr("source");
	var index = parseInt(curFocus.attr("index"));

	if(source == "listSubs"){
		clearTimeout(ival);ival = '';$(".srt").hide();
		$("#customMessage").html('');
		$("#customMessage").hide();
		if(index > 0)
			playSubs(Main.subTitles[ Object.keys(Main.subTitles)[index-1]]);
	}
	else if(source == "subtitles"){

		Main.ShowSubtitles();

		$(".player").hide();
		$('.imageFocus').removeClass("imageFocus");
	//	$('.sub-title .listSubs').hide();
		$('.play-icons').hide();
		if(Player.type == "live"){
			$(".play-icons").hide();
			$(".playerBottomDiv").hide();
			
		 }
		 else{
			$(".play-icons").hide();
			$(".player").hide();
		 }
		 $('#subsList-0').addClass("imageFocus");
		 

	}
	else if($(".player").css("display") == "block"){
		if(source == "playIcons"){
			if(index == 1){
				playOrPause();
			}
			else if(index == 0 ){
				seekToPosition("prev");
			}
			else{
				seekToPosition("next");
			}
		}
		
	}
	else {
		$(".player").show();
	}
	
}
var beaconInterval = '';
function clearPlayerValues(){
	media.stop();
	media.unsetListener();
	media.reset();
	$("#videoDiv").hide();
	$("#videoDiv").html('');
}

Player.processBack = function(){
	media.stop();
	var obj = popState();
	view = obj.view;
	previousFocus = obj.focus;
	$("#loadingText").html("Loading..");
	$("#videoDiv").hide();$("#HTML5Div").hide();
	if(playBarInterval){
		clearInterval(playBarInterval);playBarInterval = '';
     }	
     if(intervalNetwork){
          clearInterval(intervalNetwork);intervalNetwork = '';
     }
	$("#videoDiv").html('');
	$('.imageFocus').removeClass("imageFocus");
	
	$('.play-icons').hide();

	$(".waterMark").hide();
	$("#beforePlayer").hide();
	
	clearTimeout(ival);ival = '';
	$(".srt").hide();
	Main.HideLoading();
	Main.processNext();
}
var seekTimeNext = 0;
var seekTimePrev = 0;
function seekToPosition(params){
	var cur = media.getCurrentPosition(); 
	var dur = '';
	media.pause();
	dur = media.getDuration();
	try{
		if(media.getDuration() == -1){
			/* if(singleMoviePage && singleMoviePage.vendorInfo && singleMoviePage.vendorInfo.duration){
				dur = singleMoviePage.vendorInfo.duration;
				dur = dur*1000;
			} */
		}
	}catch(e){}
	
	//if((cur + jumpNum) < media.getDuration() && (cur + jumpNum) > 0){
		if(params == "next"){
			
			if(( (cur+seekTimePrev) + seekTimeNext ) < (dur-20000)){
				seekTimeNext = seekTimeNext + jumpNum;
				seekTime = seekTime + jumpNum;
				console.log("Next" + (dur + seekTimeNext) );
			}
			else{
				seekTimeNext = dur-media.getCurrentPosition();
				seekTime = dur-media.getCurrentPosition();
			}
		}
		else{
			
			if( (seekTimePrev + (cur+seekTimeNext)) > 20000){
				seekTimePrev = seekTimePrev - jumpNum;
				seekTime = seekTime - jumpNum;
				console.log("prev" + (media.getCurrentPosition() + seekTimePrev));
			}
			else{
				seekTimePrev = -media.getCurrentPosition();
				seekTime = -media.getCurrentPosition();
			}	
		}
			
		var y = '';
		var offsetPos = '';
		var pickerX = parseInt($("#seek-picker").css("left").replace("px",''));
		
		if( $("#flix-seekbar-run").css("width").indexOf("px") != -1){
			
			offsetPos = parseInt($("#flix-seekbar-run").css("width").replace("px",''));
			
			y = (  (cur + seekTime) / dur ) * 100;
			
			var totalMove = (($("#flix-seekbar").width() * y) / 100);
			$("#flix-seekbar-run").css("width",totalMove+"px");
			$("#seek-picker").css("left",(totalMove-15)+"px");
			
			
			$("#seek-picker-runtime").css("left",(totalMove + 280)+ "px" );
			$("#seek-picker-runtime").html(getTimeHMS(cur + seekTime));
			$("#seek-picker-runtime").show();
		}
		
		
		if(seekTimer)
			clearTimeout(seekTimer);

		seekTimer = setTimeout(function(){ seekTime = Math.abs(seekTime);$("#seek-picker-runtime").hide(); console.log("SeekTime before - "+seekTime);seekTo(params);clearTimeout(seekTimer);seekTimer = '';},600);
	    console.log("SeekTime in seeker- "+seekTime);
		
		
//		}	
}


function seekTo(param) {

console.log("seekTo function");

	if(seekTime){
		curPos = media.getCurrentPosition();
	     var dur = media.getDuration();
	     if(media.getDuration() == -1){
				/* if(singleMoviePage && singleMoviePage.vendorInfo && singleMoviePage.vendorInfo.duration){
					dur = singleMoviePage.vendorInfo.duration;
					dur = dur*1000;
				} */
		 }
	     if((curPos + (seekTimeNext + seekTimePrev)) < dur){
	     	media.seekTo(curPos + (seekTimeNext + seekTimePrev));
	     }
	     else{
	     	media.seekTo(dur - 2000);
	     }
	     
	     seekTime = 0;
		seekTimeNext = 0;
		seekTimePrev = 0;
	}
	if($(".play-icon").css("display") != "block")
		media.play();
		
}
var mediaState = true;
function playOrPause() {

console.log("playOrPause");

if(mediaState) {
	media.pause();
	
	$(".play-icon").html('<i class="fas fa-play"></i>');
	mediaState = false;

	//You don't have to call setScreenSaver Method. It is configurated by toast.avplay.
}
else {
	if(document.visibilityState != "hidden")
		media.play();
	$(".play-icon").html('<i class="fas fa-pause"></i>');
	

	mediaState = true;
	//You don't have to call setScreenSaver Method. It is configurated by toast.avplay.
}
}



/// Subs


function toSeconds(t) {
    var s = 0.0
    if(t) {
      var p = t.split(':');
      for(i=0;i<p.length;i++)
        s = s * 60 + parseFloat(p[i].replace(',', '.'))
    }
    return s;
  }
  function strip(s) {
    return s.replace(/^\s+|\s+$/g,"");
  }
  var ival = '';
  function playSubtitles(subtitleElement) {
   
    var srt = subtitleElement.text();
	subtitleElement.text('');
	
    srt = srt.replace(/\r\n|\r|\n/g, '\n')
    
    var subtitles = {};
    srt = strip(srt);
    var srt_ = srt.split('\n\n');
    for(s in srt_) {
        st = srt_[s].split('\n');
        if(st.length >=2) {
          n = st[0];
          i = strip(st[1].split(' --> ')[0]);
          o = strip(st[1].split(' --> ')[1]);
          t = st[2];
          if(st.length > 2) {
            for(j=3; j<st.length;j++)
              t += '\n'+st[j];
          }
          is = toSeconds(i);
          os = toSeconds(o);
          subtitles[is] = {i:is, o: os, t: t};
        }
    }
    var currentSubtitle = -1;
    ival = setInterval(function() {
      var currentTime = media.getCurrentPosition()  / (1000);
	  var subtitle = -1;
	  
	  
	  var Okeys = Object.keys(subtitles);

	  var Values = [];
	 
	  for(var i=0;i<Okeys.length;i++){
		Values.push(subtitles[Okeys[i]]);
	  }
	  
	  //Object.values(subtitles);
	  var funC = function(a, b){return parseInt(a)-parseInt(b)}
	  Okeys.sort(funC);
	  Values.sort(funC);

      for(var i = 0;i<Values.length;i++) {
		//  console.log("s = "+keys + " current Time = "+ currentTime);
        if(Okeys[i] > currentTime)
          break;
        subtitle =  Okeys[i];
      }
      if(subtitle != -1) {
        if(subtitle != currentSubtitle) {
          subtitleElement.html(subtitles[subtitle].t);
          currentSubtitle=subtitle;
        } else if(subtitles[subtitle] && subtitles[subtitle].o < currentTime) {
          subtitleElement.html('');
        }
      }
    }, 100);
  }


  function playSubs(srtUrl) {
	$(".srt").html('');
	$(".srt").show();
    var subtitleElement = $(".srt");
    var videoId = $("#renderarea video");
    if(!videoId) return;
	//var srtUrl = "http://subs.89to.com/movies/tt3778644/tt3778644.he.srt";
	try{
		if(srtUrl) {
			$(".srt").load(srtUrl, function (responseText, textStatus, req) { 
			  playSubtitles(subtitleElement);
			})
		} else {
		  playSubtitles(subtitleElement);
		}
	}
	catch(e){

	}
    
  }