var Keyhandler = {};


Keyhandler.menuKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
			
			break;
		}
	case tvKeyCode.ArrowRight: {
		$(".leftHigh").removeClass("leftHigh");
		$(".imageFocus").addClass("leftHigh");
		if(contentView == "homeMovies"){
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus)
				$('#' + homeFocus).addClass("imageFocus");
			else
				$('#homeMovies-' + 0+ "-"+0).addClass("imageFocus");

			view = "homeMovies";
		}
		else if(contentView == "singleMovie"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			$('#SP-btn-0').addClass("imageFocus");
			
		}
		else if(contentView == "tvShows"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus)
				$('#' + homeFocus).addClass("imageFocus");
		    else
				$('#hometvShows-0-0').addClass("imageFocus");
		}		
		else if(contentView == "live"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus)
				$('#' + homeFocus).addClass("imageFocus");
		    else
				$('#homeLive-0-0').addClass("imageFocus");
		}else if(contentView == "tvShowDetail"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus)
				$('#' + homeFocus).addClass("imageFocus");
		    else
				$('#eps-1').addClass("imageFocus");
		}
		else if(contentView == "adultShowDetail"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus)
				$('#' + homeFocus).addClass("imageFocus");
		    else {
                    if(adultArray.movies)
                         $('#eps-0').addClass("imageFocus");
                   else
                         $('#homeLive-0-0').addClass("imageFocus");
              }
				
		}
		else if(contentView == "liveTvDetail"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus)
				$('#' + homeFocus).addClass("imageFocus");
		    else
				$('#watchNow').addClass("imageFocus");
		}else if(contentView == "watchList"){
			view = contentView;
			
			if(homeFocus && homeFocus.split("-")[0] == "homeMovies"){
				$('.imageFocus').removeClass("imageFocus");
				$('#'+homeFocus).addClass("imageFocus");
			}
			else if(homeFocus  && homeFocus.split("-")[0] == "homeLive"){
				$('.imageFocus').removeClass("imageFocus");
				$('#'+homeFocus).addClass("imageFocus");
			}
			else if(homeFocus  && homeFocus.split("-")[0] == "hometvShows"){
				$('.imageFocus').removeClass("imageFocus");
				$('#'+homeFocus).addClass("imageFocus");
			}
			else{
				var menuIndex = parseInt($(".menuSelected").attr("index"));
				if(menuIndex == 0){
					$('.imageFocus').removeClass("imageFocus");
					$('#homeMovies-0-0').addClass("imageFocus");
				}
				else if(menuIndex == 1){
					$('.imageFocus').removeClass("imageFocus");
					$('#hometvShows-0-0').addClass("imageFocus");
				}
				else if(menuIndex == 2){
					$('.imageFocus').removeClass("imageFocus");
					$('#homeLive-0-0').addClass("imageFocus");
				}
				else{
					view = "leftMenu";
				}
			}
			break;
			
		}
		else if(contentView == "adult"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");

			if(homeFocus && homeFocus.split("-")[0] == "homeMovies"){
				$('#'+homeFocus).addClass("imageFocus");
			}
			else if(homeFocus  && homeFocus.split("-")[0] == "homeLive"){
				$('#'+homeFocus).addClass("imageFocus");
			}
			else{
				var menuIndex = parseInt($(".menuSelected").attr("index"));
				if($(".menuSelected").text() == "Movies"){
					$('#homeMovies-0-0').addClass("imageFocus");
				}
				else if($(".menuSelected").text() == "TV Shows"){
					$('#hometvShows-0-0').addClass("imageFocus");
				}
				else{
					$('#homeLive-0-0').addClass("imageFocus");
				}
			}
		}
		else if( contentView =="tvGuide"){
			view = contentView;
			$('.imageFocus').removeClass("imageFocus");
			if(homeFocus){
				$('#' + homeFocus).addClass("imageFocus");
				Keyhandler.updateProgInfo(currentActive_prog_id[homeFocus.split('_')[1]],0);
			}
		    else{
		    	$('#channel_0').addClass("imageFocus");
			 	Keyhandler.updateProgInfo(currentActive_prog_id[0],0);
		    }
				
		}
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(index > 0){
				index --;
				if($('#'+contentView+'leftMenu-' + index).length){
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'leftMenu-' + index).addClass("imageFocus");
				}
				else{
					index --;
					if($('#'+contentView+'leftMenu-' + index).length){
						$('.imageFocus').removeClass("imageFocus");
						$('#'+contentView+'leftMenu-' + index).addClass("imageFocus");
					}
				}
				
			}
			else{
				if($(".searchBar").length && (contentView == "homeMovies" || contentView == "live" || contentView == "tvShows" )){
					$('.imageFocus').removeClass("imageFocus");
					$(".searchBar").addClass("imageFocus");
					$(".searchBar").focus();
				}
			}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.menuKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {

		var id = $('.imageFocus').attr("id");
		if(id == "searchBox"){
			$("#searchBox").blur();
			$('.imageFocus').removeClass("imageFocus");
			$('#'+contentView+'leftMenu-' + 0).addClass("imageFocus");view = "leftMenu";
		}
		else if(index < 7){
			index ++;
			if($('#'+contentView+'leftMenu-' + index).length){
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'leftMenu-' + index).addClass("imageFocus");
			}else {
				index++;
				if($('#'+contentView+'leftMenu-' + index).length){
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'leftMenu-' + index).addClass("imageFocus");
				}
			}
			
		}
			break;
          }
     case 8:
	case tvKeyCode.Return: {
          pushState(view,$(".imageFocus").attr("id"));
          $('.imageFocus').removeClass("imageFocus");
          view = "exitApp";
          $("#customMessage").html(Util.showPopUp(2,'', "Do you want to Exit the Application ?", "Yes","No"));
          $("#customMessage").show();
          $("#Btn-0").addClass("imageFocus");
          Main.HideLoading();

		break;
		}
	default: {
			break;
		}
	}
}
var homeFocus = '';
var menuFocus = '';

Keyhandler.exitKeyEnter = function(currFocus){
	var index = parseInt(currFocus.attr("index"));
	var id = currFocus.attr("id");

	if(index == 0){
		if(view == "exitApp")
			toast.application.exit();
		else if(view == "acceptTerms"){
			if(Player.playData.play_location){
				view = "continue";
				$("#customMessage").html(Util.showPopUp(2,'', "", "RESUME","START OVER"));
				$("#customMessage").show();
				$(".popup-p").css("padding","0px");
				$(".popup-Message-container").addClass("resume");
				$("#Btn-0").addClass("imageFocus");
			}
			else{
				Main.hitBeaconTest(Player.playData.play_location_id,Player.playData.play_location);
			}
			
		}
		else if(view == "continue"){
			Main.hitBeaconTest(Player.playData.play_location_id,Player.playData.play_location);
		}
		else
			{
				$("#customMessage").hide();
				$("#customMessage").html('');
				try {
					var obj = popState();
					if(obj.focus.indexOf("leftMenu") == -1)
                              view = obj.view;
                         else
                              view = "leftMenu";
					$("#"+obj.focus).addClass("imageFocus");
				} catch (e) {}
	
				if (callBack) {
					callBack();
					callBack = '';
				}
			}
	}
	else{
		if(view == "continue"){
			Player.playData.play_location = 0;
			Main.hitBeaconTest(Player.playData.play_location_id,0);
		}
		else if(view == "acceptTerms"){
			$("#customMessage").hide();
			$("#customMessage").html('');
			$("#SingleMoviePage").show();
			try {
				var obj = popState();
				view = obj.view;
				$("#"+obj.focus).addClass("imageFocus");
			} catch (e) {}

			if (callBack) {
				callBack();
				callBack = '';
			}
		}
		else{
			$("#customMessage").hide();
			$("#customMessage").html('');
			try {
				var obj = popState();
				if(obj.focus.indexOf("leftMenu") == -1)
                         view = obj.view;
                    else
                         view = "leftMenu";
				$("#"+obj.focus).addClass("imageFocus");
			} catch (e) {}

			if (callBack) {
				callBack();
				callBack = '';
			}
		}
	}
}

Keyhandler.homeKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var index = parseInt($('.imageFocus').attr("index"));
	
	var id = $('.imageFocus').attr("id");
	var count = parseInt($('.imageFocus').attr("count"));
	var source = $('.imageFocus').attr("source");

	var v_index = parseInt($('.imageFocus').attr("v_index"));
	var h_index = parseInt($('.imageFocus').attr("h_index"));

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		if(source != "topMenu"){
		//	if (index > 0) {
				/* if(index == count-1){
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeMovies-' + index).addClass("imageFocus");
	
					if($("#homeMovies-"+(index+4)).html() && (index) > 3){
						$("#homeMovies-"+(index+4)).remove();
					}
				}
				else{
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeMovies-' + index).addClass("imageFocus");
	
					if($("#homeMovies-"+(index+4)).html() ) {
						$("#homeMovies-"+(index+4)).remove();
					}
	
					if((index-1) >= 0){
						$("#moviesList").prepend(Util.generateMovieCard(homeMoviesData[(index-1)],(index-1),homeMoviesData.length));
					}
				} */
				
				if(h_index == 0){
					homeFocus = $('.imageFocus').attr('id');
					$('.imageFocus').removeClass("imageFocus");
					view = "leftMenu";
					$('#'+contentView+'leftMenu-0').addClass("imageFocus");
				}
				else if(h_index > 0){
					h_index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeMovies-'+v_index+"-"+h_index).addClass("imageFocus");
				}
				
			/* }
			else{
				gotoLeftMenu();
			} */
		}
		else{
			if (index > 0) {
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#topMenu-' + index).addClass("imageFocus");
					
						$('#topMenu-' + (index)).show();
						$('#topMenu-' + (index+8)).hide();
					
			}
			else{
				view = "leftMenu";
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'leftMenu-0').addClass("imageFocus");menuFocus = 0;
			}
			
		}
			
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source != "topMenu"){
			/* if (index < count-1) {
				
				index++;

				$('.imageFocus').removeClass("imageFocus");
				$('#homeMovies-' + index).addClass("imageFocus");

				if($("#homeMovies-"+(index-2)).html() && (index) < homeMoviesData.length-1){
					$("#homeMovies-"+(index-2)).remove();
				}
				if(!$("#homeMovies-"+(index+3)).html() && (index+2) < homeMoviesData.length-1)
				$("#moviesList").append(Util.generateMovieCard(homeMoviesData[(index+3)],(index+3),homeMoviesData.length));
			} */
			if(h_index < 4){
				h_index++;
				$('.imageFocus').removeClass("imageFocus");
				$('#homeMovies-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
		else{
			if (index < count-1) {
					index++;
					$('.imageFocus').removeClass("imageFocus");
					$('#topMenu-' + index).addClass("imageFocus");
				//	if(index > 2){
						$('#topMenu-' + (index-8)).hide();
						$('#topMenu-' + (index)).show();
			//		}
			}
			
		}
			
			
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(source != "topMenu"){
				/* homeFocus = $('.imageFocus').attr('id');
				$('.imageFocus').removeClass("imageFocus");
				$('.menuSelected').addClass("imageFocus"); */
				
				if(v_index > 0){
					$("#moviesList").prepend(Util.addMovieRow((v_index-1)));
					$("#homeRow-"+(v_index-1)).show();
					v_index --;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeMovies-'+v_index+"-"+h_index).addClass("imageFocus");
					$("#homeRow-"+(v_index+2)).remove();
				}
				else if(source != "topMenu" && id != "searchBox"){
					
						homeFocus = $('.imageFocus').attr('id');
						$('.imageFocus').removeClass("imageFocus");
						if(menuFocus)
							$('#topMenu-' + (menuFocus)).addClass("imageFocus");
						else
						$('#topMenu-' + (0)).addClass("imageFocus");
				}
			}
			else  if(source == "topMenu"){
				menuFocus = index;
				$('.imageFocus').removeClass("imageFocus");
				$(".searchBar").addClass("imageFocus");
				$(".searchBar").focus();
			}
			
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.homeKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {
		var id = $('.imageFocus').attr("id");
		if(id == "searchBox"){
			$("#searchBox").blur();
			$('.imageFocus').removeClass("imageFocus");
			if(menuFocus)
			{
				$('#topMenu-'+menuFocus).addClass("imageFocus");
			}
			else{
				$('#'+contentView+'leftMenu-' + 0).addClass("imageFocus");
				view = "leftMenu";
			}

			
		}
		else if(source == "topMenu"){
			
			$('.imageFocus').removeClass("imageFocus");
			$('#'+homeFocus).addClass("imageFocus");
			menuFocus = index;
			
		}
		else if(v_index < (count/5)-1){
			$("#homeRow-"+(v_index)).remove();
			v_index ++;
			$('.imageFocus').removeClass("imageFocus");

			if((v_index * 5)+h_index < count-1 )
				$('#homeMovies-'+v_index+"-"+h_index).addClass("imageFocus");
			else
				$('#homeMovies-'+v_index+"-"+ ( (count-1) % 5)).addClass("imageFocus");


			
			$("#moviesList").append(Util.addMovieRow((v_index+1)));
			$("#homeRow-"+(v_index+1)).show();
		}
			break;
          }
     case 8:
	case tvKeyCode.Return: {
          pushState(view,$(".imageFocus").attr("id"));
          $('.imageFocus').removeClass("imageFocus");
          view = "exitApp";
          $("#customMessage").html(Util.showPopUp(2,'', "Do you want to Exit the Application ?", "Yes","No"));
          $("#customMessage").show();
          $("#Btn-0").addClass("imageFocus");
          Main.HideLoading();
          break;  
	}
	default: {
			break;
		}
	}
}

Keyhandler.exitKeyhandler = function(e){
var keycode;
var userAgent = new String(navigator.userAgent);
if (window.event) {
     keycode = e.keyCode;
} else if (e.which) {
     keycode = e.which;
}

var index = parseInt($('.imageFocus').attr("index"));
var id = $('.imageFocus').attr("id");



switch (keycode) {
case tvKeyCode.ArrowLeft: {
          if(index == 1){
               index--;
               $(".imageFocus").removeClass("imageFocus");
               $("#Btn-"+index).addClass("imageFocus");
          }
          break;
     }
case tvKeyCode.ArrowRight: {
          if(index == 0){
               index++;
               $(".imageFocus").removeClass("imageFocus");
               $("#Btn-"+index).addClass("imageFocus");
          }
          break;
     }
case tvKeyCode.ArrowUp: {

          break;
     }
case tvKeyCode.Enter:{
     
     Keyhandler.exitKeyEnter($(".imageFocus"));
     break;
}
case tvKeyCode.Return:
 {

          $("#customMessage").hide();
          $("#customMessage").html('');
          try {
               var obj = popState();
               if(obj.focus.indexOf("leftMenu") == -1)
                    view = obj.view;
               else
                    view = "leftMenu";

               
               $("#"+obj.focus).addClass("imageFocus");
          } catch (e) {}

          if (callBack) {
               callBack();
               callBack = '';
          }

          break;
     }
case tvKeyCode.ArrowDown: {

          break;
     }

default: {
          break;
     }
}

}
/* Keyhandler.signInKeydown = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
			
			break;
		}
	case tvKeyCode.ArrowRight: {
			
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(index > 0){
				index --;
				$('.imageFocus').blur();
				$('.imageFocus').removeClass("imageFocus");
				$('#signIn-' + index).addClass("imageFocus");
				$('#signIn-' + index).focus();
			}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.signInKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {
			if(index < 2){
				index ++;
				$('.imageFocus').blur();
				$('.imageFocus').removeClass("imageFocus");
				$('#signIn-' + index).addClass("imageFocus");
				$('#signIn-' + index).focus();
			}
			break;
		}
	case tvKeyCode.Return: {
			
			break;
		}
	default: {
			break;
		}
	}
} */
Keyhandler.descKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}

	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {

			break;
		}
	case tvKeyCode.ArrowRight: {

			break;
		}
	case tvKeyCode.ArrowUp: {

			break;
		}
	
	case tvKeyCode.Return:
	case tvKeyCode.Enter: {

			$("#customMessage").hide();
			$("#customMessage").html('');
			try {
				var obj = popState();
				view = obj.view;
			} catch (e) {}

			if (callBack) {
				callBack();
				callBack = '';
			}

			break;
		}
	case tvKeyCode.ArrowDown: {

			break;
		}

	default: {
			break;
		}
	}
}
Keyhandler.liveTvKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	var v_index = parseInt($('.imageFocus').attr("v_index"));
	var h_index = parseInt($('.imageFocus').attr("h_index"));

	var index = parseInt($('.imageFocus').attr("index"));
	
	var id = $('.imageFocus').attr("id");
	var count = parseInt($('.imageFocus').attr("count"));
	var source = $('.imageFocus').attr("source");
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		 if(source != "topMenu"){
		/*	if (index > 0) {
				if(index == count-1){
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeLive-' + index).addClass("imageFocus");
	
					if($("#homeLive-"+(index+4)).html() && (index) > 3){
						$("#homeLive-"+(index+4)).remove();
					}
				}
				else{
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeLive-' + index).addClass("imageFocus");
	
					if($("#homeLive-"+(index+4)).html() ) {
						$("#homeLive-"+(index+4)).remove();
					}
	
					if((index-1) >= 0){
						$("#liveList").prepend(Util.generateLiveCard(homeLiveData[(index-1)],(index-1),homeLiveData.length));
					}
				}
				
				
			}
			else{
				gotoLeftMenu()
			} */

			if(h_index == 0){
				homeFocus = $('.imageFocus').attr('id');
				$('.imageFocus').removeClass("imageFocus");
				view = "leftMenu";
				$('#'+contentView+'leftMenu-2').addClass("imageFocus");
			}
			else if(h_index > 0){
				h_index--;
				$('.imageFocus').removeClass("imageFocus");
				$('#homeLive-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
		else{
			if (index > 0) {
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).addClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).show();
				//	if((index) > 4){
						$('#'+contentView+'TopMenu-' + (index)).show();
						$('#'+contentView+'TopMenu-' + (index+8)).hide();
				//	}
						
				
			}
			else{
				menuFocus = $('.imageFocus').attr("id");
				view = "leftMenu";
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'leftMenu-0').addClass("imageFocus");
			}
		}
			
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source != "topMenu"){
			/* if (index < count-1) {
				
				index++;

				$('.imageFocus').removeClass("imageFocus");
				$('#homeLive-' + index).addClass("imageFocus");

				if($("#homeLive-"+(index-2)).html() && (index) < homeLiveData.length-1){
					$("#homeLive-"+(index-2)).remove();
				}
				if(!$("#homeLive-"+(index+3)).html() && (index+2) < homeLiveData.length-1)
				$("#liveList").append(Util.generateLiveCard(homeLiveData[(index+3)],(index+3),homeLiveData.length));
			} */

			if(h_index < 4){
				h_index++;
				$('.imageFocus').removeClass("imageFocus");
				$('#homeLive-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
		else{
			if (index < count-1) {
					index++;
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).addClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).show();
				//	if(index > 4){
						$('#'+contentView+'TopMenu-' + (index-8)).hide();
						$('#'+contentView+'TopMenu-' + (index)).show();
				//	}
			}
		}
			
			
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(source != "topMenu"){
				/* homeFocus = $('.imageFocus').attr('id');
				$('.imageFocus').removeClass("imageFocus");
				$('.menuLiveSelected').addClass("imageFocus"); */

				if(v_index > 0){
					$("#liveList").prepend(Util.addLiveRow((v_index-1)));
					$("#liveRow-"+(v_index-1)).show();
					v_index --;
					$('.imageFocus').removeClass("imageFocus");
					$('#homeLive-'+v_index+"-"+h_index).addClass("imageFocus");
					$("#liveRow-"+(v_index+2)).remove();
				}
				else if(source != "topMenu"  && id != "searchBox"){
					
						homeFocus = $('.imageFocus').attr('id');
						$('.imageFocus').removeClass("imageFocus");
						if(menuFocus)
							$('#'+menuFocus).addClass("imageFocus");
						else 
							$('.menuLiveSelected').addClass("imageFocus");
				}
				
			}
			else if(source == "topMenu"){
				menuFocus = index;
				$('.imageFocus').removeClass("imageFocus");
				$(".searchBar").addClass("imageFocus");
				$(".searchBar").focus();
			}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.liveKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {
		var id = $('.imageFocus').attr("id");
		if(id == "searchBox"){
			$("#searchBox").blur();
			$('.imageFocus').removeClass("imageFocus");
			if(menuFocus)
			{
				$('#liveTopMenu-'+menuFocus).addClass("imageFocus");
			}
			else{
				$('#'+contentView+'leftMenu-' + 0).addClass("imageFocus");view = "leftMenu";
			}
			
		}
		else if(source == "topMenu"){
			menuFocus = $('.imageFocus').attr("id");
			$('.imageFocus').removeClass("imageFocus");
			$("#"+homeFocus).addClass("imageFocus");
		}
		else if(v_index < (count/5)-1){
			$("#liveRow-"+(v_index)).remove();
			v_index ++;
			$('.imageFocus').removeClass("imageFocus");

			if((v_index * 5)+h_index < count-1 )
				$('#homeLive-'+v_index+"-"+h_index).addClass("imageFocus");
			else
				$('#homeLive-'+v_index+"-"+ ( (count-1) % 5)).addClass("imageFocus");

			
			$("#liveList").append(Util.addLiveRow((v_index+1)));
			$("#liveRow-"+(v_index+1)).show();
		}
			break;
		}
	case tvKeyCode.Return: {
			
			break;
		}
	default: {
			break;
		}
	}
}
function gotoLeftMenu(){
	contentView = view;
	view = "leftMenu";
	homeFocus = $('.imageFocus').attr('id');
	$('.imageFocus').removeClass("imageFocus");
	$('.leftHigh').addClass("imageFocus");
}
Keyhandler.liveKeyEnter =  function (currFocus) {
	Main.ShowLoading();
	
	var index = parseInt(currFocus.attr("index"));
	var source = currFocus.attr("source");
	var attrid = currFocus.attr("attrid");
	var id = currFocus.attr("id");
	var count = parseInt(currFocus.attr("count"));
	liveChnlIndex = index;
	if(id == "searchBox"){
		var searchVal = $("#searchBox").val();
		if(searchVal)
			Main.searchData("livetv",searchVal);	
	}
	else if(source == "topMenu"){
		$('.menuLiveSelected ').removeClass("menuLiveSelected ");
		if($(".mouseFocus").attr("source") == "topMenu"){
			$('.imageFocus').removeClass("imageFocus");
			$(".mouseFocus").addClass("imageFocus");
		}
		
		Main.updateLiveTvSections(attrid);
		$("#liveTopMenu-"+index).addClass("menuLiveSelected");
	}
	else if(index > -1){
	
		pushState(view,$(".imageFocus").attr("id"));
		hideValues();
	
		view = "liveTvDetail";
		contentView = view;
		$("#mainContent").hide();
		$('.imageFocus').removeClass("imageFocus");
		$('.leftHigh').removeClass("leftHigh");
		$("#SingleMoviePage").html(Util.liveTvDetailPage(homeLiveData[index],index));
		$("#liveTvDetailleftMenu-2").addClass("leftHigh");
		$("#SingleMoviePage").show();
		Main.HideLoading();
	}
	else{
		Main.HideLoading();
	}
	
	
}

Keyhandler.homeKeyEnter = function (currFocus) {
	Main.ShowLoading();

	var index = parseInt(currFocus.attr("index"));
	var source = currFocus.attr("source");
	var attrid = currFocus.attr("attrid");
	var id = currFocus.attr("id");
	var count = parseInt(currFocus.attr("count"));

	if(id == "searchBox"){
		var searchVal = $("#searchBox").val();
		if(searchVal)
			Main.searchData("movie",searchVal);
		
	}
	else if(source == "topMenu"){
		$(".menuSelected").removeClass("menuSelected");
		if($(".mouseFocus").attr("source") == "topMenu"){
			$('.imageFocus').removeClass("imageFocus");
			$(".mouseFocus").addClass("imageFocus");
		}
		Main.updateHomeSections(attrid);
		$("#topMenu-"+index).addClass("menuSelected");
	} 
	else	
	{
		var imdb = currFocus.attr("imdb");
		if(imdb)
			Main.getMovieDetails(imdb);
		else
			Main.HideLoading();
	}
	
}



Keyhandler.menuKeyEnter = function (currFocus) {
	Main.ShowLoading();
	var index = parseInt(currFocus.attr("index"));
	homeFocus = '';
	
	var id = currFocus.attr("id");
	if(id == "searchBox"){
		var searchVal = $("#searchBox").val();
		if(searchVal)
		if(contentView == "homeMovies"){
			Main.searchData("movie",searchVal);
		}else if(contentView == "tvShows"){
			Main.searchData("tv",searchVal);
		}
		else{
			Main.searchData("livetv",searchVal);
		}
	}
	else{
		switch(index){
		case 0:{
			if(view == "leftMenu") view = contentView;
			previousView = view;
			view = "homeMovies";
			Main.processNext();
			break;
		}
		case 1:{
			if(view == "leftMenu") view = contentView;
			previousView = view;
			view = "tvShows";
			Main.processNext();
			break;
		}
		case 2:{
			if(view == "leftMenu") view = contentView;
			previousView = view;
			view = "live";
			Main.processNext();
			break;
		}
		case 4:{
			if(!Main.profile.token){
				Main.showInfo("Please login to get Watch List");
				callBack = function(){
					view = "signIn";
					Main.processNext();
				}
			}
			else{
				view = "watchList";
				Main.processNext();
			}
			break;
		}
		case 3:{
			view = "tvGuide";
			Main.processNext();
			break;
		}
		case 5:{
			if(Main.profile){
				pushState(contentView,$(".imageFocus").attr("id"));
				hideValues();
				Main.HideLoading();
				view = "profile";
				$('.imageFocus').removeClass("imageFocus");
				$("#profile").html(Util.profilePage()) ;
				$("#profile").show();
			}
			else{
				pushState(contentView,$(".imageFocus").attr("id"));
				$('.imageFocus').removeClass("imageFocus");
				view = "signIn";
				Main.processNext();
			}
			
			break;
		}
		case 6:{
			Main.HideLoading();
			pushState(contentView,$(".imageFocus").attr("id"));
			$('.imageFocus').removeClass("imageFocus");
			view = "confirmPin";
			$("#customMessage").html(Util.confirmPin());
			$("#customMessage").show();


			
			break;
		}
		case 7:{
			if(currFocus.children()[1].textContent == "Sign In"){
				pushState(contentView,$(".imageFocus").attr("id"));
				$('.imageFocus').removeClass("imageFocus");
				view = "signIn";
				Main.processNext();
			}
			else{
				Main.logOut();currFocus.children()[1].textContent = "Sign In";
			}
			break;
		}
	}
	}


	
	
	
}
/* Keyhandler.signInKeyEnter = function (currFocus) {
	var index = parseInt(currFocus.attr("index"));
	if(index == 2){
		Main.getSignIn($('#email').val().trim(),$('#password').val().trim());
	}
} */





Keyhandler.liveTvDetailKeydown = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}

	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");
	
	var source = $('.imageFocus').attr("source");

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
			if(id == "watchListBtn"){
				$('.imageFocus').removeClass("imageFocus");
				$('#watchNow').addClass("imageFocus");
			}
			else{
				gotoLeftMenu();
			}
		
			break;
		}
	case tvKeyCode.ArrowRight: {
			if(id == "watchNow"){
				$('.imageFocus').removeClass("imageFocus");
				$('#watchListBtn').addClass("imageFocus");
			}
			break;
		}
	case tvKeyCode.ArrowUp: {

			break;
	}
	case tvKeyCode.Enter: {
		Keyhandler.liveTvDetailKeyEnter($('.imageFocus'));
		break;
	}
	case tvKeyCode.ArrowDown: {

			break;
	}
	case tvKeyCode.Return:
	case 8: {
		$("#SingleMoviePage").hide();
		$("#SingleMoviePage").html('');
		try {
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			contentView = view;
			homeFocus = '';
		} catch (e) {}
		
		Main.processNext();
		break;
		}
	default: {
			break;
		}
	}
}


Keyhandler.liveTvDetailKeyEnter = function (currFocus) {
	Main.ShowLoading();
	
	var attrid = currFocus.attr("id");
	var liveID = currFocus.attr("liveID");
	var liveTVIndex = currFocus.attr("liveTVIndex");
	liveChnlIndex = liveTVIndex;
	if(homeLiveData && stack[stack.length-1].view == "live")
		Player.name = homeLiveData[liveTVIndex].name;
	else if(Main.searchResults && stack[stack.length-1].view == "search"){
			Player.name = Main.searchResults[liveTVIndex].name;
	}
	else if(adultArray.channels){
		Player.name = adultArray.channels[liveTVIndex].name;
	}
	else if(watchlistMap["channel"].length){
		Player.name = watchlistMap["channel"][liveTVIndex].name;
	}
	if(attrid == "watchNow"){
		Main.playLive(liveID);
	}
	else{
		if(homeLiveData){
			if($(currFocus.selector + " span").text().indexOf("Add") != -1){
				Main.hitWatchList("add",homeLiveData[liveTVIndex].id,0,0,0);$(currFocus.selector + " span").text("Remove From Watchist")
			}
			else{
				Main.hitWatchList("remove",homeLiveData[liveTVIndex].id,0,0,0);$(currFocus.selector + " span").text("Add to Watchist")
			}
		}
		else if(adultArray && adultArray.channels){
			if($(currFocus.selector + " span").text().indexOf("Add") != -1){
				Main.hitWatchList("add",adultArray.channels[liveTVIndex].id,0,0,0);$(currFocus.selector + " span").text("Remove From Watchist")
			}
			else{
				Main.hitWatchList("remove",adultArray.channels[liveTVIndex].id,0,0,0);$(currFocus.selector + " span").text("Add to Watchist")
			}
		}
		else if(Main.searchResults){
			if($(currFocus.selector + " span").text().indexOf("Add") != -1){
				Main.hitWatchList("add",Main.searchResults[liveTVIndex].id,0,0,0);$(currFocus.selector + " span").text("Remove From Watchist")
			}
			else{
				Main.hitWatchList("remove",Main.searchResults[liveTVIndex].id,0,0,0);$(currFocus.selector + " span").text("Add to Watchist")
			}
		}
		
	}
}

Keyhandler.singleMovieKeydown = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}

	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");
	
	var source = $('.imageFocus').attr("source");

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		if(source == "SPbuttons"){
			if(index == 0){
				contentView = view;
				view = "leftMenu";
				homeFocus = $('.imageFocus').attr('id');
				
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'leftMenu-0').addClass("imageFocus");
			}
			else{
				index --;
				$('.imageFocus').removeClass("imageFocus");
				$('#SP-btn-'+index).addClass("imageFocus");
			}
		}
		
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source == "SPbuttons"){
			if(index < 1){
				index ++;
				$('.imageFocus').removeClass("imageFocus");
				$('#SP-btn-'+index).addClass("imageFocus");
			}
			
		}
			break;
		}
	case tvKeyCode.ArrowUp: {

			break;
	}
	case tvKeyCode.Enter: {
		Keyhandler.singleMovieEnter($('.imageFocus'));
	break;
	}
	case tvKeyCode.ArrowDown: {

			break;
	}
	case tvKeyCode.Return:
	case 8: {
		$("#SingleMoviePage").hide();
		$("#SingleMoviePage").html('');
		try {
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			contentView = view;
			homeFocus = '';
		} catch (e) {}
		
		Main.processNext();
		break;
		}
	default: {
			break;
		}
	}
}
Keyhandler.singleMovieEnter = function (currFocus) {
	

	var index = parseInt(currFocus.attr("index"));
	var source = currFocus.attr("source");
	var attrid = currFocus.attr("attrid");
	var count = parseInt(currFocus.attr("count"));
	var imdb = parseInt(currFocus.attr("count"));
	Player.name = singleMoviePage.title;
	if(index == 1){
		if($(currFocus.selector + " span").text().indexOf("Add") != -1){
			Main.hitWatchList("add",0,singleMoviePage.imdb,0,0);$(currFocus.selector + " span").text("Remove From Watchist")
		}
		else{
			Main.hitWatchList("remove",0,singleMoviePage.imdb,0,0);$(currFocus.selector + " span").text("Add to Watchist")
		}
			
	}
	else{
		Main.playStream(singleMoviePage.imdb,"","");
	}
}




Keyhandler.tvShowsKeyDown = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var v_index = parseInt($('.imageFocus').attr("v_index"));
	var h_index = parseInt($('.imageFocus').attr("h_index"));
	var count = homeTvShowData.length;
	var id = $('.imageFocus').attr("id");
	var source = $('.imageFocus').attr("source");
	var index = parseInt($('.imageFocus').attr("index"));
	var menuCount = parseInt($('.imageFocus').attr("count"));
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
			if(source == "topMenu"){
				if (index > 0) {
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).addClass("imageFocus");
					$('#'+contentView+'TopMenu-' + (index)).show();
					$('#'+contentView+'TopMenu-' + (index+8)).hide();
			}
			else{
				gotoLeftMenu()
			}
		}
		else{
			if(h_index == 0){
				homeFocus = $('.imageFocus').attr('id');
				$('.imageFocus').removeClass("imageFocus");
				view = "leftMenu";
				$('#'+contentView+'leftMenu-1').addClass("imageFocus");
			}
			else if(h_index > 0){
				h_index--;
				$('.imageFocus').removeClass("imageFocus");
				$('#hometvShows-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
			
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source == "topMenu"){
			if (index < menuCount-1) {
				index++;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'TopMenu-' + index).addClass("imageFocus");
				$('#'+contentView+'TopMenu-' + (index-8)).hide();
				$('#'+contentView+'TopMenu-' + (index)).show();
			}
		}
		else{
			if(h_index < 4){
				h_index++;
				$('.imageFocus').removeClass("imageFocus");
				$('#hometvShows-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
		
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(source != "topMenu"){
				if(v_index > 0){
					$("#tvShowList").prepend(Util.addTvRow((v_index-1)));
					$("#tvShowRow-"+(v_index-1)).show();
					v_index --;
					$('.imageFocus').removeClass("imageFocus");
					$('#hometvShows-'+v_index+"-"+h_index).addClass("imageFocus");
					$("#tvShowRow-"+(v_index+2)).remove();
				}
				else{
					if(source != "topMenu" && id != "searchBox"){
						homeFocus = $('.imageFocus').attr('id');
						$('.imageFocus').removeClass("imageFocus");
						$('.tvmenuSelected').addClass("imageFocus");
						
					}
				}
			}
			else  if(source == "topMenu"){
				menuFocus = index;
				$('.imageFocus').removeClass("imageFocus");
				$(".searchBar").addClass("imageFocus");
				$(".searchBar").focus();
			}
			
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.tvShowsKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {

		var id = $('.imageFocus').attr("id");
		if(id == "searchBox"){
			$("#searchBox").blur();
			$('.imageFocus').removeClass("imageFocus");
			if(menuFocus)
			{
				$('#tvShowsTopMenu-'+menuFocus).addClass("imageFocus");
			}
			else{
				$('#'+contentView+'leftMenu-' + 0).addClass("imageFocus");view = "leftMenu";
			}
			
		}
		else if(source == "topMenu"){
				
				$('.imageFocus').removeClass("imageFocus");
				if(homeFocus.indexOf("topMenu") != -1)
					homeFocus = '';
				if(homeFocus)
					$('#'+homeFocus).addClass("imageFocus");
				else
				$('#hometvShows-'+0+"-"+0).addClass("imageFocus");
			}
			else if(v_index < (count/5)-1){
				$("#tvShowRow-"+(v_index)).remove();
				v_index ++;
				$('.imageFocus').removeClass("imageFocus");

				if((v_index * 5)+h_index < count-1 )
					$('#hometvShows-'+v_index+"-"+h_index).addClass("imageFocus");
				else
					$('#hometvShows-'+v_index+"-"+ ( (count-1) % 5)).addClass("imageFocus");

				
				$("#tvShowList").append(Util.addTvRow((v_index+1)));
				$("#tvShowRow-"+(v_index+1)).show();
			}
			break;
		}
	case tvKeyCode.Return: {
			
			break;
		}
	default: {
			break;
		}
	}
}
Keyhandler.tvShowsKeyEnter = function (currFocus) {
	Main.ShowLoading();
	var index = parseInt(currFocus.attr("index"));

	var source = currFocus.attr("source");
	var id = currFocus.attr("id");
	var attrid = currFocus.attr("attrid");
	var count = parseInt(currFocus.attr("count"));

	if(source == "topMenu"){
		$(".tvmenuSelected").removeClass("tvmenuSelected");
		if($(".mouseFocus").attr("source") == "topMenu"){
			$('.imageFocus').removeClass("imageFocus");
			$(".mouseFocus").addClass("imageFocus");
		}
		Main.updatetvShowSections(attrid);
		$("#tvShowsTopMenu-"+index).addClass("tvmenuSelected");
	}
	else if(id == "searchBox"){
		var searchVal = $("#searchBox").val();
		if(searchVal)
			Main.searchData("tv",searchVal);	
	}
	else{
		var imdb = currFocus.attr("imdb");
		if(imdb)
			Main.getTvShowDetails(imdb);
		else
			Main.HideLoading();
	}
	
	
}


Keyhandler.adultShowDetailKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}

	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");

	var count =  parseInt($('.imageFocus').attr("count"));
	var source = $('.imageFocus').attr("source");
	var s = parseInt($('.imageFocus').attr("season"));
	 
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		if(source == "eps"){
			if (index > 0) {
				if(index == count){
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#eps-' + index).addClass("imageFocus");
	
					if($("#eps-"+(index+4)).html() && (index) > 3){
						$("#eps-"+(index+4)).remove();
					}
				}
				else{
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#eps-' + index).addClass("imageFocus");
	
					if($("#eps-"+(index+4)).html() ) {
						$("#eps-"+(index+4)).remove();
					}
	
					if((index-1) >= 0){
						$("#episodes").prepend(Util.adultEpsCardGenerate((index-1),s));
					}
				}
				
				
			}
			else{
				gotoLeftMenu()
			}
		}
		else {
			if(id == "watchList"){
				$('#watchList').removeClass("imageFocus");
				$('#SP-btn-1').addClass("imageFocus");
			}
			else{
				gotoLeftMenu();
			}

			
		}
		
		
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source != "SPbuttons"){
			if (index < count-1) {
				
				index++;

				$('.imageFocus').removeClass("imageFocus");
				$('#eps-' + index).addClass("imageFocus");

				if($("#eps-"+(index-2)).html() && (index) < adultShowDetail.episodes.length){
					$("#eps-"+(index-2)).remove();
				}
				if(!$("#eps-"+(index+2)).html() && (index+1) < adultShowDetail.episodes.length)
				$("#episodes").append(Util.adultEpsCardGenerate((index+2),s));
			}
		}
		else{
			if(id == "SP-btn-1"){
				$('#SP-btn-1').removeClass("imageFocus");
				$('#watchList').addClass("imageFocus");
			}
		}
		
			break;
		}
	case tvKeyCode.ArrowUp: {
		if(source == "eps"){
			tvEPSIndex = index;
			$('.imageFocus').removeClass("imageFocus");
			$('#SP-btn-1').addClass('imageFocus');	
			TweenMax.to($(".scrollSingleDiv"), 0.4, {
				top : '109%',
				ease : Power1.easeInOut
			});
		}	
		break;
	}
	case tvKeyCode.Enter: {
			
		Keyhandler.adultShowDetailEnter($(".imageFocus"));
	break;
	}
	case tvKeyCode.ArrowDown: {
		if(source != "eps"){
			TweenMax.to($(".scrollSingleDiv"), 0.4, {
				top : -300,
				ease : Power1.easeInOut
			});
			$('.imageFocus').removeClass("imageFocus");
			$('#eps-' + tvEPSIndex).addClass('imageFocus');
		
		}
		
			break;
	}
	case tvKeyCode.Return:
	case 8: {
		$("#SingleMoviePage").hide();
		$("#SingleMoviePage").html('');
		try {
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			contentView = view;
			homeFocus = '';
			tvEPSIndex = 1;
		} catch (e) {}
		
		Main.processNext();
		break;
		}
	default: {
			break;
		}
	}
}
Keyhandler.adultShowDetailEnter = function (currFocus) {
	Main.ShowLoading();
	var index = parseInt(currFocus.attr("index"));

	var source = currFocus.attr("source");
	Player.name = adultShowDetail.name;
	
	index++;

	if(source == "SPbuttons"){
		Main.playStream("tt6969696",adultShowDetail.id,1);
	}
	else{
		Main.playStream("tt6969696",adultShowDetail.id,index);
	}
	
	
}






var tvEPSIndex = 1;
Keyhandler.tvShowDetailKeyhandler = function(e){
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}

	var index = parseInt($('.imageFocus').attr("index"));
	var id = $('.imageFocus').attr("id");

	var count =  parseInt($('.imageFocus').attr("count"));
	var source = $('.imageFocus').attr("source");
	var s = parseInt($('.imageFocus').attr("season"));
	 
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		if(source == "eps"){
			if (index > 1) {
				if(index == count){
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#eps-' + index).addClass("imageFocus");
	
					if($("#eps-"+(index+4)).html() && (index) > 3){
						$("#eps-"+(index+4)).remove();
					}
				}
				else{
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#eps-' + index).addClass("imageFocus");
	
					if($("#eps-"+(index+4)).html() ) {
						$("#eps-"+(index+4)).remove();
					}
	
					if((index-1) >= 1){
						$("#episodes").prepend(Util.generateTVEPSCard((index-1),s));
					}
				}
				
				
			}
			else{
				gotoLeftMenu()
			}
		}
		else {
			if(id == "watchListBtn"){
				$('#watchListBtn').removeClass("imageFocus");
				$('#SP-btn-1').addClass("imageFocus");
			}
			else{
				gotoLeftMenu();
			}

			
		}
		
		
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source != "SPbuttons"){
			if (index < count) {
				
				index++;

				$('.imageFocus').removeClass("imageFocus");
				$('#eps-' + index).addClass("imageFocus");

				if($("#eps-"+(index-2)).html() && (index) < Object.keys(tvShowDetail.seasons[s]).length){
					$("#eps-"+(index-2)).remove();
				}
				if(!$("#eps-"+(index+3)).html() && (index+2) < Object.keys(tvShowDetail.seasons[s]).length)
				$("#episodes").append(Util.generateTVEPSCard((index+3),s));
			}
		}
		else{
			if(id == "SP-btn-1"){
				$('#SP-btn-1').removeClass("imageFocus");
				$('#watchListBtn').addClass("imageFocus");
			}
		}
		
			break;
		}
	case tvKeyCode.ArrowUp: {
		if(source == "eps"){
			tvEPSIndex = index;
			$('.imageFocus').removeClass("imageFocus");
			$('#SP-btn-1').addClass('imageFocus');	
			TweenMax.to($(".scrollSingleDiv"), 0.4, {
				top : '109%',
				ease : Power1.easeInOut
			});
		}	
		break;
	}
	case tvKeyCode.Enter: {
			
		Keyhandler.tvShowDetailEnter($(".imageFocus"));
	break;
	}
	case tvKeyCode.ArrowDown: {
		if(source != "eps"){
			TweenMax.to($(".scrollSingleDiv"), 0.4, {
				top : -300,
				ease : Power1.easeInOut
			});
			$('.imageFocus').removeClass("imageFocus");
			$('#eps-' + tvEPSIndex).addClass('imageFocus');
		
		}
		
			break;
	}
	case tvKeyCode.Return:
	case 8: {
		$("#SingleMoviePage").hide();
		$("#SingleMoviePage").html('');
		try {
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			contentView = view;
			homeFocus = '';
			tvEPSIndex = 1;
		} catch (e) {}
		
		Main.processNext();
		break;
		}
	default: {
			break;
		}
	}
}

Keyhandler.signInKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");
	switch (keycode) {
     case 65376: { // Done{
          $('.imageFocus').blur();
          break;
     }
     case 65385: {
          $('.imageFocus').blur();
          break;
     } // Cancel
	case tvKeyCode.ArrowLeft: {

			break;
		}
	case tvKeyCode.ArrowRight: {

			break;
		}
	case tvKeyCode.ArrowUp: {
			if(id == "password"){
				$('.imageFocus').blur();
				$('.imageFocus').removeClass("imageFocus");
				$('#email').addClass('imageFocus');
				
			}else if(id == "login"){
				$('.imageFocus').blur();
				$('.imageFocus').removeClass("imageFocus");
				$('#password').addClass('imageFocus');
				
			}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.signInEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
			if(id == "email"){
				$('.imageFocus').blur()
				$('.imageFocus').removeClass("imageFocus");
				$('#password').addClass('imageFocus');
				
			}else if(id == "password"){
				$('.imageFocus').blur()
				$('.imageFocus').removeClass("imageFocus");
				$('#login').addClass('imageFocus');
				//$('#login').focus();
			}
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			if(stack.length){
				$("#signIn").hide();
				$("#signIn").html("");
				var obj = popState();
				view = obj.view;
				previousFocus = obj.focus;
				Main.processNext();
			}
			break;
		}
	default: {
			break;
		}
	}

}
Keyhandler.tvShowDetailEnter = function(currFocus){
	var index = parseInt(currFocus.attr("index"));
	var id = currFocus.attr("id");

	var count =  parseInt(currFocus.attr("count"));
	var source = currFocus.attr("source");
	var s = parseInt(currFocus.attr("season"));
	var e = parseInt(currFocus.attr("eps"));
	Player.name = tvShowDetail.title;
	if(source == "eps"){
		var imdb = currFocus.attr("imdb");
		Player.season = s;
		Player.eps = e;
		Main.playStream(imdb,s,e);
	}
	else{
		var season = parseInt(currFocus.text().replace("Season Selected - ",""));
		if(id == "SP-btn-1"){
			Main.ShowMenu(season);
		}
		else if(id == "watchListBtn"){
			if($(currFocus.selector + " span").text().indexOf("Add") != -1){
				Main.hitWatchList("add",0,tvShowDetail.imdb,0,0);$(currFocus.selector + " span").text("Remove From Watchist")
			}
			else{
				Main.hitWatchList("remove",0,tvShowDetail.imdb,0,0);$(currFocus.selector + " span").text("Add to Watchist");
			}
		}
	}
	

}
Keyhandler.signInEnter = function(currFocus){
	var id = currFocus.attr("id");

	if(id == "login"){
		Main.login($("#email").val(),$("#password").val());
	}
	else if(id){
		if($("#"+id).is(":focus")){

			$("#"+id).blur();
			if(id == "email"){
				$(".imageFocus").removeClass("imageFocus");
				$("#password").focus();
				$("#password").addClass("imageFocus");
			}
			else if(id == "password"){
				$(".imageFocus").removeClass("imageFocus");
				$("#login").addClass("imageFocus");
			}
				
		}
		else{
			$("#"+id).focus();
		}
	}

}
Keyhandler.seasonsListEnter = function(currFocus){
	if(stack.length >0 && stack[stack.length-1].view == "tvGuide"){
		epgSelectedDate = new Date(currFocus.text());
		Main.ShowLoading();
 		setTimeout(function(){
 			Keyhandler.getSelectedDateEPG();
 		},100);
		/* $('.list_vertical #navBar').nextAll().remove();
		tvGuideCurrentList = [];
		previousRowIndex = "";
		currentActive_prog_id = [];
		$(".list_vertical #navBar").after(Util.epgProgramSection(tvGuideChannelList));
		$('#goLiveButton').text(Util.displayDateFormat(epgSelectedDate));
		if(new Date().getDay() != epgSelectedDate.getDay())
			$('#liveBar').hide();
		else{
			$(".prog_list_width").css("margin-left",Main.getEPGScrollPos()+"px");
			$("#liveBar").css('margin-left',currentLiveBarPistion+"px");
			clearInterval(liveBar);
		    liveBar = setInterval(function(){ liveBarFunction() }, 30000);
			$('#liveBar').show();
		}
		$('#changeDate').text(formatDate(epgSelectedDate));
		$("#customMessage").hide();
		$("#customMessage").html("");
		$('#channel_0').addClass('imageFocus');
		var obj = popState();
		view = obj.view;
 */
	}else{
		Main.ShowLoading();
	var id = currFocus.attr("id");
	var season = currFocus.text().replace("Season - ","")
	
	
	Main.updateEpisodes(season);

	$("#customMessage").hide();
	$("#customMessage").html("");
	var obj = popState();
	view = obj.view;
	previousFocus = obj.focus;
	Main.processNext();

	Main.HideLoading();
	}
}

Keyhandler.seasonsListKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");

	var index = parseInt($('.imageFocus').attr("index"));
	var count =  parseInt($('.imageFocus').attr("count"));

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {

			break;
		}
	case tvKeyCode.ArrowRight: {

			break;
		}
	case tvKeyCode.ArrowUp: {
		if(index > 0){
			index--;
			$('.imageFocus').removeClass("imageFocus");
			$('#ssList-'+index).addClass('imageFocus');
		}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.seasonsListEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
		if(index < count-1){
			index++;
			$('.imageFocus').removeClass("imageFocus");
			$('#ssList-'+index).addClass('imageFocus');
		}
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			$("#customMessage").hide();
			$("#customMessage").html("");
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			Main.processNext();
			break;
		}
	default: {
			break;
		}
	}

}
Keyhandler.confirmPinKeyDown  = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		    
			break;
		}
	case tvKeyCode.ArrowRight: {
		
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(id == "changePin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#oldPin').addClass('imageFocus');
			}
			break;
		}
	case tvKeyCode.Enter: {
		    Keyhandler.confirmPinEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
		    if(id == "oldPin"){
				$('.imageFocus').blur();
				$('.imageFocus').removeClass("imageFocus");
				$('#changePin').addClass('imageFocus');
			}
			
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			$("#customMessage").hide();
			$("#customMessage").html("");$('.imageFocus').removeClass("imageFocus");
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			Main.processNext();
			break;
		}
	default: {
			break;
		}
	}

}
Keyhandler.confirmPinEnter =   function(currFocus){
	var id = currFocus.attr("id");
	if(id == "changePin"){
		
		if($('#oldPin').val() != Main.pin){
			$(".errorHead").text("Please enter valid Pin");
		}
		else{
			$("#customMessage").hide();
			$("#customMessage").html("");$('.imageFocus').removeClass("imageFocus");
			Main.getAdultMovies();
		}
		
	}
	else{
		$('#oldPin').focus();
	}
}
Keyhandler.changePinKeyDown  = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		    
			break;
		}
	case tvKeyCode.ArrowRight: {
		
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(id == "confirmPin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#newPin').addClass('imageFocus');
			}
			else if(id == "newPin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#oldPin').addClass('imageFocus');
			}
			else if(id == "changePin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#confirmPin').addClass('imageFocus');
			}
			break;
		}
	case tvKeyCode.Enter: {
		    Keyhandler.changePinEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
		    if(id == "newPin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#confirmPin').addClass('imageFocus');
			}
			else if(id == "oldPin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#newPin').addClass('imageFocus');
			}
			else if(id == "confirmPin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#changePin').addClass('imageFocus');
			}
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			$("#customMessage").hide();
			$("#customMessage").html("");$('.imageFocus').removeClass("imageFocus");
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			$('#'+previousFocus).addClass('imageFocus');
			Main.processNext();
			break;
		}
	default: {
			break;
		}
	}

}
Keyhandler.changePinEnter =   function(currFocus){
	var id = currFocus.attr("id");
	if(id == "changePin"){
		if(!$('#oldPin').val() == Main.profile.pin){
			$(".errorHead").text("Please enter valid Pin");
		}
		else if($('#newPin').val()){
			$(".errorHead").text("Enter valid pin.");
		}
		else if( $('#newPin').val() != $('#confirmPin').val()){
			$(".errorHead").text("New pin and Confirmed pin are not same.");
		}
		else{
			Main.pin = $('#confirmPin').val();
			localStorage.setItem("pin",Main.pin);
			$("#customMessage").hide();
			$("#customMessage").html("");$('.imageFocus').removeClass("imageFocus");
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			$('#'+previousFocus).addClass('imageFocus');
			Main.processNext();
		}
	}
	else{
		$('#newPin').blur();$('#oldPin').blur();$('#confirmPin').blur();
		$('.imageFocus').focus();
	}
}
Keyhandler.profileKeyhandler = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
		    if(id == "loginSave"){
				$('.imageFocus').removeClass("imageFocus");
				$('#timeZone').addClass('imageFocus');
			}
			else if(id == "timeZone"){
				$('.imageFocus').removeClass("imageFocus");
				$('#changePin').addClass('imageFocus');
			}
			else if(id == "changePin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#adultBox').addClass('imageFocus');
			}
			break;
		}
	case tvKeyCode.ArrowRight: {
			if(id == "timeZone"){
				$('.imageFocus').removeClass("imageFocus");
				$('#loginSave').addClass('imageFocus');
			}
			else if(id == "changePin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#timeZone').addClass('imageFocus');
			}
			else if(id == "adultBox"){
				$('.imageFocus').removeClass("imageFocus");
				$('#changePin').addClass('imageFocus');
			}
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(id == "timeZone" && Main.profile.adult){
				$('.imageFocus').removeClass("imageFocus");
				$('#adultBox').addClass('imageFocus');
				
			}
			else if(id == "loginSave" && Main.profile.adult){
				$('.imageFocus').removeClass("imageFocus");
				$('#changePin').addClass('imageFocus');
				
			}
			break;
		}
	case tvKeyCode.Enter: {
		    Keyhandler.profileEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
			if(id == "adultBox"){
				$('.imageFocus').removeClass("imageFocus");
				$('#timeZone').addClass('imageFocus');
				
			}
			else if(id == "changePin"){
				$('.imageFocus').removeClass("imageFocus");
				$('#loginSave').addClass('imageFocus');
				
			}
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			$("#profile").hide();
			$("#profile").html("");
			var obj = popState();
			view = obj.view;
			if(view  == "homeMovies" || view  == "tvGuide" || view == "watchList" || view == "live" || view == "tvShows"){
				previousFocus = '';
			}
			else{
				previousFocus = obj.focus;
			}
			//previousFocus = obj.focus;
			Main.processNext();
			break;
		}
	default: {
			break;
		}
	}

}
Keyhandler.profileEnter = function(currFocus){
	var id = currFocus.attr("id");
	if(id == "timeZone"){
		Main.ShowTimeZone(Main.offset);
	}
	else if(id == "changePin"){
		pushState(view,currFocus.attr("id"));
		view = "changePin";
		$("#customMessage").html(Util.changePin());
		$("#customMessage").show();
	}
	else if(id == "adultBox"){
		if($("#adultBox input").prop("checked") == true){
			$("#adultBox input").prop("checked",false);
			Main.profile.showAdult = false;
			localStorage.setItem("profile",JSON.stringify(Main.profile));
		}
		else if($("#adultBox input").prop("checked") == false){

			pushState(view,currFocus.attr("id"));
			view = "popUp";
			$("#customMessage").html(Util.showPopUp1(1,'Apollo Group - Adults Section',"This section is designed for ADULTS only and include videos and materials that some viewers may find offensive. If you are under the age of 21 (or the legal adult age in your jurisdiction),if such material offends you or if it is illegal to view such material in your community please exit the section. The following terms and conditions apply to this section. Use of the section will constitute your agreement to the following terms and conditions: <br/> 1.) I am 21 years of age or older <br/> 2.) I accept all responsibility for my own actions; and <br/> 3.) I agree that I am legally bound to these Terms and Conditions","Confirm"));
			$("#customMessage").show();
               $("#Btn-0").addClass("imageFocus");
			callBack = function(){
				$("#adultBox input").prop("checked",true);
				Main.profile.showAdult = true;
				localStorage.setItem("profile",JSON.stringify(Main.profile));

			}
			
		}
		localStorage.setItem('profile', JSON.stringify(Main.profile));
	}
	else if(id == "loginSave"){
		if($("#loginSave input").prop("checked") == true){
			$("#loginSave input").prop("checked",false);
			Main.profile.saveLogin = false;
		}
		else if($("#loginSave input").prop("checked") == false){
			$("#loginSave input").prop("checked",true);
			Main.profile.saveLogin = true;
		}
		localStorage.setItem('profile', JSON.stringify(Main.profile));
	}

}
Keyhandler.timeZoneKeyhandler = function(e){
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");

	var index = parseInt($('.imageFocus').attr("index"));
	var count =  parseInt($('.imageFocus').attr("count"));

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {

			break;
		}
	case tvKeyCode.ArrowRight: {

			break;
		}
	case tvKeyCode.ArrowUp: {
		if(index > 0){
			index--;
			$('.imageFocus').removeClass("imageFocus");
			$('#timeList-'+index).addClass('imageFocus');
			$('#timeList-'+index).show();
			
			$('#timeList-'+(index+10)).hide();

		}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.timeZoneListEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
		if(index < count-1){
			index++;
			$('.imageFocus').removeClass("imageFocus");
			$('#timeList-'+index).addClass('imageFocus');
			$('#timeList-'+index).show();

			if(index >= 10){
				$('#timeList-'+(index-10)).hide();
			}
		}
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			$("#customMessage").hide();
			$("#customMessage").html("");
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			$('#'+previousFocus).addClass('imageFocus');
			break;
		}
	default: {
			break;
		}
	}

}

Keyhandler.timeZoneListEnter = function(currFocus){
	Main.ShowLoading();
	var id = currFocus.attr("id");
	var index = parseInt(currFocus.attr("index"));
	
	Main.offset = Object.keys(Main.timeZoneData)[index];
	$("#timeZone").text(Main.timeZoneData[Main.offset]);
	$("#customMessage").hide();
	$("#customMessage").html("");
	var obj = popState();
	view = obj.view;
	previousFocus = obj.focus;
	
	$('#'+previousFocus).addClass('imageFocus');

	Main.HideLoading();
}


Keyhandler.subTitleKeyhandler = function(e){
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	hoverOn = false;
	var source = $('.imageFocus').attr("source");
	var id = $('.imageFocus').attr("id");

	var index = parseInt($('.imageFocus').attr("index"));
	var count =  parseInt($('.imageFocus').attr("count"));

	switch (keycode) {
	case tvKeyCode.ArrowLeft: {

			break;
		}
	case tvKeyCode.ArrowRight: {

			break;
		}
	case tvKeyCode.ArrowUp: {
		if(index > 0){
			index--;
			$('.imageFocus').removeClass("imageFocus");
			$('#timeList-'+index).addClass('imageFocus');
			$('#timeList-'+index).show();
			
			$('#timeList-'+(index+10)).hide();

		}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.subTitleListEnter($(".imageFocus"));
			break;
		}
	case tvKeyCode.ArrowDown: {
		if(index < count-1){
			index++;
			$('.imageFocus').removeClass("imageFocus");
			$('#timeList-'+index).addClass('imageFocus');
			$('#timeList-'+index).show();

			if(index >= 10){
				$('#timeList-'+(index-10)).hide();
			}
		}
			break;
		}
	case tvKeyCode.Return:
	case 8: {
			$("#customMessage").hide();
			$("#customMessage").html("");
			var obj = popState();
			view = obj.view;
			previousFocus = obj.focus;
			$('#'+previousFocus).addClass('imageFocus');
			break;
		}
	default: {
			break;
		}
	}

}

Keyhandler.subTitleListEnter = function(currFocus){
	Main.ShowLoading();
	var id = currFocus.attr("id");
	var index = parseInt(currFocus.attr("index"));
	
	Main.offset = Object.keys(Main.timeZoneData)[index];
	$("#timeZone").text(Main.timeZoneData[Main.offset]);
	$("#customMessage").hide();
	$("#customMessage").html("");
	var obj = popState();
	view = obj.view;
	previousFocus = obj.focus;
	Main.processNext();

	Main.HideLoading();
}


Keyhandler.adultKeyDown = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var v_index = parseInt($('.imageFocus').attr("v_index"));
	var h_index = parseInt($('.imageFocus').attr("h_index"));
	
	var count =  0;
	var id = $('.imageFocus').attr("id");

	var focus = '',type = '';

	if(id.split("-")[0] == "homeMovies"){
		focus = "homeMovies";type = "movies";
		if(view == "search")
			count = Main.searchResults.length;
		else
			count = adultArray.movies.length;
	}
	else if(id.split("-")[0] == "homeLive"){
		focus = "homeLive";type = "live";
		if(view == "search")
			count = Main.searchResults.length;
		else
			count = adultArray.channels.length;
	}
	else if(id.split("-")[0] == "hometvShows"){
		focus = "hometvShows";type = "shows";count = Main.searchResults.length;
	}
	var source = $('.imageFocus').attr("source");
	var index = parseInt($('.imageFocus').attr("index"));
	var menuCount = parseInt($('.imageFocus').attr("count"));
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
			if(source == "topMenu"){
				if (index > 0) {
					index --;
					if($('#adultTopMenu-' + index).length){
						$('.imageFocus').removeClass("imageFocus");
						$('#adultTopMenu-' + index).addClass("imageFocus");
						$('#adultTopMenu-' + (index)).show();
					}		
			}
			else{
				gotoLeftMenu()
			}
		}
		else{
			if(h_index == 0){
				if(view != "search"){
					homeFocus = $('.imageFocus').attr('id');
					$('.imageFocus').removeClass("imageFocus");
					view = "leftMenu";
					$('#'+contentView+'leftMenu-6').addClass("imageFocus");
				}
				
			}
			else if(h_index > 0){
				h_index--;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
			
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source == "topMenu"){
			if (index < 3) {
				index++;
				if($('#adultTopMenu-' + index).length){
					$('.imageFocus').removeClass("imageFocus");
					$('#adultTopMenu-' + index).addClass("imageFocus");
				}
				
				
				
			}
		}
		else{
			if(h_index < 4 && index < count-1){
				h_index++;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
		
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(v_index > 0){
				
				$("#adultRow-"+(v_index-1)).show();
				v_index --;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
				$("#adultRow-"+(v_index+2)).hide();
			}
			else{
				if(source != "topMenu"){
					homeFocus = $('.imageFocus').attr('id');

					if($('#adultTopMenu-0').length || $('#adultTopMenu-1').length){
						$('.imageFocus').removeClass("imageFocus");
						
						if(focus == "homeMovies")
							$('#adultTopMenu-0').addClass("imageFocus");
						else if(focus == "homeLive")
							$('#adultTopMenu-1').addClass("imageFocus");
					}
					
					
					
				}
			}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.adultKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {
			if(source == "topMenu"){
				
				$('.imageFocus').removeClass("imageFocus");
				if(homeFocus)
					$('#'+homeFocus).addClass("imageFocus");
				else {
					var menuIndex = parseInt($(".menuSelected").attr("index"));
					if(menuIndex == 0){
						$('#homeMovies-0-0').addClass("imageFocus");
					}
					else{
						$('#homeLive-0-0').addClass("imageFocus");
					}
				}
				
			}
			else if(v_index < (count/5)-1){
				$("#adultRow-"+(v_index)).hide();
				v_index ++;
				$('.imageFocus').removeClass("imageFocus");
				if((v_index * 5)+h_index < count-1 )
					$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
				else
					$('#'+focus+'-'+v_index+"-"+ ( (count-1) % 5)).addClass("imageFocus");

				$("#adultRow-"+(v_index+1)).show();
			}
			break;
		}
	case tvKeyCode.Return: {
			if(view == "search"){
				var obj = popState();
				view = obj.view;
				previousFocus = obj.focus;
				contentView = view;
				homeFocus = '';
				Main.processNext();
			}
			break;
		}
	default: {
			break;
		}
	}
}

Keyhandler.adultKeyEnter = function(currFocus){
	var id = currFocus.attr("id");
	var focus = '',type = '';
	if(id.split("-")[0] == "homeMovies"){
		focus = "homeMovies";type = "movies";
		if(view == "search")
			count = Main.searchResults.length;
		else
			count = adultArray.movies.length;
	}
	else if(id.split("-")[0] == "homeLive"){
		focus = "homeLive";type = "live";
		if(view == "search")
			count = Main.searchResults.length;
		else
			count = adultArray.channels.length;
	}
	else if(id.split("-")[0] == "hometvShows"){
		focus = "hometvShows";type = "shows";
		if(view == "search")
			count = Main.searchResults.length;
	}

	var source = currFocus.attr("source");
	var index = parseInt(currFocus.attr("index"));
	var menuCount = parseInt(currFocus.attr("count"));
	
	if(source == "topMenu"){
		if(id == "adultTopMenu-0"){
			
			$('.menuSelected').removeClass("menuSelected");
			$('#'+id).addClass("menuSelected");
			$("#adultList").html(Util.adultMovies());homeFocus = 0;
		}
		else if(id == "adultTopMenu-1"){
			$('.menuSelected').removeClass("menuSelected");
			$('#'+id).addClass("menuSelected");
			$("#adultList").html(Util.adultLive());homeFocus = 0;
		}
	}
	else{
		if(view != "search"){
			if(focus == "homeMovies"){
				
			adultShowDetail = adultArray.movies[index];
			
			pushState(view,$(".imageFocus").attr("id"));
			$(".imageFocus").removeClass("imageFocus");
			$(".leftHigh").removeClass("leftHigh");
			$("#mainContent").hide();
			view = "adultShowDetail";
			contentView = view;
			$("#SingleMoviePage").html(Util.adultDetailPage(adultShowDetail)).show();
			$("#"+contentView+"leftMenu-6").addClass("leftHigh");
		
			Main.HideLoading();
			}
			else if(focus == "homeLive"){
				pushState(view,$(".imageFocus").attr("id"));
				hideValues();
				view = "liveTvDetail";
				contentView = view;
				$("#mainContent").hide();
				$('.imageFocus').removeClass("imageFocus");
				$('.leftHigh').removeClass("leftHigh");
				$("#SingleMoviePage").html(Util.liveTvDetailPage(adultArray.channels[index],index));
				$("#liveTvDetailleftMenu-2").addClass("leftHigh");
				$("#SingleMoviePage").show();
				Main.HideLoading();
			}
		}
		else{
			if(focus == "homeMovies"){
				//pushState(view,$(".imageFocus").attr("id"));
				var imdb = currFocus.attr("imdb");
				Main.getMovieDetails(imdb);
			}
			else if(focus == "homeLive"){
				pushState(view,$(".imageFocus").attr("id"));
				hideValues();
			
				view = "liveTvDetail";
				contentView = view;
				$("#mainContent").hide();
				$('.imageFocus').removeClass("imageFocus");
				$('.leftHigh').removeClass("leftHigh");
				$("#SingleMoviePage").html(Util.liveTvDetailPage(Main.searchResults[index],index));
				$("#liveTvDetailleftMenu-2").addClass("leftHigh");
				$("#SingleMoviePage").show();
				Main.HideLoading();
			}
			else if(focus == "hometvShows"){
				var imdb = currFocus.attr("imdb");
				Main.getTvShowDetails(imdb);
			}
		}
		
		
		
	}
}

Keyhandler.watchListKeyDown = function (e) {
	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var v_index = parseInt($('.imageFocus').attr("v_index"));
	var h_index = parseInt($('.imageFocus').attr("h_index"));
	
	var count = homeTvShowData.length;
	var id = $('.imageFocus').attr("id");
	var focus = '',type = '';
	if(id.split("-")[0] == "homeMovies"){
		focus = "homeMovies";type = "movies";count = watchlistMap["movies"].length;
	}
	else if(id.split("-")[0] == "homeLive"){
		focus = "homeLive";type = "live";count = watchlistMap["channel"].length;
	}else if(id.split("-")[0] == "hometvShows"){
		focus = "hometvShows";type = "shows";count = watchlistMap["tvshow"].length;
	}
	var source = $('.imageFocus').attr("source");
	var index = parseInt($('.imageFocus').attr("index"));
	var menuCount = parseInt($('.imageFocus').attr("count"));
	switch (keycode) {
	case tvKeyCode.ArrowLeft: {
			if(source == "topMenu"){
				if (index > 0) {
					index --;
					if($('#watchListTopMenu-' + index).length){
						$('.imageFocus').removeClass("imageFocus");
						$('#watchListTopMenu-' + index).addClass("imageFocus");
						$('#watchListTopMenu-' + (index)).show();
					}
					else if($('#watchListTopMenu-' + (index-1)).length){
						index--;
						$('.imageFocus').removeClass("imageFocus");
						$('#watchListTopMenu-' + index).addClass("imageFocus");
					}		
			}
			else{
				gotoLeftMenu()
			}
		}
		else{
			if(h_index == 0){
				homeFocus = $('.imageFocus').attr('id');
				$('.imageFocus').removeClass("imageFocus");
				view = "leftMenu";
				$('#'+contentView+'leftMenu-3').addClass("imageFocus");
			}
			else if(h_index > 0){
				h_index--;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
			
			break;
		}
	case tvKeyCode.ArrowRight: {
		if(source == "topMenu"){
			if (index < 3) {
				index++;
				if($('#watchListTopMenu-' + index).length){
					$('.imageFocus').removeClass("imageFocus");
					$('#watchListTopMenu-' + index).addClass("imageFocus");
				}
				else if($('#watchListTopMenu-' + (index+1)).length){
					index++;
					$('.imageFocus').removeClass("imageFocus");
					$('#watchListTopMenu-' + index).addClass("imageFocus");
				}
				
				
				
			}
		}
		else{
			if(h_index < 4 && h_index < count-1){
				h_index++;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
			}
		}
		
			break;
		}
	case tvKeyCode.ArrowUp: {
			if(v_index > 0){
				
				$("#watchRow-"+(v_index-1)).show();
				v_index --;
				$('.imageFocus').removeClass("imageFocus");
				$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
				$("#watchRow-"+(v_index+2)).hide();
			}
			else{
				if(source != "topMenu"){
					homeFocus = $('.imageFocus').attr('id');
					$('.imageFocus').removeClass("imageFocus");

					if(focus == "homeMovies")
						$('#watchListTopMenu-0').addClass("imageFocus");
					else if(focus == "homeLive")
						$('#watchListTopMenu-2').addClass("imageFocus");
					else if(focus == "hometvShows")
						$('#watchListTopMenu-1').addClass("imageFocus");
					
				}
			}
			break;
		}
	case tvKeyCode.Enter: {
			Keyhandler.watchListKeyEnter($('.imageFocus'));
			break;
		}
	case tvKeyCode.ArrowDown: {
			if(source == "topMenu"){
				
				$('.imageFocus').removeClass("imageFocus");
				if(homeFocus)
					$('#'+homeFocus).addClass("imageFocus");
				else {
					var menuIndex = parseInt($(".menuSelected").attr("index"));
					if(menuIndex == 0){
						$('#homeMovies-0-0').addClass("imageFocus");
					}
					else if(menuIndex == 1){
						$('#hometvShows-0-0').addClass("imageFocus");
					}
					else{
						$('#homeLive-0-0').addClass("imageFocus");
					}
				}
				
			}
			else if(v_index < (count/5)-1){
				$("#watchRow-"+(v_index)).hide();
				v_index ++;
				$('.imageFocus').removeClass("imageFocus");
				if((v_index * 5)+h_index < count-1 )
					$('#'+focus+'-'+v_index+"-"+h_index).addClass("imageFocus");
				else
					$('#'+focus+'-'+v_index+"-"+ ( (count-1) % 5)).addClass("imageFocus");

				$("#watchRow-"+(v_index+1)).show();
			}
			break;
		}
	case tvKeyCode.Return: {
			
			break;
		}
	default: {
			break;
		}
	}
}

Keyhandler.watchListKeyEnter = function(currFocus){

	var id = currFocus.attr("id");
	var focus = '',type = '';
	if(id.split("-")[0] == "homeMovies"){
		focus = "homeMovies";type = "movies";count = watchlistMap["movies"].length;
	}
	else if(id.split("-")[0] == "homeLive"){
		focus = "homeLive";type = "live";count = watchlistMap["channel"].length;
	}else if(id.split("-")[0] == "hometvShows"){
		focus = "hometvShows";type = "shows";count = watchlistMap["tvshow"].length;
	}
	var source = currFocus.attr("source");
	var index = parseInt(currFocus.attr("index"));
	var menuCount = parseInt(currFocus.attr("count"));
	
	if(source == "topMenu"){
		if(id == "watchListTopMenu-0"){
			
			$('.menuSelected').removeClass("menuSelected");
			$('#'+id).addClass("menuSelected");
			Main.getWatchListData("movie")
		}
		else if(id == "watchListTopMenu-1"){
			$('.menuSelected').removeClass("menuSelected");
			$('#'+id).addClass("menuSelected");
			Main.getWatchListData("show")
		}
		else if(id == "watchListTopMenu-2"){
			$('.menuSelected').removeClass("menuSelected");
			$('#'+id).addClass("menuSelected");
			Main.getWatchListData("live")
		}
	}
	else{

		if(focus == "homeMovies"){
			var imdb = currFocus.attr("imdb");
			Main.getMovieDetails(imdb);
		}
		else if(focus == "homeLive"){
			pushState(view,$(".imageFocus").attr("id"));
			hideValues();
		
			view = "liveTvDetail";
			contentView = view;
			$("#mainContent").hide();
			$('.imageFocus').removeClass("imageFocus");
			$('.leftHigh').removeClass("leftHigh");
			$("#SingleMoviePage").html(Util.liveTvDetailPage(watchlistMap["channel"][index],index));
			$("#liveTvDetailleftMenu-2").addClass("leftHigh");
			$("#SingleMoviePage").show();
			Main.HideLoading();
		}
		else if(focus == "hometvShows"){
			var imdb = currFocus.attr("imdb");
			Main.getTvShowDetails(imdb);
		}
	}

	
}
Keyhandler.getSelectedDateEPG = function(){
	Main.ShowLoading();
	tvGuideProgramsList = [];
		for(var i=0;i< 10;i++){
			if(i== 0)
				tempChannelList = '"'+tvGuideChannelList[i].epg.toLowerCase()+'"';
			else
				tempChannelList = tempChannelList + "," + '"' + tvGuideChannelList[i].epg.toLowerCase() + '"';
			//Main.getChannelGuide(tvGuideChannelList[i].epg.toLowerCase());
		}
		//Main.getChannelGuide(tvGuideChannelList[i].epg.toLowerCase());
		Main.getChannelGuide(tempChannelList);
		
	$('.list_vertical #navBar').nextAll().remove();
		tvGuideCurrentList = [];
		previousRowIndex = "";
		currentActive_prog_id = [];
		$(".list_vertical #navBar").after(Util.epgProgramSection(tvGuideChannelList));
		$('#goLiveButton').text(Util.displayDateFormat(epgSelectedDate));
		if(Main.getOffsetDate().getDay() != epgSelectedDate.getDay())
			$('#liveBar').hide();
		else{
			$(".prog_list_width").css("margin-left",Main.getEPGScrollPos()+"px");
			$("#liveBar").css('margin-left',currentLiveBarPistion+"px");
			clearInterval(liveBar);
		    liveBar = setInterval(function(){ liveBarFunction() }, 30000);
			$('#liveBar').show();
		}
		$('#changeDate').text(formatDate(epgSelectedDate));
		$("#customMessage").hide();
		$("#customMessage").html("");
		$('#channel_0').addClass('imageFocus');
		Keyhandler.updateProgInfo(currentActive_prog_id[0],0);
		if(stack.length>0){
			var obj = popState();
			view = obj.view;
		}
		
	Main.HideLoading();
		
}
var previousRowIndex = '';
Keyhandler.tvGuideKeyHandler = function(e){
 	var keycode;
	var userAgent = new String(navigator.userAgent);
	if (window.event) {
		keycode = e.keyCode;
	} else if (e.which) {
		keycode = e.which;
	}
	
	var source = $(".imageFocus").attr("source");
	switch (keycode) {
		case tvKeyCode.ArrowLeft: {
			totalDuration = 0;
			if(source == "topMenu"){
				var index = parseInt($('.imageFocus').attr("index"));
				
				var count = parseInt($('.imageFocus').attr("count"));
				if (index > 0) {
					index--;
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).addClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).show();
				//	if((index) > 4){
						$('#'+contentView+'TopMenu-' + (index)).show();
						$('#'+contentView+'TopMenu-' + (index+8)).hide();
				//	}
						
				
			}
			else{
				menuFocus = $('.imageFocus').attr("index");
				view = "leftMenu";
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'leftMenu-4').addClass("imageFocus");
			}
		}
		else if(source == 'prgrams_data'){
				
				var rowIndex = $(".imageFocus").attr("rowIndx");
				var colIndex = $(".imageFocus").attr("index");
				var currStartTime = parseInt($(".imageFocus").attr("startepochtime"));
				var current_EndTime = parseInt($(".imageFocus").attr("endepochtime"));

				if(colIndex > 0){
					colIndex--;
					var hrs = tvGuideCurrentList[rowIndex][colIndex].start.substring(8,10);
					var Minutes = tvGuideCurrentList[rowIndex][colIndex].start.substring(10,12);
					var currentMargin = parseInt($('.prog_list_width').css('margin-left').replace('px',''));
					if(window_Width == 1280){
						var epgScrollPos = (hrs*360)+(Minutes*6);
						if(colIndex == 0)
							$(".prog_list_width").css('margin-left', 0);
						else if(epgScrollPos>180 && epgScrollPos<7980)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-180));
						else if((epgScrollPos > 0 && epgScrollPos<360) && currentMargin < -100)
							$(".prog_list_width").css('margin-left', 0);
					}else{
						var epgScrollPos = (hrs*600)+(Minutes*10);
						if(colIndex == 0)
							$(".prog_list_width").css('margin-left', 0);
						else if(epgScrollPos>300 && epgScrollPos<13350)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-300));
						else if((epgScrollPos > 0 && epgScrollPos<600) && currentMargin < -100)
							$(".prog_list_width").css('margin-left', 0);
					}
					
					$(".imageFocus").removeClass("imageFocus");
					$("#epgData_"+rowIndex+'_'+colIndex).addClass("imageFocus");
					currentActive_prog_id[rowIndex] = colIndex;
					Keyhandler.updateProgInfo(colIndex,rowIndex);
				}else if(colIndex == 0){
					previousRowIndex = rowIndex;
					$(".imageFocus").removeClass("imageFocus");
					$("#channel_"+rowIndex).addClass("imageFocus");
				}
			}
			else if(source == "buttons"){
				if(gannerCodeList || languageList ){
					var currentId = $(".imageFocus").attr("id");
				
					if(currentId == "gannerCodeList" && languageList.length>0){
						$(".imageFocus").removeClass("imageFocus");
						$("#languageList").addClass("imageFocus");
					}else if(currentId == "languageList" && gannerCodeList.length>0){
						$(".imageFocus").removeClass("imageFocus");
						$("#gannerCodeList").addClass("imageFocus");
					}
					
				}
				
			}
			else if(source == "channels"){
				contentView = view;
				view = "leftMenu";
				homeFocus = $('.imageFocus').attr('id');
				$('.imageFocus').removeClass("imageFocus");
				$('#'+contentView+'leftMenu-4').addClass("imageFocus");
			}
			break;
		}
		case tvKeyCode.ArrowRight: {
			if(source == "topMenu"){
				var index = parseInt($('.imageFocus').attr("index"));
				
				var count = parseInt($('.imageFocus').attr("count"));
				if (index < count-1) {
					index++;
					$('.imageFocus').removeClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).addClass("imageFocus");
					$('#'+contentView+'TopMenu-' + index).show();
					//	if(index > 4){
					$('#'+contentView+'TopMenu-' + (index-8)).hide();
					$('#'+contentView+'TopMenu-' + (index)).show();
					//	}
				}
			}
			else if(source == 'prgrams_data'){
				var rowIndex = $(".imageFocus").attr("rowIndx");
				var colIndex = $(".imageFocus").attr("index");
				var currStartTime = parseInt($(".imageFocus").attr("startepochtime"));
				var current_EndTime = parseInt($(".imageFocus").attr("endepochtime"));

				if(colIndex < tvGuideCurrentList[rowIndex].length-1){
					colIndex++;
					var hrs = tvGuideCurrentList[rowIndex][colIndex].start.substring(8,10);
					var Minutes = tvGuideCurrentList[rowIndex][colIndex].start.substring(10,12);
					var currentMargin = parseInt($('.prog_list_width').css('margin-left').replace('px',''));
					if(window_Width == 1280){
						var epgScrollPos = (hrs*360)+(Minutes*6);
						if(epgScrollPos>360 && epgScrollPos<7980)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-180));
						else if(currentMargin< 0 && currentMargin > -7740)
							$(".prog_list_width").css('margin-left', "-7740px");
					}else{
						var epgScrollPos = (hrs*600)+(Minutes*10);
						if(epgScrollPos>600 && epgScrollPos<13200)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-300));
						else if(currentMargin< 0 && currentMargin > -12900)
							$(".prog_list_width").css('margin-left', "-12900px");
					}
					$(".imageFocus").removeClass("imageFocus");
					$("#epgData_"+rowIndex+'_'+colIndex).addClass("imageFocus");
					currentActive_prog_id[rowIndex] = colIndex;
					Keyhandler.updateProgInfo(colIndex,rowIndex);
				}else if(colIndex == tvGuideCurrentList[rowIndex].length-1 || tvGuideCurrentList[rowIndex].length == 0){
					var myDate = Main.getOffsetDate();
					myDate.setDate(myDate.getDate()+6);
					if(epgSelectedDate < myDate){
						epgSelectedDate.setDate(epgSelectedDate.getDate()+1);
						//Keyhandler.getSelectedDateEPG();
						Main.ShowLoading();
				 		setTimeout(function(){
				 			Keyhandler.getSelectedDateEPG();
				 		},100);
					}
				}
				
			}
			else if(source == "channels"){
				var current_Channel_Index = $(".imageFocus").attr("index");
				$(".imageFocus").removeClass("imageFocus");
				if(previousRowIndex == current_Channel_Index){
					$("#epgData_"+current_Channel_Index+'_'+currentActive_prog_id[current_Channel_Index]).addClass("imageFocus");
				}else{
					$("#epgData_"+current_Channel_Index+'_'+currentActive_prog_id[current_Channel_Index]).addClass("imageFocus");
					/*var hrs = tvGuideCurrentList[current_Channel_Index][currentActive_prog_id[current_Channel_Index]].start.substring(8,10);
					var Minutes = tvGuideCurrentList[current_Channel_Index][currentActive_prog_id[current_Channel_Index]].start.substring(10,12);
					if(window_Width == 1280){
						var epgScrollPos = (hrs*360)+(Minutes*6);
						if(epgScrollPos>360 && epgScrollPos<8100)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-180));
					}else{
						var epgScrollPos = (hrs*600)+(Minutes*10);
						if(epgScrollPos>600 && epgScrollPos<13350)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-300));
					}*/
					
				}

				var hrs = tvGuideCurrentList[current_Channel_Index][currentActive_prog_id[current_Channel_Index]].start.substring(8,10);
				var Minutes = tvGuideCurrentList[current_Channel_Index][currentActive_prog_id[current_Channel_Index]].start.substring(10,12);
				var currentMargin = parseInt($('.prog_list_width').css('margin-left').replace('px',''));
				if(window_Width == 1280){
					var epgScrollPos = (hrs*360)+(Minutes*6);
					if(epgScrollPos>360 && epgScrollPos<8100)
						$(".prog_list_width").css('margin-left', -(epgScrollPos-180));
					else if(epgScrollPos>= 0 && epgScrollPos<=360)
						$(".prog_list_width").css('margin-left', "0px");
					else if(currentMargin< 0 && currentMargin > -7740)
						$(".prog_list_width").css('margin-left', "-7740px");
				}else{
					var epgScrollPos = (hrs*600)+(Minutes*10);
					if(epgScrollPos>600 && epgScrollPos<13350)
						$(".prog_list_width").css('margin-left', -(epgScrollPos-300));
					else if(epgScrollPos>= 0 && epgScrollPos<=600)
						$(".prog_list_width").css('margin-left', "0px");
					else if(currentMargin<= 0 && currentMargin > -12900)
						$(".prog_list_width").css('margin-left', "-12900px");
				}
				/*for(var y=0;y<currentActive_prog_id.length;y++){
						if(y == current_Channel_Index){
							$("#epgData_"+y+'_'+currentActive_prog_id[y]).addClass("imageFocus");		
							break;
						}
						
					}*/
			}

			else if(source == "buttons"){
				if(gannerCodeList || languageList ){
					var currentId = $(".imageFocus").attr("id");
					
					if(currentId == "gannerCodeList" && languageList.length>0){
						$(".imageFocus").removeClass("imageFocus");
						$("#languageList").addClass("imageFocus");
					}else if(currentId == "languageList" && gannerCodeList.length>0){
						$(".imageFocus").removeClass("imageFocus");
						$("#gannerCodeList").addClass("imageFocus");
					}
					
				}
				
			}
			
			break;
		}case tvKeyCode.ArrowUp: {
				totalDuration = 0;
				if(source == 'prgrams_data'){
				
					//lastIndexFocused = false;
					var current_Prog_Index = $(".imageFocus").attr("rowIndx");
					var currer = current_Prog_Index;
					current_Prog_Index--;
					if(currentActive_prog_id[current_Prog_Index] == undefined)
						current_Prog_Index--;

					/*if(current_Prog_Index < -1){
						$(".imageFocus").removeClass("imageFocus");
						if(last_selected_date != undefined )
							$("#"+last_selected_date).addClass("imageFocus");
						else
							$(".date_active").addClass("imageFocus");
					}else*/ 
					if(current_Prog_Index >= 0){
						
						if(current_Prog_Index>3){
								/*$("#entireDataRow_"+currer).css("display", "none");
							$("#channel_"+currer).css("display", "none");*/
						}
						if(currentActive_prog_id[currer-1] == undefined)
							var hideROwIndex = currer- 5;
						else
							var hideROwIndex = currer- 4;

							if($("#entireDataRow_"+(hideROwIndex+1)).css("display") == 'none'){
								$("#entireDataRow_"+(hideROwIndex+1)).css("display", "block");	
								$("#channel_"+(hideROwIndex+1)).css("display", "block");
							}
							$("#entireDataRow_"+hideROwIndex).css("display", "block");
							$("#channel_"+hideROwIndex).css("display", "block");
							$(".imageFocus").removeClass("imageFocus");
							$("#epgData_"+current_Prog_Index+'_'+currentActive_prog_id[current_Prog_Index]).addClass("imageFocus");	
						/*}else{
							$(".imageFocus").removeClass("imageFocus");
							$("#epgData_"+current_Prog_Index+'_'+currentActive_prog_id[current_Prog_Index]).addClass("imageFocus");	
						}*/
						if(tvGuideCurrentList[current_Prog_Index].length > 0){
							var hrs = tvGuideCurrentList[current_Prog_Index][currentActive_prog_id[current_Prog_Index]].start.substring(8,10);
							var Minutes = tvGuideCurrentList[current_Prog_Index][currentActive_prog_id[current_Prog_Index]].start.substring(10,12);
							var currentMargin = parseInt($('.prog_list_width').css('margin-left').replace('px',''));
							if(window_Width == 1280){
								var epgScrollPos = (hrs*360)+(Minutes*6);
								if(epgScrollPos>360 && epgScrollPos<8100)
									$(".prog_list_width").css('margin-left', -(epgScrollPos-180));
								else if(epgScrollPos>= 0 && epgScrollPos<=360)
									$(".prog_list_width").css('margin-left', "0px");
								else if(currentMargin< 0 && currentMargin > -7740)
									$(".prog_list_width").css('margin-left', "-7740px");
							}else{
								var epgScrollPos = (hrs*600)+(Minutes*10);
								if(epgScrollPos>600 && epgScrollPos<13200)
									$(".prog_list_width").css('margin-left', -(epgScrollPos-300));
								else if(epgScrollPos>= 0 && epgScrollPos<=600)
									$(".prog_list_width").css('margin-left', "0px");
								else if(currentMargin<= 0 && currentMargin > -12900)
									$(".prog_list_width").css('margin-left', "-12900px");
							}
							Keyhandler.updateProgInfo(currentActive_prog_id[current_Prog_Index],current_Prog_Index);
						}else{
							Keyhandler.removeProgInfo();
						}
						
					}else{
						if(source != "topMenu"){
							homeFocus = $('.imageFocus').attr('id');
							$('.imageFocus').removeClass("imageFocus");
							if(menuFocus)
								$('#tvGuideTopMenu-' + (menuFocus)).addClass("imageFocus");
							else
							$('#tvGuideTopMenu-' + (0)).addClass("imageFocus");
						}
					}
					
				}
				else if(source == "channels"){
					var current_Channel_Index = $(".imageFocus").attr("index");
					var currer = current_Channel_Index;
					current_Channel_Index--;
					/*if(currentActive_prog_id[current_Prog_Index] == undefined)
						current_Prog_Index--;*/

					/*if(current_Channel_Index == -1){
						$(".imageFocus").removeClass("imageFocus");
						$("#goCurrentTime").addClass("imageFocus");
					}else*/ 
					if(current_Channel_Index >= 0){
						//current_Channel_Index--;
						var hideROwIndex = currer- 4;
						$("#entireDataRow_"+hideROwIndex).css("display", "block");
							$("#channel_"+hideROwIndex).css("display", "block");
						$(".imageFocus").removeClass("imageFocus");
						$("#channel_"+current_Channel_Index).addClass("imageFocus");
						Keyhandler.updateProgInfo(currentActive_prog_id[current_Channel_Index],current_Channel_Index);
					}else{
						if(source != "topMenu"){
							homeFocus = $('.imageFocus').attr('id');
							$('.imageFocus').removeClass("imageFocus");
							if(menuFocus)
								$('#tvGuideTopMenu-' + (menuFocus)).addClass("imageFocus");
							else
								$('#tvGuideTopMenu-' + (0)).addClass("imageFocus");
						}
					}
				}
				else if(source == "goLive"){
					$(".imageFocus").removeClass("imageFocus");
						$(".date_active").addClass("imageFocus");
				}
				else if(source == "topMenu"){
					var index = $(".imageFocus").attr('index');
					menuFocus = index;
					$(".imageFocus").removeClass("imageFocus");
					$("#changeDate").addClass("imageFocus");
				}
			break;
		}
		case tvKeyCode.Enter: {
			
			Keyhandler.epgEnterKeyDown($(".imageFocus"));

			break;
		}
		case tvKeyCode.ArrowDown: {
			 var source = $(".imageFocus").attr("source");
			var current_Prog_Index = $(".imageFocus").attr("rowIndx");
			var index = $(".imageFocus").attr('index');
			totalDuration = 0;
			if(source == 'prgrams_data'){
				//lastIndexFocused = false;
				current_Prog_Index++;
				if(tvGuideCurrentList.length-5==current_Prog_Index && epgLastIndex < tvGuideChannelList.length){
					newProgramStartTime = $(".imageFocus").attr("startepochtime");
					//pageCount= pageCount+1;
					nameToShow = 'TV Guide';
					view ='tvGuide';
					Main.ShowLoading();
					Main.updateTvGuideContent();
					//Main.HideLoading();
				}

				if(current_Prog_Index <4){
					if(tvGuideCurrentList.length-1 >= current_Prog_Index){
						$(".imageFocus").removeClass("imageFocus");

						$("#epgData_"+current_Prog_Index+'_'+currentActive_prog_id[current_Prog_Index]).addClass("imageFocus");
					}	
				}else{
						
					if(tvGuideCurrentList.length-6 >= current_Prog_Index ){
						var hideROwIndex = current_Prog_Index- 4;
						if($("#entireDataRow_"+(hideROwIndex-1)).css("display") == 'block'){
							$("#entireDataRow_"+(hideROwIndex-1)).css("display", "none");	
							$("#channel_"+(hideROwIndex-1)).css("display", "none");
						}
						$("#entireDataRow_"+hideROwIndex).css("display", "none");
						$("#channel_"+hideROwIndex).css("display", "none");
						$(".imageFocus").removeClass("imageFocus");
						

						$("#epgData_"+current_Prog_Index+'_'+currentActive_prog_id[current_Prog_Index]).addClass("imageFocus");
						//Keyhandler.updateProgInfo(current_Prog_Index,);
					}else if(current_Prog_Index< tvGuideCurrentList.length){
						$(".imageFocus").removeClass("imageFocus");
						$("#epgData_"+current_Prog_Index+'_'+currentActive_prog_id[current_Prog_Index]).addClass("imageFocus");

					}
				}
				if(tvGuideCurrentList[current_Prog_Index].length>0){
					
					var hrs = tvGuideCurrentList[current_Prog_Index][currentActive_prog_id[current_Prog_Index]].start.substring(8,10);
					var Minutes = tvGuideCurrentList[current_Prog_Index][currentActive_prog_id[current_Prog_Index]].start.substring(10,12);
					var currentMargin = parseInt($('.prog_list_width').css('margin-left').replace('px',''));
					if(window_Width == 1280){
						var epgScrollPos = (hrs*360)+(Minutes*6);
						if(epgScrollPos>360 && epgScrollPos<8280)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-180));
						else if(epgScrollPos>= 0 && epgScrollPos<=360)
							$(".prog_list_width").css('margin-left', "0px");
						else if(currentMargin< 0 && currentMargin > -7740)
							$(".prog_list_width").css('margin-left', "-7740px");
					}else{
						var epgScrollPos = (hrs*600)+(Minutes*10);
						if(epgScrollPos>600 && epgScrollPos<13200)
							$(".prog_list_width").css('margin-left', -(epgScrollPos-300));
						else if(epgScrollPos>= 0 && epgScrollPos<=600)
							$(".prog_list_width").css('margin-left', "0px");
						else if(currentMargin<= 0 && currentMargin > -12900)
							$(".prog_list_width").css('margin-left', "-12900px");
					}
					
					Keyhandler.updateProgInfo(currentActive_prog_id[current_Prog_Index],current_Prog_Index);
				}else{
					Keyhandler.removeProgInfo();
				}
				
			}

			else if(source == "topMenu"){
					$(".imageFocus").removeClass("imageFocus");
					$("#channel_0").addClass("imageFocus");	
					menuFocus = index;
					Keyhandler.updateProgInfo(currentActive_prog_id[0],0);
			}

			else if(source == "dates"){
				/*last_selected_date = $(".imageFocus").attr('index');
				var current_Prog_Index = 0;
				$(".imageFocus").removeClass("imageFocus");
				$("#epgData_"+current_Prog_Index+'_'+currentActive_prog_id[current_Prog_Index]).addClass("imageFocus");*/
				$(".imageFocus").removeClass("imageFocus");
				if(menuFocus)
					$('#tvGuideTopMenu-' + (menuFocus)).addClass("imageFocus");
				else
					$('#tvGuideTopMenu-' + (0)).addClass("imageFocus");
			}

			else if(source == "channels"){
				var current_Channel_Index = $(".imageFocus").attr("index");
				var current_Id = $(".imageFocus").attr("id");
				current_Channel_Index++;
				if(tvGuideCurrentList.length-5==current_Channel_Index){
				 channel_down = true;
					//pageCount= pageCount+1;
					nameToShow = 'TV Guide';
					view ='tvGuide';
					//Main.updateTvGuideContent(clickOnTvGuide , selectedLang,true,false,"GET",nameToShow);
					if(epgLastIndex < tvGuideChannelList.length){
						Main.updateTvGuideContent();
					}
				}	
				if(current_Channel_Index < tvGuideCurrentList.length-5){
					var hideROwIndex = current_Channel_Index- 4;
					if($("#entireDataRow_"+(hideROwIndex-1)).css("display") == 'block'){
						$("#entireDataRow_"+(hideROwIndex-1)).css("display", "none");	
						$("#channel_"+(hideROwIndex-1)).css("display", "none");
					}

					$("#entireDataRow_"+hideROwIndex).css("display", "none");
					$("#channel_"+hideROwIndex).css("display", "none");

					$(".imageFocus").removeClass("imageFocus");
					$("#channel_"+current_Channel_Index).addClass("imageFocus");
					Keyhandler.updateProgInfo(currentActive_prog_id[current_Channel_Index],current_Channel_Index);
				}else if(current_Channel_Index < tvGuideCurrentList.length){
					$(".imageFocus").removeClass("imageFocus");
					$("#channel_"+current_Channel_Index).addClass("imageFocus");
					Keyhandler.updateProgInfo(currentActive_prog_id[current_Channel_Index],current_Channel_Index);
				}else if(current_Id == "goCurrentTime"){
					
					$(".imageFocus").removeClass("imageFocus");
					$("#channel_0").addClass("imageFocus");
				}
			}

			if(source == "buttons"){
				$(".imageFocus").removeClass("imageFocus");
				$("#"+lastSelectedDate).addClass("imageFocus")
				
			}
			break;
		}
		case 8:
		case tvKeyCode.Return: {

			break;
		}
		default:{
			break;
		}
	}
 }
 Keyhandler.epgEnterKeyDown = function(currFocus){
 	var source = currFocus.attr('source');
 	var index = currFocus.attr('index');
 	if(source == "topMenu"){
 		homeFocus = '';
 		Main.ShowLoading();
 		setTimeout(function(){
 			Main.updateTvGuideSection(topMenu["tvGuide"][index].id);
	 		$('.guideMenuSelected').removeClass('guideMenuSelected');
	 		$("#tvGuideTopMenu-"+index).addClass("guideMenuSelected");
 		},100);

 		
 	}else if(source == "dates"){
 		if (view != "seasonsList")
			pushState(view, $(".imageFocus").attr("id"));
		$(".imageFocus").removeClass("imageFocus");
		view = "seasonsList";
		$("#customMessage").show();
		$("#customMessage").html(Util.showDatesPopUp());
 	}
 	else if(source == "channels"){
 		var chaneelIndex = currFocus.attr("index");
 		Player.name = tvGuideChannelList[chaneelIndex].name;
 		pushState(view, $(".imageFocus").attr("id"));
 		liveChnlIndex = chaneelIndex;
 		Main.playLive(tvGuideChannelList[chaneelIndex].id);
 	}else if(source == "prgrams_data"){
 		var chaneelIndex = currFocus.attr("rowIndx");
 		Player.name = tvGuideChannelList[chaneelIndex].name;
 		pushState(view, $(".imageFocus").attr("id"));
 		liveChnlIndex = chaneelIndex;
 		Main.playLive(tvGuideChannelList[chaneelIndex].id);
 	}
 }
 Keyhandler.updateProgInfo = function(index,rowIndex){
 	try{
 		if(rowIndex <=tvGuideChannelList.length && (tvGuideCurrentList[rowIndex].length && index <= tvGuideCurrentList[rowIndex].length)){
	 		$('#epg_channel_img').attr('src',tvGuideChannelList[rowIndex].logo);
	 		$('#epg_prog_dur').text(tvGuideCurrentList[rowIndex][index].startTime +' - '+ tvGuideCurrentList[rowIndex][index].endTime);
	 		$('#epg_prog_title').text(tvGuideCurrentList[rowIndex][index].title);
	 		$('#epg_prog_desc').text(tvGuideCurrentList[rowIndex][index].desc)
	 	}else{
	 		Keyhandler.removeProgInfo();
	 	}
	 }catch(e){
	 	Keyhandler.removeProgInfo();
	 }
 }
Keyhandler.removeProgInfo = function(){
	$('#epg_channel_img').attr('src','images/livetv-error.jpg');
	$('#epg_prog_dur').text('');
	$('#epg_prog_title').text('');
	$('#epg_prog_desc').text('');
}