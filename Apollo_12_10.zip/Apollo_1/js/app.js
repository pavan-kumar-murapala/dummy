/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

var tvKeyCode = {};
var scount = 0,mainCount = 0;
var vers = null;
var eventTimer = '';
var scrollEvent = true;
var airMouse = false;

var filesPath = "https://d3lyihdno7nd8k.cloudfront.net/$ptv_v2/HTML5/jsonHTMLUSFlies.json";

var selectedMovie = '',view = '';


var app = {
    // Application Constructor
    initialize: function() {
        //document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
		this.onDeviceReady();
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
       
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
    	
        toast.inputdevice.getSupportedKeys(function (keys) {
	        for(var i=0, len=keys.length; i<len; i++) {
	            tvKeyCode[keys[i].name] = keys[i].code;
	           if(['MediaPlay', 'MediaPause', 'MediaFastForward', 'MediaRewind', 'MediaStop','MediaPlayPause'].indexOf(keys[i].name) >= 0) {
					toast.inputdevice.registerKey(keys[i].name,function () {});
				}
	        }
	    });
        var handleKeys = function (e) {
	        
	    	airMouse = false;
	    	var source = $(".imageFocus").attr("source");
	    	//console.log("source"+source);
			
			//e.preventDefault();
			
	        if(source && source == "list"){
	        	if(!scrollEvent){}
	            else{
	            	Main.processTrigger(e);
	            	scrollEvent = false;
	            	
	            	eventTimer = setTimeout(function(){
	            		scrollEvent = true;
	            		clearTimeout(eventTimer);
	                	eventTimer = '';
	            	},100);
	            }
	        }
	        else{
	        	console.log("Triggered");
	        	Main.processTrigger(e);
	        }
	    };
	    
        window.removeEventListener("keydown", handleKeys);
	    window.addEventListener('keydown', handleKeys);
		
	    function checkMain(){
	    	try{
	    		if(Main){
	    			Main.initialize();
	    			clearInterval(loadTimeInterval);
	    			loadTimeInterval = '';
	    		}
	    	}
	    	catch(e){
	    		clearInterval(loadTimeInterval);
    			loadTimeInterval = '';
	    		loadTimeInterval = setTimeout(checkMain,500);
	    	}
	    		
	    }
	    var loadTimeInterval = setTimeout(checkMain,500);
    
   
    }
};

// To load Main js files
app.loadMeta = function() {

				try{
					
					if(vers.files)
						{
						
						for(var i = 0 ; i< vers.files.length;i++){
							 
							  if(vers.files[i].FileName.indexOf('css')!=-1)
								  {
									  var link = document.createElement('link');
									  link.setAttribute('rel', 'stylesheet');
									  link.setAttribute('type', 'text/css');
									  link.setAttribute('href', ""+vers.files[i].FileName+"?v="+vers.files[i].VersionNo+"");
									  document.getElementsByTagName('head')[0].appendChild(link);
									 
									  if (link.addEventListener) {
										    link.addEventListener('load', function() {
										    	scount++; if(scount == vers.files.length) app.initialize();
										    }, false);
									  }else if(link.onreadystatechange){
										      link.onreadystatechange = function() {
											    var state = link.readyState;
											    if (state === 'loaded' || state === 'complete') {
											      link.onreadystatechange = null;
											      scount++; if(scount == vers.files.length  ) app.initialize();
											    }
											  };
									  }else
										  {
											  link.onload = function () {
												  scount++; if(scount == vers.files.length  ) app.initialize();
											  };
										  }
								  
								  }
							  else
								  {
									  var fileref=document.createElement('script');
							     	  if (typeof fileref!="undefined"){
							        	 fileref.src = ""+vers.files[i].FileName+"?v="+vers.files[i].VersionNo+"";
							             document.getElementsByTagName("head")[0].appendChild(fileref);
							             if(fileref.onreadystatechange)
							            	 {
								            	 fileref.onreadystatechange= function () {
								            	      if (this.readyState == 'complete') scount++;if(scount == vers.files.length  ) app.initialize();
								            	  }
							            	 }
							             else
							            	 {
								            	 fileref.onload = function()
								            	 {
								            		 scount++; if(scount == vers.files.length  ) app.initialize();
								            	 }  
							            	 }
							           }
								  }
					       }
						 // app.initialize();
						
						}
				}
				catch(e){
					document.getElementById("customMessage").style.display = "block";
				    document.getElementById("customMessage").innerHTML = "<p class='loadNot'><img style='width: 70px;vertical-align: -25px;padding-right: 14px;' src='https://d20w296omhlpzq.cloudfront.net/devices/common/shape-9@3x.png'/>Unable to load necessary modules, Please check your internet connection and relaunch the application.</p>";
				}

}

//To load Toast and Jquery JS files
app.loadMainFiles =  function(){
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if(xhr.readyState == 4)
		if(xhr.status == 200)
		{
			try{
				vers = JSON.parse(xhr.responseText);
				if(vers.mainFiles){
					 for(var i = 0 ; i< vers.mainFiles.length;i++){
						 
						  if(vers.mainFiles[i].FileName.indexOf('css')!=-1)
							  {
								  var link = document.createElement('link');
								  link.setAttribute('rel', 'stylesheet');
								  link.setAttribute('type', 'text/css');
								  link.setAttribute('href', ""+vers.mainFiles[i].FileName+"?v="+vers.mainFiles[i].VersionNo+"");
								  document.getElementsByTagName('head')[0].appendChild(link);
								 
								  if (link.addEventListener) {
									    link.addEventListener('load', function() {
									    	mainCount++; if(mainCount == vers.mainFiles.length) app.checkMainFilesStatus();
									    }, false);
								  }else if(link.onreadystatechange){
									      link.onreadystatechange = function() {
										    var state = link.readyState;
										    if (state === 'loaded' || state === 'complete') {
										      link.onreadystatechange = null;
										      mainCount++; if(mainCount == vers.mainFiles.length  ) app.checkMainFilesStatus();
										    }
										  };
								  }else
									  {
										  link.onload = function () {
											  mainCount++; if(mainCount == vers.mainFiles.length  ) app.checkMainFilesStatus();
										  };
									  }
							  
							  }
						  else
							  {
								  var fileref=document.createElement('script');
						     	  if (typeof fileref!="undefined"){
						        	 fileref.src = ""+vers.mainFiles[i].FileName+"?v="+vers.mainFiles[i].VersionNo+"";
						             document.getElementsByTagName("head")[0].appendChild(fileref);
						             if(fileref.onreadystatechange)
						            	 {
							            	 fileref.onreadystatechange= function () {
							            	      if (this.readyState == 'complete') mainCount++;if(mainCount == vers.mainFiles.length  ) app.checkMainFilesStatus();
							            	  }
						            	 }
						             else
						            	 {
							            	 fileref.onload = function()
							            	 {
							            		 mainCount++; if(mainCount == vers.mainFiles.length  ) app.checkMainFilesStatus();
							            	 }  
						            	 }
						           }
							  }
				       }
				}
			}
			catch(e){
				document.getElementById("customMessage").style.display = "block";
			    document.getElementById("customMessage").innerHTML = "<p class='loadNot'><img style='width: 70px;vertical-align: -25px;padding-right: 14px;' src='https://d20w296omhlpzq.cloudfront.net/devices/common/shape-9@3x.png'/>Unable to load necessary modules, Please check your internet connection and relaunch the application.</p>";
			}
			
		}
		else{
				document.getElementById("customMessage").style.display = "block";
			    document.getElementById("customMessage").innerHTML = "<p class='loadNot'><img style='width: 70px;vertical-align: -25px;padding-right: 14px;' src='https://d20w296omhlpzq.cloudfront.net/devices/common/shape-9@3x.png'/>Unable to load necessary modules, Please check your internet connection and relaunch the application.</p>";
		}
	};
	xhr.timeout = 4000;
	xhr.open("GET",filesPath+"?v="+new Date().getTime());
	xhr.send();
};

//Check status and go to Initialize
app.checkMainFilesStatus = function(){
	 function checkMainFiles(){
	    	try{
	    		if(cordova){}
	    		if(jQuery){}
	    		app.loadMeta();
	    	}
	    	catch(e){
	    		clearInterval(loadTimeInterval);
	    		loadTimeInterval = '';
	    		loadTimeInterval = setTimeout(checkMainFiles,100);
	    	}
	    		
	    }
	    var loadTimeInterval = setTimeout(checkMainFiles,100);
}
app.checkCountry = function(){
		$.ajax({ 
	        type: "GET", 
	        url: "https://prod.$ptv.com/auth/api/v2/get/country"
	        })
	        .done(function( msg ) {
				try{
					var data = JSON.parse(msg);
					if(data.status == 1){
						var countryCode = data.response.countryCode;
						
						//countryCode = "US";
						
						if(countryCode.trim().toUpperCase() == "IN"){
							filesPath = "https://d3lyihdno7nd8k.cloudfront.net/$ptv_v2/HTML5/jsonHTMLINDIAFlies.json";
						}
						else{
							filesPath = "https://d3lyihdno7nd8k.cloudfront.net/$ptv_v2/HTML5/jsonHTMLUSFlies.json";
						}
						app.loadMainFiles();
					}
				}catch(e){
					app.loadMainFiles();
				}
	           
	           
	        })
	        .error(function() {
	        	document.getElementById("customMessage").style.display = "block";
			    document.getElementById("customMessage").innerHTML = "<p class='loadNot'><img style='width: 70px;vertical-align: -25px;padding-right: 14px;' src='https://d20w296omhlpzq.cloudfront.net/devices/common/shape-9@3x.png'/>Unable to get location information.</p>";
	    	
	        })
	        .fail(function() {
	        	document.getElementById("customMessage").style.display = "block";
			    document.getElementById("customMessage").innerHTML = "<p class='loadNot'><img style='width: 70px;vertical-align: -25px;padding-right: 14px;' src='https://d20w296omhlpzq.cloudfront.net/devices/common/shape-9@3x.png'/>Unable to get location information.</p>";
	        });
	}
//app.checkCountry();

app.initialize();