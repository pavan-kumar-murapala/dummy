Util = {};
Util.splashHtml = function() {
    var Text = "";
    Text += '<div style="overflow:hidden;height:100%;width:100%;background:url(images/logo.png) no-repeat; background-size:36%;background-position:center center;">';
    Text += '</div>';
    return Text;
}
var listMenu = true;
var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                ];
function formatDate(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return date.getMonth()+1 + "/" + date.getDate() + "/" + date.getFullYear() + " " + strTime;
}			

Util.getSubChannels = function(array){
	var Text = '';
	Text += '<ul class="submenu">'
//Text += '<li>'
if(listMenu){
	Text += '<div class="listMenu">'
	Text += '<ul>'
	var star = '';
	for(var i=0;i<array.length;i++){
		if(array[i].favorite){
			star = "<img style='width:25px' src='images/star.png'>"
		}
		else{
			star = '';
		}
		Text += '	<li source="playSubChannels" type="list" index="'+i+'" id="liveChannels-'+i+'" length="'+array.length+'"><table><tr><td><img class="listThumb" src="'+array[i].thumb+'"></td><td class="channelText"><p> '+array[i].name+' </p></td><td>'+star+'</td></tr></table></li>'
	}
	Text += '</ul>'
	Text += '</div>'
}
else{
	Text += '<div class="GridMenu">'
	Text += '<ul>'
	for(var i=0;i<array.length;i++){
		if(i%5 == 0){
			Text += '<div id="Grow-'+(i/5)+'">'
		}
		Text += '	<li><div type="grid" source="playSubChannels" index="'+i+'" id="liveChannels-'+i+'" length="'+array.length+'"><img class="gridthumb" src="'+array[i].thumb+'"><p class="gridTitle">'+array[i].name+'</p></div></li>'
		if((i+1)%5 == 0 && i != 0){
			Text += '</div>'
		}
		
	}
		
	
	Text += '</ul>'
	Text += '</div>'
}

//Text += '</li>'
Text += '</ul>'
return Text;
}
Util.leftMenu = function(setView){
	var Text = '';
	Text += '<div  class="wrapper"  >';
	Text += '<div  class="leftMenu col-sm-1 no-padding"  >'
	
	Text += '<ul class="menuBar">'


	    Text += '<li class="dummyList">'
		Text += '</li>'
		Text += '<li class="" index = 0 id="'+setView+'leftMenu-0" ><img src="images/movies.png"><p>Movies</p>'


		Text += '</li>'
		
		Text += '<li  index = 1 id="'+setView+'leftMenu-1" ><img src="images/tv-shows.png"><p>TVShows</p>'
		Text += '</li>'
		
		Text += '<li  index = 2 id="'+setView+'leftMenu-2"><img src="images/livetv.png"></i><p>Live TV</p>'
		Text += '</li>'
		
		Text += '<li  index = 3 id="'+setView+'leftMenu-3"><img src="images/watchlist.png"><p>Watch List</p>'
		Text += '</li>'

		Text += '<li  index = 4 id="'+setView+'leftMenu-4"><img src="images/profile.png"><p>Profile</p>'
		Text += '</li>'
		if(Main.profile){
			Text += '<li  index = 5 id="'+setView+'leftMenu-5"><img src="images/logout.png"><p>Log Out</p>'
		}
		else{
			Text += '<li  index = 5 id="'+setView+'leftMenu-5"><img src="images/logout.png"><p>Sign In</p>'
		}
		
		Text += '</li>'
	Text += '</ul>'
	Text +='</div>';
	return Text;
}
Util.updateHomePage = function(homeData){
	var Text = '';

	for(var i=0;i<homeData.length && i < 4;i++){
		Text += Util.generateMovieCard(homeData[i],i,homeData.length);
	}

	return Text;
}

Util.profilePage = function(){
	var Text = '';

	Text += '<div class="profile-container">'
	Text += '<div class="profile-bg-wrap"><div class="profile-logo"><img src="images/login_logo.png"/></div></div>'
	Text += '<div class="profile-detail"><div class="profile-image"><img src="images/profile-icon.png"/></div><span class="profile-name">'+Main.profile.company_name+'</span></div>'
	var active = "";
	if(Main.profile.expire < new Date().getTime())
		active = "In active";
	else 
		active = "active";
	Text += '<div class="profile-account-details"><div class="row"><div class="profile-detail-inner col-sm-6"><img src="images/profile.png"/><span>Premium Account - '+active+'</span></div><div class="profile-detail-inner col-sm-6"><img src="images/calendar.png"/><span>Expire: '+dateUtil(Main.profile.expire)+'</span></div></div></div>'

    Text += '</div>'

	return Text;
}
Util.liveTvDetailPage = function(obj){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	Text += Util.leftMenu("liveTvDetail");

	Text += '<div class="col-sm-11 inner-content no-padding">'
	
	Text += '<div  class="header clearfix" id="heading">'
	Text += '<div  class="container">'			
	Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
	Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Movies</h1></div>'
	Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
	Text += '</div>';
	Text += '</div>';

	Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'
	Text += '<li >Live TV / '+obj.name+'</li>'					
	Text +='</ul></div></div>';

	
	Text += '<div  class="liveDetail-page" id="liveDiv" >'
	Text += '<div  class="liveBanner" id="" >'
	Text+="<img  src='"+obj.logo+"'>"
	Text +='</div >';
	Text += ' <div class="liveChannelButtons">'
	Text += '<div  class="row liveEpgNow" >'
		Text += '<div  class="col-sm-3" >'
		Text+="<img src='"+obj.logo+"' class='liveDetailImg'>"
		Text +='</div >';

		Text += '<div  class="col-sm-5" >'
			Text+="<h2 class='epgNow'>Live Now : "+obj.epg_now+"</h2>"
			Text+="<h2 class='epgNow'>Live Next : "+obj.epg_next+"</h2>"
		Text +='</div >';

	Text +='</div >';

	Text +='<div class="SP-buttons">';
	
	Text +='<div source="SPbuttons" index="0" id="watchNow" class="btn playButton imageFocus"><img src="images/livetv.png"/><span>Play</span></div>';
	Text +='<div source="SPbuttons" index="1"  id="watchList" class="btn dark-btn watchList" ><img src="images/watchlist.png"/><span>Add to WatchList</span></div>';
	
	Text += '</div>';
	
	Text +='</div>';
	Text += '</div>';
	
	Text += '</div>';

	return Text;
}

Util.movieDetailsPage = function(singleMoviePage){
	var Text = '';
	
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("singleMovie");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading">'
			Text += '<div  class="container">'			
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Movies</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
                        Text += '</div>';
                        Text += '</div>';

			Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'

			
			Text += '<li >'+singleMoviePage.genres+'</li>'					
			
			
			Text +='</ul></div></div>';

			Text += '<div  class="details-page" id="movieDiv" >'
			
			Text += '<div  class="details-page-left" id="movieImage" >'
			Text+="<img src='"+singleMoviePage.poster+"'>"
			Text +='</div >';

			Text += '<div  class="details-page-right" id="movieCategory" >'
				Text += '<div  class="title-name" >'+singleMoviePage.title+' ('+singleMoviePage.year+')</div>'
				
				Text +='<div class="release-date">'+dateUtil(singleMoviePage.released)+'</div>';
				Text +='<div class="desc" >'+singleMoviePage.plot+'</div>';
				Text +='<div class="rating">';
				
				Text +='<div class="rating-value"><span>'+singleMoviePage.rank+'<b>/10</b></span></div>';
				Text +='<div class="imdb-btn"><img src="images/imdb-btn.png"/></div>';

				Text += '</div>';
				Text +='<div class="SP-buttons">';
				
				Text +='<div source="SPbuttons" index="0" id="SP-btn-0" class="btn playButton imageFocus"><img src="images/livetv.png"/><span>Play</span></div>';
				Text +='<div source="SPbuttons" index="1"  id="SP-btn-1" class="btn dark-btn watchList" ><img src="images/watchlist.png"/><span>Add to WatchList</span></div>';
			//	Text +='<div source="SPbuttons" index="2"  id="SP-btn-2" class="btn dark-btn allDetails"><div class="dots"><span></span><span></span><span></span></div><span>Show All Details</span></div>';
				
				
				Text +='</div>';
				
			Text +='</div >';


			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
	
	return Text;
}

Util.tvShowDetailPage = function(show){
	var Text = '';
	
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("tvShowDetail");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading">'
			Text += '<div  class="container">'			
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">TV SHOW</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
                        Text += '</div>';
                        Text += '</div>';

			Text += '<div  id="navBar" ><div class="container"><ul class="listNone">'

			
			Text += '<li >'+show.genres+'</li>'					
			
			
			Text +='</ul></div></div>';

			Text += '<div class="scrollSingleDiv">';

			Text += '<div  class="details-page " id="movieDiv" >'
			
			Text += '<div  class="details-page-left" id="movieImage" >'
			Text+="<img src='"+show.poster+"'>"
			Text +='</div >';

			Text += '<div  class="details-page-right" id="movieCategory" >'
				Text += '<div  class="title-name" >'+show.title+' ('+show.year+')</div>'
				
				Text +='<div class="release-date">'+dateUtil(show.released)+'</div>';
				Text +='<div class="desc" >'+show.plot+'</div>';
				Text +='<div class="rating">';
				
				Text +='<div class="rating-value"><span>'+show.rank+'<b>/10</b></span></div>';
				Text +='<div class="imdb-btn"><img src="images/imdb-btn.png"/></div>';

				Text += '</div>';
				Text +='<div class="SP-buttons">';
				
				Text +='<div source="SPbuttons" index="1"  id="SP-btn-1" class="btn dark-btn selectSeason imageFocus" ><span>Season Selected - '+ Object.keys(tvShowDetail.seasons).length+'</span></div>';

				//Text +='<div source="SPbuttons" index="0" id="SP-btn-0" class="btn playButton imageFocus"><img src="images/livetv.png"/><span>Play</span></div>';
				//Text +='<div source="SPbuttons" index="1"  id="SP-btn-1" class="btn dark-btn watchList" ><img src="images/watchlist.png"/><span>Add to WatchList</span></div>';
			//	Text +='<div source="SPbuttons" index="2"  id="SP-btn-2" class="btn dark-btn allDetails"><div class="dots"><span></span><span></span><span></span></div><span>Show All Details</span></div>';
				
				Text +='</div>';

				
			Text +='</div >';
			

			Text +='</div >';

			Text += "<div class='episodes' id='episodes' style='display: inline-block;'>"
			/* if(Object.keys(show.seasons).length > 0)
			for(var i=0;i<Object.keys(show.seasons[1]).length;i++){
				var v_index = Math.floor(i/4);
				var h_index = i % 4;
				if(h_index == 0){
					if(v_index > 0)
						Text += "<div id='epsRow-"+v_index+"' style='display:none' class='episodesRow row'>"
					else
						Text += "<div id='epsRow-"+v_index+"' class='episodesRow row'>"
				}
					
				Text += Util.generateEpsCard(show,show.seasons[1][(i+1)],v_index,h_index,(i+1),1,Object.keys(tvShowDetail.seasons[1]).length);
				if(h_index == 3)
					Text += "</div>"
			} */
			var seasonToShow = Object.keys(tvShowDetail.seasons).length;
			for(var i=0;i<Object.keys(show.seasons[seasonToShow]).length && i < 4;i++){
				Text += Util.generateEpsCard(show,show.seasons[seasonToShow][(i+1)],(i+1),seasonToShow,Object.keys(tvShowDetail.seasons[seasonToShow]).length);
			}

			Text +='</div>';
			Text +='</div >';
			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
	
	return Text;
}


function dateUtil(epocTime){
	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
   ];
	var date = new Date(parseInt(epocTime));
	
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var day = date.getDate();
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var seconds = date.getSeconds();

	return day+" "+monthNames[month] + " " + year;
}
Util.updatetvShowPage =  function(homeTvShowData){
	var Text = '';
	
	var rowID = 0;
	for(var i=0;i<homeTvShowData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		if(v_index < 2){
			if(h_index == 0){
				Text += "<div id='tvShowRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>"
			}
		}
		

	}
    return Text;
}
Util.homeLivePage =  function(homeLiveData){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("live");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Live</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div  id="navBar" ><div class="container"><ul class="menuHorizontal">'

			for (var i=0;i<topMenu["livetv"].length;i++){
				if(i == 0){
					Text += '<li  id="liveTopMenu-'+i+'" count='+topMenu["livetv"].length+' class="menuLiveSelected" source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'">'+topMenu["livetv"][i].name+'</li>'					
				}
				else if(i < 10){
					Text += '<li  id="liveTopMenu-'+i+'" count='+topMenu["livetv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'">'+topMenu["livetv"][i].name+'</li>'					
				}
				else{
					Text += '<li  id="liveTopMenu-'+i+'" style="display:none" count='+topMenu["livetv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["livetv"][i].id+'">'+topMenu["livetv"][i].name+'</li>'					
				}
			}
			
			Text +='</ul></div></div>';
			Text += '<div  class="inner-wrap">'
			Text += '<div id="liveList" >'
			
			for(var i=0;i<homeLiveData.length && i < 4;i++){
				Text += Util.generateLiveCard(homeLiveData[i],i,homeLiveData.length);
			}
			
			Text +='</div >';
			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
    return Text;
}
Util.generateLiveCard = function(obj,i,count){
	var Text = '';
	Text += '<div class="live-image" imdb="'+obj.id+'"	index='+i+' id="homeLive-'+i+'" count='+count+' >'
        Text += '<div class="live-image-inner">'
	Text += '<img src="' + obj.logo + '"  onerror="this.src=\'images/livetv-error.jpg\';" />';
	Text += '</div>'
  Text += '</div>'
	return Text;
}

Util.generateTVEPSCard = function(i,s){
	var Text = '';
	Text += '<div source = "eps" class="tvEPS" imdb="'+tvShowDetail.imdb+'"	index='+i+' id="eps-'+i+'" eps='+i+' season = '+s+'  count='+Object.keys(tvShowDetail.seasons[s]).length+' >'
	Text += '<img src="' + tvShowDetail.seasons[s][i].screenshot + '"  onerror="this.src=\'images/show.png\';" />';
	Text += '</div>'
	return Text;
}
Util.generateEpsCard = function(show,obj,i,s,count){
	var Text = '';
	Text += '<div   source = "eps" class="tvEPS" imdb="'+show.imdb+'" index='+i+' id="eps-'+i+'" eps='+i+' season = '+s+'  count='+count+' >'
	var image = '';
	if(obj){
		image = obj.screenshot;
	}
	Text += '<img src="' + image	+ '"  onerror="this.src=\'images/show.png\';" />';
	Text += '</div>'
	return Text;
}
Util.homeTVShowPage =  function(homeTvShowData){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("tvShows");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class="header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">TV SHOWS</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div  id="navBar" ><div class="container"><ul class="menuHorizontal ">'

			for (var i=0;i<topMenu["tv"].length;i++){
				if(i == 0){
					Text += '<li  id="tvShowsTopMenu-'+i+'" count='+topMenu["tv"].length+' class="tvmenuSelected" source="topMenu" index='+i+' attrId="'+topMenu["tv"][i].id+'">'+topMenu["tv"][i].name+'</li>'					
				}
				else if(i>8){
					Text += '<li  id="tvShowsTopMenu-'+i+'" style="display:none" count='+topMenu["tv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["tv"][i].id+'">'+topMenu["tv"][i].name+'</li>'										
				}else{
					Text += '<li  id="tvShowsTopMenu-'+i+'" count='+topMenu["tv"].length+' source="topMenu" index='+i+' attrId="'+topMenu["tv"][i].id+'">'+topMenu["tv"][i].name+'</li>'					
				}
			}
			
			Text +='</ul></div></div>';
			Text += '<div class="center-layout">'
			Text += '<div id="tvShowList" >'
			
			var rowID = 0;
			for(var i=0;i<homeTvShowData.length;i++){

				var v_index = Math.floor(i/5);
				var h_index = i % 5;
				if(v_index < 2){
					if(h_index == 0){
						Text += "<div id='tvShowRow-"+v_index+"' class='row'>";
					}
					Text +="<div class='col-5-eq'>"
					Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
					Text +="</div>"
					if(h_index == 4){
						Text += "</div>"
					}
				}
				

			}
			Text +='</div >';
			Text +='</div >';


			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	Text += '</div>';
    return Text;
}
Util.addTvRow = function(v_indexAdd){
	var Text = '';
	var rowID = 0;
	for(var i= (v_indexAdd)*5;i<homeTvShowData.length;i++){

		var v_index = Math.floor(i/5);
		var h_index = i % 5;
		
		if(v_index == v_indexAdd){

			if(h_index == 0){
				Text += "<div id='tvShowRow-"+v_index+"' class='row'>";
			}
			Text +="<div class='col-5-eq'>"
			Text += Util.generatetvShowCard(homeTvShowData[i],v_index,h_index,i,homeTvShowData.length);
			Text +="</div>"
			if(h_index == 4){
				Text += "</div>"
			}
		}
		else{
			break;
		}
		

	}
	return Text;
}
Util.generatetvShowCard = function(obj,v,h,i,count){
	var Text = '';
	Text += '<div class="tvShows-image" imdb="'+obj.imdb+'"	index='+i+' h_index='+h+'  v_index='+v+'  id="hometvShows-'+v+"-"+h+'" count='+count+' >'
	Text += '<img src="' + obj.poster + '"  onerror="this.src=\'images/movieTile1.png\';" />';
		Text += '<div class="shows-content">';
			Text += '<div class="shows-name">'+obj.title+'</div>'
			var seasons = '',dateValue = '';
			if(obj.seasons && obj.seasons.last){
				dateValue = "Last: "+ dateUtil(obj.seasons.last.released);
				seasons = obj.seasons.last.season +" Seasons";
			} 

    Text += '<div class="shows-detail">'+obj.year+'- '+ (seasons)+' - <b>'+obj.rank+'</b></div>'
			Text += '<div class="shows-date"> '+dateValue+'</div>'
		
		Text +='</div>';
	Text += '</div>'
	return Text;
}
Util.homePage = function(homeData){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("homeMovies");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class= "header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Movies</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div id="navBar"><div class="container"><ul class="menuHorizontal">'

			for (var i=0;i<topMenu["movie"].length;i++){
				if(i == 0){
					Text += '<li  id="topMenu-'+i+'" count='+topMenu["movie"].length+' class="menuSelected" source="topMenu" index='+i+' attrId="'+topMenu["movie"][i].id+'">'+topMenu["movie"][i].name+'</li>'					
				}
				else if(i >= 8){
					Text += '<li  id="topMenu-'+i+'" style="display:none" count='+topMenu["movie"].length+' source="topMenu" index='+i+' attrId="'+topMenu["movie"][i].id+'">'+topMenu["movie"][i].name+'</li>'										
				}else	{
					Text += '<li  id="topMenu-'+i+'" count='+topMenu["movie"].length+' source="topMenu" index='+i+' attrId="'+topMenu["movie"][i].id+'">'+topMenu["movie"][i].name+'</li>'					
				}
			}
			
			Text +='</ul></div></div>';
                        Text += '<div class="inner-wrap">'
			Text += '<div id="moviesList">'                        
			for(var i=0;i<homeData.length && i < 4;i++){
					Text += Util.generateMovieCard(homeData[i],i,homeData.length);
			}
			Text +='</div >';
                        Text +='</div >';

			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	
    return Text;
}
Util.generateMovieCard = function(obj,i,count){
	var Text = '';
	Text += '<div class="shows-image" imdb="'+obj.imdb+'"	index='+i+' id="homeMovies-'+i+'" count='+count+' >'
	Text += '<img src="' + obj.poster + '"  onerror="this.src=\'images/movieTile1.png\';" />';
	Text += '</div>'
	return Text;
}
Util.generatePlayerOverlay = function(){
    var Text = '';
    Text += '<div class="wrapperMenu">'
	Text += '<ul >'
	var count = 0;
	function checkLive(obj){
		return obj.type == "live";
	}
	var liveData = HomeData.categories.filter(checkLive);
	for(var i=0;i<liveData.length;i++){
		 
		Text += '<li source="playCatg" index="'+i+'" id="cat-'+i+'" length="'+liveData.length+'">'+liveData[i].name+'</li>';	
	}
	Text += '</ul>'
    Text += '</div>'

    return Text;
}


Util.showStatusPopUp = function(code,message,btnText){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="info-msg-cont">'
    Text += '<div class="row remove-margin">'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4">'
    var image = 'https://d20w296omhlpzq.cloudfront.net/devices/common/shape-5@3x.png';
    if(code == 0)
        image = 'images/error.png';
    else if(code ==1)
        image = 'images/success.png';
    else
        image = 'images/info.png';
    
    Text += '<img src="'+image+'" class="img-responsive pop-err-ico" alt="">'
    Text += '</div>'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '<p class="dis-block">'+message+'</p>'
    Text += '<a href="#" class="orange-button" style="margin:0px">'+btnText+'</a>'
    Text += '</div>'

    return Text;
}
Util.showMenuPopUp = function(seasonNo,count,name){
    var Text = '';
    Text += '<div class="overlay-screen"></div>'
    Text += '<div class="info-msg-cont">'
    Text += '<div class="row remove-margin">'
	Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
	for(var i=0;i<count;i++)
		if(i == (seasonNo-1))
			Text += '<a index='+i+' count='+count+' id="ssList-'+i+'" class="btn btn-default btn-block btnCust imageFocus" >'+name+" - "+(i+1)+'</a>'		
		else
			Text += '<a index='+i+' count='+count+' id="ssList-'+i+'" class="btn btn-default btn-block btnCust" >'+name+" - "+(i+1)+'</a>'
    Text += '<div class="col-md-4 col-lg-4 col-xl-4"></div>'
    Text += '</div>'
    Text += '</div>'

    return Text;
}
Util.showPopUp = function(no,title,desc,info1,info2){
    var Text = '';
    Text += '<div class="">'
    Text += '<div class="overlay-screen">'
    Text += '</div>'
    Text += '<div class="popup-Message-container popup-lg">'
    Text += '<h4 class="popup-subhead">'+title+'</h4>'
    Text += '<p class="popup-p" >'+desc
    Text += '</p>'
    Text +=   '<div class="col-md-12 col-lg-12 col-xl-12 remove-padding popup-btn-wrap mt30">'
    if(no == 2){
        
        Text +=     '<a id="Btn-0" class="popUpBtn popUpBtn-orange remove-margin" index="0">'+info1+'</a>'
        Text +=     '<a id="Btn-1" class="popUpBtn  ml30  remove-margin" index="1">'+info2+'</a>'
        
    }
    else if(no == 1){
            Text +=     '<a id="Btn-0" index = "0" class="popUpBtn-orange popUpBtn remove-margin">'+info1+'</a>'
    }
    else {
        
    }
    Text +=   '</div>  '
    Text +=   ''
    Text += '</div>'
    Text += ''
    Text += '</div>'
return Text;
}
Util.signIn = function(){
	var Text = "";
	
	Text += '<div class="login-page">'
	Text += '     <div id="loading"  class="cssload-container loader-bg" style="display:none;z-index: 999;">'
	Text += '      <div id="loadingImg">'
	Text += '	     	<div class="loader-img" id="loadingText">Loading..</div> '
	Text += '	     	<img src="images/Spin.png" class="imgLoader" />'
	Text += '     	</div>'
	Text += '     </div>'
	Text += '        <div class="login-container">'
	Text += '            <div class="center-wrap">'
	Text += '                <div class="login-logo"><img src="images/login_logo.png"/></div>'
	Text += '                <div class="login-form">'
	Text += '                    <div class="login-header">Login</div>'
	Text += '                    <div class="login-content">'
	Text += '                        <form>'
	Text += '                            <div class="form-group">'
	Text += '                                <input type="text" placeholder="Username" id="email" value="trial0988@apollogroup.tv" class="form-control signin imageFocus"/>'
	Text += '                            </div>'
	Text += '                            <div class="form-group">'
	Text += '                                <input type="password" placeholder="Password" id="password" value="88nq7fo" class="form-control signin"/>'
	Text += '                            </div>'
	Text += '                            <div class="btn-action">'
	Text += '                                <b type="submit"  id="login"  class="btn blue-btn">Login</b>'
	Text += '                            </div>'
	Text += '                        </form>'
	Text += '                    </div>'
	Text += '                </div>'
	Text += '            </div>'
	Text += '        </div>'
	Text += '    </div>'
	
	return Text;
}
Util.watchListHTML = function(){
	var Text = '';
	Text += '<div  class="no-padding" id="" >';
	
	Text += Util.leftMenu("watchList");


		Text += '<div  class="col-sm-11 inner-content no-padding" >';
			Text += '<div  class= "header clearfix" id="heading" >'
			Text += '<div  class="container">'	
			Text += '<div class="logo col-sm-4 p-left"><img src="images/logo.png"/></div>'
			Text += '<div class="col-sm-4 text-center"><h1 class="main-title">Watch List</h1></div>'
			Text += '<div class="form-search navItem floatRight col-sm-4 p-right"> <input type="text" placeholder="search" class="searchBar"></div>'
			Text += '</div>';
			Text += '</div>';
			Text += '<div id="navBar"><div class="container"><ul class="menuHorizontal">'

			if(watchlistMap["movies"].length)
				Text += '<li  id="moviesTopMenu"  class="" source="topMenu" >Movies</li>'		
			if(watchlistMap["tvshow"].length)	
				Text += '<li  id="showsTopMenu" class="" source="topMenu">TV Shows</li>'		
			if(watchlistMap["channel"].length)		
				Text += '<li  id="channelsTopMenu" class="" source="topMenu">Channels</li>'		
			
			Text +='</ul></div></div>';
                        Text += '<div class="inner-wrap">'
			Text += '<div id="moviesList">'                        
			for(var i=0;i<homeData.length && i < 4;i++){
					Text += Util.generateMovieCard(homeData[i],i,homeData.length);
			}
			Text +='</div >';
                        Text +='</div >';

			//Text +='</div>';
		Text += '</div>';
	Text += '</div>';

	
    return Text;
}